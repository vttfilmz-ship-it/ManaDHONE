
import React, { useState, useEffect } from 'react';
import { Advert } from '../types';
import { getAds } from '../services/storageService';
import { IconUpload, IconTrash, IconEdit, IconWand } from './Icons';

interface AdminAdFormProps {
    initialData?: Advert | null;
    onSave: (data: Advert) => void;
    onCancel: () => void;
}

const AdminAdForm: React.FC<AdminAdFormProps> = ({ initialData, onSave, onCancel }) => {
    const [formData, setFormData] = useState<Partial<Advert>>({
        title: '',
        description: '',
        imageUrl: '',
        businessId: ''
    });

    const [otherAds, setOtherAds] = useState<Advert[]>([]);
    const [previewIndex, setPreviewIndex] = useState(0);

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        }
        // Load other ads to show context in the slider preview
        const allAds = getAds();
        setOtherAds(allAds.filter(a => a.id !== initialData?.id));
    }, [initialData]);

    // Combined list for the slider preview (Draft Ad + Existing Ads)
    const previewAds = [
        { ...formData, id: 'draft', isDraft: true },
        ...otherAds
    ].filter(a => a.imageUrl);

    // Auto-slide effect for the preview
    useEffect(() => {
        if (previewAds.length <= 1) return;
        const timer = setInterval(() => {
            setPreviewIndex(prev => (prev + 1) % previewAds.length);
        }, 4000);
        return () => clearInterval(timer);
    }, [previewAds.length]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
                // Force preview to show the draft when image is updated
                setPreviewIndex(0);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.title || !formData.imageUrl) return;

        const finalData: Advert = {
            id: initialData?.id || Date.now().toString(),
            status: initialData?.status || 'approved',
            title: formData.title!,
            description: formData.description || '',
            imageUrl: formData.imageUrl!,
            businessId: formData.businessId
        };

        onSave(finalData);
    };

    return (
        <div className="bg-white p-8 rounded-[2.5rem] shadow-2xl max-w-4xl mx-auto border border-gray-100">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-3xl font-black text-gray-900">{initialData ? 'Edit Advertisement' : 'Create New Ad'}</h2>
                    <p className="text-gray-500 font-medium">Design how your business appears in the main town slider.</p>
                </div>
                <button onClick={onCancel} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            
            {/* Contextual Slider Preview */}
            <div className="mb-10">
                <div className="flex items-center justify-between mb-4">
                    <label className="block text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                        <IconWand className="w-4 h-4 text-indigo-500" />
                        Live Slider Context Preview
                    </label>
                    <div className="flex gap-1">
                        {previewAds.map((_, i) => (
                            <div key={i} className={`h-1 rounded-full transition-all ${i === previewIndex ? 'bg-indigo-600 w-4' : 'bg-gray-200 w-1'}`}></div>
                        ))}
                    </div>
                </div>

                <div className="relative w-full h-64 md:h-80 rounded-[2rem] overflow-hidden shadow-xl border border-gray-200 bg-slate-900 group">
                    {previewAds.length > 0 ? (
                        previewAds.map((ad, index) => (
                            <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ${index === previewIndex ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                                <img src={ad.imageUrl} alt="Ad Preview" className="w-full h-full object-cover opacity-60" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-8">
                                    {(ad as any).isDraft && (
                                        <div className="absolute top-4 left-4 bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter shadow-lg animate-pulse">
                                            Current Draft
                                        </div>
                                    )}
                                    <span className="bg-yellow-500 text-black text-[10px] font-black px-2 py-0.5 rounded uppercase mb-2 inline-block w-fit">Featured Promotion</span>
                                    <h3 className="text-white text-3xl font-black mb-2 drop-shadow-md">
                                        {ad.title || 'Your Ad Title'}
                                    </h3>
                                    <p className="text-gray-200 text-sm font-medium drop-shadow-sm line-clamp-2 max-w-lg">
                                        {ad.description || 'Provide a catchy description to attract local customers in Dhone.'}
                                    </p>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 bg-gray-100">
                            <IconWand className="w-12 h-12 mb-2 opacity-20" />
                            <span className="text-sm font-bold">Waiting for image and content...</span>
                        </div>
                    )}
                </div>
                <p className="text-[10px] text-gray-400 mt-3 text-center uppercase font-bold tracking-widest">
                    This preview shows how your ad blends with existing active advertisements.
                </p>
            </div>
            
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-6">
                    {/* Image Management Section */}
                    <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Banner Asset</label>
                        <div className="relative group aspect-video bg-gray-50 rounded-3xl overflow-hidden border-2 border-dashed border-gray-200 hover:border-indigo-300 transition-all">
                            {formData.imageUrl ? (
                                <>
                                    <img src={formData.imageUrl} alt="Ad Asset" className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                        <label className="cursor-pointer bg-white text-gray-900 p-3 rounded-2xl shadow-xl hover:scale-110 transition-transform flex items-center gap-2 font-bold text-sm">
                                            <IconEdit className="w-4 h-4" /> Replace
                                            <input type="file" onChange={handleImageUpload} className="hidden" accept="image/*" />
                                        </label>
                                        <button 
                                            type="button"
                                            onClick={() => setFormData(prev => ({...prev, imageUrl: ''}))}
                                            className="bg-red-500 text-white p-3 rounded-2xl shadow-xl hover:scale-110 transition-transform"
                                        >
                                            <IconTrash className="w-5 h-5" />
                                        </button>
                                    </div>
                                </>
                            ) : (
                                <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer group-hover:bg-indigo-50/50 transition-colors">
                                    <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                        <IconUpload className="w-8 h-8 text-indigo-500" />
                                    </div>
                                    <span className="text-sm font-bold text-gray-500">Upload Banner Image</span>
                                    <span className="text-[10px] text-gray-400 mt-1">Recommended: 1600 x 600px</span>
                                    <input type="file" onChange={handleImageUpload} className="hidden" accept="image/*" />
                                </label>
                            )}
                        </div>
                        <div className="mt-3 flex gap-2">
                             <input 
                                type="text" 
                                name="imageUrl" 
                                value={formData.imageUrl} 
                                onChange={handleChange} 
                                placeholder="Or paste image URL here..." 
                                className="flex-1 text-xs p-3 bg-gray-50 border-2 border-gray-100 rounded-xl focus:border-indigo-500 outline-none transition-all" 
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Link Business (Optional)</label>
                        <div className="relative">
                            <select 
                                name="businessId" 
                                value={formData.businessId} 
                                onChange={handleChange as any}
                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none appearance-none font-bold text-gray-700"
                            >
                                <option value="">No Direct Business Link</option>
                                {/* In a real app we'd map businesses here */}
                                <option value="1">ManaDHONE Spice Garden</option>
                                <option value="2">City Mobiles & Computers</option>
                            </select>
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-6">
                    <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Ad Headline</label>
                        <input 
                            type="text" 
                            name="title" 
                            value={formData.title} 
                            onChange={handleChange} 
                            required 
                            placeholder="e.g. Mega Sunday Biryani Offer!"
                            className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold text-gray-900" 
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Promotion Details</label>
                        <textarea 
                            name="description" 
                            value={formData.description} 
                            onChange={handleChange} 
                            rows={5} 
                            placeholder="Describe the offer or event details..."
                            className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all resize-none text-gray-700 leading-relaxed" 
                        />
                    </div>

                    <div className="pt-6 flex flex-col sm:flex-row gap-4">
                        <button 
                            type="button" 
                            onClick={onCancel} 
                            className="flex-1 px-8 py-4 border-2 border-gray-100 rounded-2xl text-gray-500 font-bold hover:bg-gray-50 transition-colors"
                        >
                            Discard
                        </button>
                        <button 
                            type="submit" 
                            className="flex-1 px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 transition-all transform hover:-translate-y-1 active:translate-y-0"
                        >
                            {initialData ? 'Update Promotion' : 'Publish to Town'}
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default AdminAdForm;
