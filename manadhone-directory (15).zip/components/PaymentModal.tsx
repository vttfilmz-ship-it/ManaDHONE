
import React, { useState } from 'react';
import { IconCheck, IconCreditCard, IconCurrency } from './Icons';
import { Transaction } from '../types';
import { saveTransaction } from '../services/storageService';

interface PaymentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: (transactionId: string) => void;
    amount: number;
    itemName: string;
    itemType: Transaction['type'];
    referenceId: string;
    customerEmail: string;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSuccess, amount, itemName, itemType, referenceId, customerEmail }) => {
    const [step, setStep] = useState<'options' | 'processing' | 'success'>('options');
    const [method, setMethod] = useState<Transaction['method']>('UPI');

    if (!isOpen) return null;

    const handlePay = () => {
        setStep('processing');
        
        // Simulate real transaction delay
        setTimeout(() => {
            /* Added itemName property to the transaction object to match updated Transaction interface and enable descriptive reminders in Admin */
            const transaction: Transaction = {
                id: 'TXN_' + Math.random().toString(36).substr(2, 9).toUpperCase(),
                referenceId,
                type: itemType,
                amount,
                currency: 'INR',
                status: 'success',
                method,
                customerEmail,
                customerName: 'Town Customer',
                createdAt: Date.now(),
                itemName: itemName
            };
            
            saveTransaction(transaction);
            setStep('success');
            
            setTimeout(() => {
                onSuccess(transaction.id);
            }, 1500);
        }, 2000);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
                
                {/* Header */}
                <div className="bg-indigo-600 p-8 text-white flex justify-between items-start">
                    <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-70 mb-1">Secure Checkout</p>
                        <h3 className="text-3xl font-black tracking-tight">₹{amount}</h3>
                        <p className="text-indigo-100 text-sm mt-1">{itemName}</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                <div className="p-8">
                    {step === 'options' && (
                        <div className="space-y-6">
                            <div className="space-y-3">
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Select Payment Method</label>
                                
                                <button 
                                    onClick={() => setMethod('UPI')}
                                    className={`w-full p-4 rounded-2xl border-2 flex items-center justify-between transition-all ${method === 'UPI' ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-100 hover:border-slate-200'}`}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600">
                                            <IconCurrency className="w-6 h-6" />
                                        </div>
                                        <span className="font-bold text-slate-700">UPI (GPay, PhonePe)</span>
                                    </div>
                                    {method === 'UPI' && <IconCheck className="w-5 h-5 text-indigo-600" />}
                                </button>

                                <button 
                                    onClick={() => setMethod('Card')}
                                    className={`w-full p-4 rounded-2xl border-2 flex items-center justify-between transition-all ${method === 'Card' ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-100 hover:border-slate-200'}`}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 bg-teal-100 rounded-xl flex items-center justify-center text-teal-600">
                                            <IconCreditCard className="w-6 h-6" />
                                        </div>
                                        <span className="font-bold text-slate-700">Credit / Debit Card</span>
                                    </div>
                                    {method === 'Card' && <IconCheck className="w-5 h-5 text-indigo-600" />}
                                </button>
                            </div>

                            <button 
                                onClick={handlePay}
                                className="w-full bg-slate-900 hover:bg-indigo-600 text-white font-black py-5 rounded-2xl shadow-xl transition-all active:scale-95 uppercase tracking-[0.2em] text-xs"
                            >
                                Pay Now ₹{amount}
                            </button>
                            
                            <p className="text-[10px] text-slate-400 text-center flex items-center justify-center gap-1.5 font-bold uppercase">
                                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd"></path></svg>
                                256-bit encrypted secure transaction
                            </p>
                        </div>
                    )}

                    {step === 'processing' && (
                        <div className="py-12 flex flex-col items-center text-center animate-in zoom-in duration-300">
                            <div className="w-20 h-20 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-8"></div>
                            <h4 className="text-2xl font-black text-slate-900 mb-2">Processing Payment</h4>
                            <p className="text-slate-500 max-w-xs">Please do not close this window or press the back button.</p>
                        </div>
                    )}

                    {step === 'success' && (
                        <div className="py-12 flex flex-col items-center text-center animate-in zoom-in duration-300">
                            <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mb-8 shadow-2xl shadow-emerald-500/30">
                                <IconCheck className="w-12 h-12" />
                            </div>
                            <h4 className="text-2xl font-black text-slate-900 mb-2">Payment Successful!</h4>
                            <p className="text-slate-500 max-w-xs">Your transaction was successful. Proceeding to finalize your request...</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PaymentModal;