
import React from 'react';
import { HistoryEvent } from '../types';
import { IconCastle, IconTrain } from './Icons';

interface TimelineProps {
    events: HistoryEvent[];
}

const Timeline: React.FC<TimelineProps> = ({ events }) => {
    return (
        <div className="relative py-12">
            {/* Vertical Line */}
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-1 bg-indigo-200 md:-ml-0.5 rounded-full"></div>

            <div className="space-y-12">
                {events.map((event, index) => {
                    const isLeft = index % 2 === 0;
                    return (
                        <div key={event.id} className={`relative flex items-center md:justify-between ${isLeft ? 'flex-row-reverse' : ''}`}>
                            
                            {/* Empty space for alignment on desktop */}
                            <div className="hidden md:block w-5/12"></div>

                            {/* Dot */}
                            <div className="absolute left-4 md:left-1/2 w-5 h-5 bg-indigo-600 rounded-full border-4 border-white shadow-lg md:-ml-2.5 z-10 transform -translate-x-1.5 md:translate-x-0"></div>

                            {/* Content Card */}
                            <div className={`ml-12 md:ml-0 w-full md:w-5/12 bg-white dark:bg-slate-800 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 border border-gray-100 dark:border-slate-700 overflow-hidden group`}>
                                {/* Image Section */}
                                {event.imageUrl && (
                                    <div className="h-48 w-full overflow-hidden relative">
                                        <img 
                                            src={event.imageUrl} 
                                            alt={event.title} 
                                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                                        <div className="absolute bottom-3 left-4">
                                            <span className="inline-block px-3 py-1 bg-indigo-600/90 text-white rounded-lg text-sm font-bold shadow-md">
                                                {event.year}
                                            </span>
                                        </div>
                                    </div>
                                )}

                                <div className="p-6 relative">
                                    {/* Arrow for Desktop */}
                                    <div className={`hidden md:block absolute top-8 w-4 h-4 bg-white dark:bg-slate-800 transform rotate-45 border-gray-100 dark:border-slate-700 ${isLeft ? '-right-2 border-r border-t' : '-left-2 border-l border-b'} z-0`}></div>

                                    {!event.imageUrl && (
                                        <span className="inline-block px-3 py-1 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-full text-xs font-bold mb-3">
                                            {event.year}
                                        </span>
                                    )}
                                    
                                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 leading-tight">{event.title}</h3>
                                    <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                                        {event.description}
                                    </p>
                                    
                                    {/* Icon Badge Overlay (if no image, or as an accent) */}
                                    <div className="absolute top-4 right-4 text-gray-100 dark:text-slate-700 opacity-20 transform rotate-12 group-hover:rotate-0 transition-transform duration-500">
                                        {event.iconType === 'fort' && <IconCastle className="w-16 h-16" />}
                                        {event.iconType === 'train' && <IconTrain className="w-16 h-16" />}
                                        {/* Fallback generic icon circle if specific icon missing */}
                                        {event.iconType !== 'fort' && event.iconType !== 'train' && (
                                            <div className="w-16 h-16 rounded-full border-4 border-current"></div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Timeline;
