
import React, { useState, useEffect } from 'react';
import { NewsItem, LocalEvent, Influencer, EmergencyContact, Job, HeroSlide, HistoryEvent, TourismSpot, Freelancer, JobCategory, FMProgram, User, Property, RealEstateAgent } from '../types';
import { IconUpload, IconTrash, IconMapPin, IconPlay, IconUser, IconFilm, IconBed, IconBath, IconCar, IconEdit, IconCheck } from './Icons';
import { getJobCategories, getAgents } from '../services/storageService';

// Helper for image upload
const ImageUpload = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
    const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => onChange(reader.result as string);
            reader.readAsDataURL(file);
        }
    };
    return (
        <div className="flex gap-2 items-center">
            <input 
                type="text" 
                value={value} 
                onChange={(e) => onChange(e.target.value)} 
                placeholder="Image URL" 
                className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 bg-gray-50 border p-2 text-sm" 
            />
            <label className="cursor-pointer bg-white border border-gray-300 text-gray-700 px-3 py-2 rounded-md hover:bg-gray-50 flex items-center gap-1 shadow-sm text-sm">
                <IconUpload className="w-4 h-4" />
                <input type="file" onChange={handleFile} className="hidden" accept="image/*" />
            </label>
        </div>
    );
};

// --- PROPERTY FORM ---
interface PropertyFormProps {
    initialData?: Property | null;
    onSave: (data: Property) => void;
    onCancel: () => void;
}
export const PropertyForm: React.FC<PropertyFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<Property>>({ 
        title: '', type: 'Plot', purpose: 'Sale', price: '', area: '', location: '', description: '', imageUrl: '', agentId: '', status: 'available',
        bedrooms: 0, bathrooms: 0, parking: false, amenities: [], images: [], featured: false
    });
    const [agents, setAgents] = useState<RealEstateAgent[]>([]);
    const [amenityStr, setAmenityStr] = useState('');

    useEffect(() => { 
        if (initialData) {
            setData(initialData); 
            setAmenityStr(initialData.amenities?.join(', ') || '');
        }
        setAgents(getAgents());
    }, [initialData]);

    const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const fileList = Array.from(files);
            const readAsDataURL = (file: File) => new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result as string);
                reader.readAsDataURL(file);
            });

            const processedImages = await Promise.all(fileList.map(readAsDataURL));
            
            setData(prev => {
                const updatedImages = [...(prev.images || []), ...processedImages];
                return {
                    ...prev,
                    images: updatedImages,
                    // If no main image exists, use the first one from this batch
                    imageUrl: prev.imageUrl || updatedImages[0]
                };
            });
        }
    };

    const removeGalleryImage = (indexToRemove: number) => {
        setData(prev => {
            const updated = (prev.images || []).filter((_, index) => index !== indexToRemove);
            return {
                ...prev,
                images: updated,
                // If we deleted the image that was the main one, pick a new one or clear it
                imageUrl: prev.imageUrl === (prev.images || [])[indexToRemove] ? (updated[0] || '') : prev.imageUrl
            };
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...data,
            id: initialData?.id || Date.now().toString(),
            createdAt: initialData?.createdAt || Date.now(),
            amenities: amenityStr.split(',').map(a => a.trim()).filter(Boolean)
        } as Property);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-8 rounded-[2rem] shadow-xl max-w-2xl mx-auto border border-gray-100">
            <h3 className="font-black text-2xl text-slate-900 border-b pb-4">{initialData ? 'Edit Property Listing' : 'Add Property'}</h3>
            
            {/* Status Management (Admin Authority) */}
            <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100 mb-6 flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                    <label className="block text-xs font-black text-indigo-400 uppercase tracking-widest mb-2">Listing Status</label>
                    <select 
                        required 
                        className="w-full border border-indigo-200 p-3 rounded-xl bg-white text-indigo-900 font-bold outline-none"
                        value={data.status}
                        onChange={e => setData({...data, status: e.target.value as any})}
                    >
                        <option value="pending">Pending Approval (Hidden)</option>
                        <option value="available">Approved & Available (Live)</option>
                        <option value="sold">Approved & Sold (Live)</option>
                        <option value="rejected">Rejected (Hidden)</option>
                    </select>
                </div>
                <div className="sm:w-1/3 flex flex-col justify-end">
                    <label className="flex items-center gap-2 cursor-pointer bg-white p-3 rounded-xl border border-indigo-200 hover:bg-indigo-50 transition-colors">
                        <input 
                            type="checkbox" 
                            checked={data.featured} 
                            onChange={e => setData({...data, featured: e.target.checked})}
                            className="w-5 h-5 text-indigo-600 rounded border-gray-300" 
                        />
                        <span className="text-xs font-black text-indigo-900 uppercase">Pin to Top</span>
                    </label>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Title</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.title} onChange={e => setData({...data, title: e.target.value})} />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Type</label>
                    <select className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.type} onChange={e => setData({...data, type: e.target.value as any})}>
                        <option value="Plot">Plot</option>
                        <option value="House">House</option>
                        <option value="Apartment">Apartment</option>
                        <option value="Commercial">Commercial</option>
                    </select>
                </div>
            </div>

            {/* Features Row */}
            {(data.type === 'House' || data.type === 'Apartment') && (
                <div className="grid grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl">
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 flex items-center gap-1">
                            <IconBed className="w-3 h-3" /> Beds
                        </label>
                        <input type="number" className="w-full border p-2 rounded-lg font-bold" value={data.bedrooms} onChange={e => setData({...data, bedrooms: parseInt(e.target.value) || 0})} />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 flex items-center gap-1">
                            <IconBath className="w-3 h-3" /> Baths
                        </label>
                        <input type="number" className="w-full border p-2 rounded-lg font-bold" value={data.bathrooms} onChange={e => setData({...data, bathrooms: parseInt(e.target.value) || 0})} />
                    </div>
                    <div className="flex flex-col justify-end">
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1 flex items-center gap-1">
                            <IconCar className="w-3 h-3" /> Parking
                        </label>
                        <button 
                            type="button"
                            onClick={() => setData({...data, parking: !data.parking})}
                            className={`w-full py-2 rounded-lg border text-xs font-bold ${data.parking ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-slate-400'}`}
                        >
                            {data.parking ? 'Yes' : 'No'}
                        </button>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Purpose</label>
                    <select className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.purpose} onChange={e => setData({...data, purpose: e.target.value as any})}>
                        <option value="Sale">Sale</option>
                        <option value="Rent">Rent</option>
                    </select>
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Price</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.price} onChange={e => setData({...data, price: e.target.value})} placeholder="e.g. ₹50 Lakhs" />
                </div>
            </div>

            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Amenities (Comma separated)</label>
                <input className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-medium" value={amenityStr} onChange={e => setAmenityStr(e.target.value)} placeholder="e.g. Pool, Garden, Lift" />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Area</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.area} onChange={e => setData({...data, area: e.target.value})} placeholder="e.g. 1500 Sqft" />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Assign Agent</label>
                    <select className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.agentId} onChange={e => setData({...data, agentId: e.target.value})}>
                        <option value="">Direct Seller (No Agent)</option>
                        {agents.map(a => <option key={a.id} value={a.id}>{a.name} ({a.agency})</option>)}
                    </select>
                </div>
            </div>

            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Location</label>
                <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.location} onChange={e => setData({...data, location: e.target.value})} />
            </div>

            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Detailed Description</label>
                <textarea rows={4} className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-medium" value={data.description} onChange={e => setData({...data, description: e.target.value})} placeholder="Describe property highlights, nearby landmarks, etc." />
            </div>

            {/* COVER IMAGE */}
            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Cover Image</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>

            {/* MULTIPLE PHOTOS GALLERY */}
            <div className="pt-4 border-t border-slate-100">
                <label className="block text-xs font-black text-indigo-400 uppercase tracking-widest mb-3">Property Gallery (Multiple Photos)</label>
                <div className="grid grid-cols-3 gap-3 mb-4">
                    {data.images?.map((img, idx) => (
                        <div key={idx} className="relative aspect-video rounded-xl overflow-hidden border border-slate-200 group">
                            <img src={img} className="w-full h-full object-cover" alt="" />
                            <button 
                                type="button" 
                                onClick={() => removeGalleryImage(idx)}
                                className="absolute top-1 right-1 p-1.5 bg-red-500 text-white rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600"
                            >
                                <IconTrash className="w-3.5 h-3.5" />
                            </button>
                            {data.imageUrl === img && (
                                <div className="absolute bottom-1 left-1 bg-indigo-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase">Cover</div>
                            )}
                        </div>
                    ))}
                    <label className="cursor-pointer aspect-video border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center hover:bg-indigo-50 hover:border-indigo-300 transition-all group">
                        <IconUpload className="w-6 h-6 text-slate-300 group-hover:text-indigo-400" />
                        <span className="text-[10px] font-black text-slate-400 uppercase mt-1 group-hover:text-indigo-500">Add Photos</span>
                        <input type="file" multiple onChange={handleGalleryUpload} className="hidden" accept="image/*" />
                    </label>
                </div>
            </div>

            <div className="flex justify-end gap-3 pt-6">
                <button type="button" onClick={onCancel} className="px-6 py-3 border-2 border-slate-50 rounded-xl text-slate-400 font-bold hover:bg-slate-50 transition-all">Cancel</button>
                <button type="submit" className="px-10 py-3 bg-indigo-600 text-white rounded-xl font-black shadow-lg hover:bg-indigo-700 transition-all active:scale-95">Save Changes</button>
            </div>
        </form>
    );
};

// --- AGENT FORM ---
interface AgentFormProps {
    initialData?: RealEstateAgent | null;
    onSave: (data: RealEstateAgent) => void;
    onCancel: () => void;
}
export const AgentForm: React.FC<AgentFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<RealEstateAgent>>({ name: '', agency: '', phone: '', bio: '', experience: '', imageUrl: '', verified: true });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...data,
            id: initialData?.id || Date.now().toString()
        } as RealEstateAgent);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-[2rem] shadow-xl max-w-2xl mx-auto border border-gray-100">
            <h3 className="font-black text-2xl text-slate-900 border-b pb-4">{initialData ? 'Edit Agent Profile' : 'Add New Agent'}</h3>
            
            <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 flex items-center gap-3">
                <input 
                    type="checkbox" 
                    id="verified"
                    checked={data.verified} 
                    onChange={e => setData({...data, verified: e.target.checked})}
                    className="w-6 h-6 text-blue-600 border-blue-300 rounded focus:ring-blue-500" 
                />
                <label htmlFor="verified" className="text-sm font-black text-blue-900 uppercase cursor-pointer flex items-center gap-2">
                    <IconCheck className="w-4 h-4" /> Verified Agent Status
                </label>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Full Name</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.name} onChange={e => setData({...data, name: e.target.value})} />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Agency Name</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.agency} onChange={e => setData({...data, agency: e.target.value})} />
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Contact Phone</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.phone} onChange={e => setData({...data, phone: e.target.value})} />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Total Experience</label>
                    <input required className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-bold" value={data.experience} onChange={e => setData({...data, experience: e.target.value})} placeholder="e.g. 5 Years" />
                </div>
            </div>
            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Professional Bio</label>
                <textarea rows={3} className="w-full border-2 border-slate-50 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all font-medium" value={data.bio} onChange={e => setData({...data, bio: e.target.value})} />
            </div>
            <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Profile Photo</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-50">
                <button type="button" onClick={onCancel} className="px-6 py-3 border-2 border-slate-50 rounded-xl text-slate-400 font-bold hover:bg-slate-50 transition-all">Cancel</button>
                <button type="submit" className="px-10 py-3 bg-indigo-600 text-white rounded-xl font-black shadow-lg hover:bg-indigo-700 transition-all active:scale-95">Save Agent</button>
            </div>
        </form>
    );
};

// --- NEWS FORM ---
interface NewsFormProps {
    initialData?: NewsItem | null;
    onSave: (data: NewsItem) => void;
    onCancel: () => void;
}
export const NewsForm: React.FC<NewsFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<NewsItem>>({ title: '', summary: '', author: '', imageUrl: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            title: data.title!,
            summary: data.summary!,
            author: data.author || 'Admin',
            imageUrl: data.imageUrl || 'https://picsum.photos/400/300',
            date: initialData?.date || Date.now()
        } as NewsItem);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit News' : 'Add News'}</h3>
            <div>
                <label className="block text-sm font-medium mb-1">Headline</label>
                <input required className="w-full border p-2 rounded" value={data.title} onChange={e => setData({...data, title: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Summary</label>
                <textarea required rows={3} className="w-full border p-2 rounded" value={data.summary} onChange={e => setData({...data, summary: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Image</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Author/Source</label>
                <input className="w-full border p-2 rounded" value={data.author} onChange={e => setData({...data, author: e.target.value})} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save News</button>
            </div>
        </form>
    );
};

// --- EVENTS FORM ---
interface EventFormProps {
    initialData?: LocalEvent | null;
    onSave: (data: LocalEvent) => void;
    onCancel: () => void;
}
export const EventForm: React.FC<EventFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<LocalEvent>>({ title: '', location: '', date: '', type: 'Event', imageUrl: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            title: data.title!,
            location: data.location!,
            date: data.date!,
            type: data.type!,
            imageUrl: data.imageUrl || 'https://picsum.photos/400/300'
        } as LocalEvent);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Event' : 'Add Event/Movie'}</h3>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Title</label>
                    <input required className="w-full border p-2 rounded" value={data.title} onChange={e => setData({...data, title: e.target.value})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select className="w-full border p-2 rounded" value={data.type} onChange={e => setData({...data, type: e.target.value as 'Movie' | 'Event'})}>
                        <option value="Event">Event</option>
                        <option value="Movie">Movie</option>
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Location</label>
                    <input required className="w-full border p-2 rounded" value={data.location} onChange={e => setData({...data, location: e.target.value})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Date/Time</label>
                    <input required className="w-full border p-2 rounded" value={data.date} onChange={e => setData({...data, date: e.target.value})} placeholder="e.g. Sat, 10 AM" />
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Image</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Event</button>
            </div>
        </form>
    );
};

// --- INFLUENCER FORM ---
interface InfluencerFormProps {
    initialData?: Influencer | null;
    onSave: (data: Influencer) => void;
    onCancel: () => void;
}
export const InfluencerForm: React.FC<InfluencerFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<Influencer>>({ name: '', handle: '', platform: 'Instagram', followers: '', imageUrl: '', profileUrl: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            name: data.name!,
            handle: data.handle!,
            platform: data.platform!,
            followers: data.followers!,
            imageUrl: data.imageUrl || 'https://picsum.photos/100',
            profileUrl: data.profileUrl || '#'
        } as Influencer);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Star' : 'Add Star'}</h3>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Name</label>
                    <input required className="w-full border p-2 rounded" value={data.name} onChange={e => setData({...data, name: e.target.value})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Handle (@)</label>
                    <input required className="w-full border p-2 rounded" value={data.handle} onChange={e => setData({...data, handle: e.target.value})} />
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium mb-1">Platform</label>
                    <select className="w-full border p-2 rounded" value={data.platform} onChange={e => setData({...data, platform: e.target.value as any})}>
                        <option value="Instagram">Instagram</option>
                        <option value="YouTube">YouTube</option>
                        <option value="Facebook">Facebook</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Followers Count</label>
                    <input required className="w-full border p-2 rounded" value={data.followers} onChange={e => setData({...data, followers: e.target.value})} placeholder="e.g. 50k" />
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Website / Profile URL</label>
                <input className="w-full border p-2 rounded" value={data.profileUrl} onChange={e => setData({...data, profileUrl: e.target.value})} placeholder="https://instagram.com/username" />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Profile Photo</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Star</button>
            </div>
        </form>
    );
};

// --- CONTACT FORM ---
interface ContactFormProps {
    initialData?: EmergencyContact | null;
    onSave: (data: EmergencyContact) => void;
    onCancel: () => void;
}
export const ContactForm: React.FC<ContactFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<EmergencyContact>>({ title: '', number: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            title: data.title!,
            number: data.number!
        } as EmergencyContact);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-md mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Contact' : 'Add Emergency Contact'}</h3>
            <div>
                <label className="block text-sm font-medium mb-1">Service Title</label>
                <input required className="w-full border p-2 rounded" value={data.title} onChange={e => setData({...data, title: e.target.value})} placeholder="e.g. Police Station" />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Phone Number</label>
                <input required className="w-full border p-2 rounded" value={data.number} onChange={e => setData({...data, number: e.target.value})} placeholder="e.g. 100" />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Contact</button>
            </div>
        </form>
    );
};

// --- JOB CATEGORY FORM ---
interface JobCategoryFormProps {
    initialData?: JobCategory | null;
    onSave: (data: JobCategory) => void;
    onCancel: () => void;
}
export const JobCategoryForm: React.FC<JobCategoryFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<JobCategory>>({ name: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            name: data.name!
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-md mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Category' : 'Add Job Category'}</h3>
            <div>
                <label className="block text-sm font-medium mb-1">Category Name</label>
                <input required className="w-full border p-2 rounded" value={data.name} onChange={e => setData({...data, name: e.target.value})} placeholder="e.g. Sales, IT, Medical" />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Category</button>
            </div>
        </form>
    );
};

// --- JOB FORM ---
interface JobFormProps {
    initialData?: Job | null;
    onSave: (data: Job) => void;
    onCancel: () => void;
}
export const JobForm: React.FC<JobFormProps> = ({ initialData, onSave, onCancel }) => {
    /* Updated default applyByDate to 7 days from now */
    const [data, setData] = useState<Partial<Job>>({ 
        title: '', company: '', location: '', type: 'Full-time', salary: '', description: '', contact: '', status: 'approved', category: '', applyByDate: Date.now() + (7 * 24 * 60 * 60 * 1000), isFeatured: false
    });
    const [categories, setCategories] = useState<JobCategory[]>([]);
    
    useEffect(() => { 
        if (initialData) setData(initialData); 
        setCategories(getJobCategories());
    }, [initialData]);

    const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const timestamp = new Date(e.target.value).getTime();
        setData({...data, applyByDate: timestamp});
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            status: data.status || 'approved',
            title: data.title!,
            company: data.company!,
            location: data.location!,
            type: data.type! as 'Full-time' | 'Part-time' | 'Contract',
            salary: data.salary!,
            description: data.description!,
            contact: data.contact!,
            category: data.category!,
            postedDate: initialData?.postedDate || Date.now(),
            applyByDate: data.applyByDate || Date.now() + (7 * 24 * 60 * 60 * 1000),
            isFeatured: data.isFeatured || false
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-3xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Job' : 'Add New Job'}</h3>
            
            <div className="flex flex-col sm:flex-row gap-4">
                {/* Status Field (Admin Only) */}
                <div className="flex-1 bg-yellow-50 p-3 rounded-md border border-yellow-200">
                    <label className="block text-sm font-bold text-yellow-800 mb-1">Listing Status</label>
                    <select 
                        className="w-full border border-yellow-300 p-2 rounded bg-white text-gray-800"
                        value={data.status}
                        onChange={e => setData({...data, status: e.target.value as any})}
                    >
                        <option value="pending">Pending Approval</option>
                        <option value="approved">Approved (Live)</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>

                {/* Featured Toggle */}
                <div className="flex-1 bg-amber-50 p-3 rounded-md border border-amber-200 flex items-center gap-3">
                    <input 
                        type="checkbox" 
                        id="isFeatured"
                        checked={data.isFeatured}
                        onChange={e => setData({...data, isFeatured: e.target.checked})}
                        className="w-5 h-5 text-amber-600 border-amber-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="isFeatured" className="text-sm font-bold text-amber-800 cursor-pointer">Mark as Featured Listing</label>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Job Title</label>
                    <input required className="w-full border p-2 rounded" value={data.title} onChange={e => setData({...data, title: e.target.value})} placeholder="e.g. Sales Executive" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Company Name</label>
                    <input required className="w-full border p-2 rounded" value={data.company} onChange={e => setData({...data, company: e.target.value})} placeholder="e.g. Dhone Textiles" />
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <select required className="w-full border p-2 rounded" value={data.category} onChange={e => setData({...data, category: e.target.value})}>
                        <option value="">Select Category</option>
                        {categories.map(cat => (
                            <option key={cat.id} value={cat.name}>{cat.name}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Job Type</label>
                    <select className="w-full border p-2 rounded" value={data.type} onChange={e => setData({...data, type: e.target.value as any})}>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Contract">Contract</option>
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Salary Range</label>
                    <input required className="w-full border p-2 rounded" value={data.salary} onChange={e => setData({...data, salary: e.target.value})} placeholder="e.g. ₹15,000/month" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Location</label>
                    <input required className="w-full border p-2 rounded" value={data.location} onChange={e => setData({...data, location: e.target.value})} placeholder="e.g. Main Bazaar, Dhone" />
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Contact Info</label>
                    <input required className="w-full border p-2 rounded" value={data.contact} onChange={e => setData({...data, contact: e.target.value})} placeholder="Phone or Email" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Apply By Date</label>
                    <input 
                        required 
                        type="date" 
                        className="w-full border p-2 rounded" 
                        value={data.applyByDate ? new Date(data.applyByDate).toISOString().split('T')[0] : ''} 
                        onChange={handleDateChange} 
                    />
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea required rows={4} className="w-full border p-2 rounded" value={data.description} onChange={e => setData({...data, description: e.target.value})} placeholder="Job roles and responsibilities..." />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Job</button>
            </div>
        </form>
    );
};

// --- FREELANCER FORM ---
interface FreelancerFormProps {
    initialData?: Freelancer | null;
    onSave: (data: Freelancer) => void;
    onCancel: () => void;
}
export const FreelancerForm: React.FC<FreelancerFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<Freelancer>>({ 
        name: '', skill: '', category: 'Tech', experience: '', contact: '', description: '', hourlyRate: '', imageUrl: '', status: 'approved', location: 'Dhone', isFeatured: false
    });
    
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            status: data.status || 'approved',
            name: data.name!,
            skill: data.skill!,
            category: data.category! as any,
            experience: data.experience!,
            contact: data.contact!,
            description: data.description!,
            hourlyRate: data.hourlyRate!,
            location: data.location!,
            imageUrl: data.imageUrl || 'https://i.pravatar.cc/150?u=${Date.now()}',
            joinedDate: initialData?.joinedDate || Date.now(),
            isFeatured: data.isFeatured || false
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-3xl auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Profile' : 'Add New Freelancer'}</h3>
            
            <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 bg-yellow-50 p-3 rounded-md border border-yellow-200">
                    <label className="block text-sm font-bold text-yellow-800 mb-1">Profile Status</label>
                    <select 
                        className="w-full border border-yellow-300 p-2 rounded bg-white text-gray-800"
                        value={data.status}
                        onChange={e => setData({...data, status: e.target.value as any})}
                    >
                        <option value="pending">Pending Approval</option>
                        <option value="approved">Approved (Live)</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div className="flex-1 bg-indigo-50 p-3 rounded-md border border-indigo-200 flex items-center gap-3">
                    <input 
                        type="checkbox" 
                        id="isFeatured"
                        checked={data.isFeatured}
                        onChange={e => setData({...data, isFeatured: e.target.checked})}
                        className="w-5 h-5 text-indigo-600 border-indigo-300 rounded focus:ring-indigo-500"
                    />
                    <label htmlFor="isFeatured" className="text-sm font-bold text-indigo-800 cursor-pointer">Mark as Top Talent (Priority)</label>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Name</label>
                    <input required className="w-full border p-2 rounded" value={data.name} onChange={e => setData({...data, name: e.target.value})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Skill / Title</label>
                    <input required className="w-full border p-2 rounded" value={data.skill} onChange={e => setData({...data, skill: e.target.value})} placeholder="e.g. Electrician" />
                </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <select className="w-full border p-2 rounded" value={data.category} onChange={e => setData({...data, category: e.target.value as any})}>
                        <option value="Tech">Tech & Design</option>
                        <option value="Home Service">Home Service</option>
                        <option value="Education">Education</option>
                        <option value="Creative">Creative</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Experience</label>
                    <input required className="w-full border p-2 rounded" value={data.experience} onChange={e => setData({...data, experience: e.target.value})} placeholder="e.g. 5 Years" />
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Contact (Phone/Email)</label>
                    <input required className="w-full border p-2 rounded" value={data.contact} onChange={e => setData({...data, contact: e.target.value})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Rate (Optional)</label>
                    <input className="w-full border p-2 rounded" value={data.hourlyRate} onChange={e => setData({...data, hourlyRate: e.target.value})} placeholder="e.g. ₹500/visit" />
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea required rows={3} className="w-full border p-2 rounded" value={data.description} onChange={e => setData({...data, description: e.target.value})} placeholder="Describe your services..." />
            </div>

            <div>
                <label className="block text-sm font-medium mb-1">Profile Photo</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>

            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Profile</button>
            </div>
        </form>
    );
};

// --- HERO SLIDE FORM ---
interface HeroSlideFormProps {
    initialData?: HeroSlide | null;
    onSave: (data: HeroSlide) => void;
    onCancel: () => void;
}
export const HeroSlideForm: React.FC<HeroSlideFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<HeroSlide>>({ imageUrl: '', caption: '', active: true, page: 'home' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            imageUrl: data.imageUrl || 'https://picsum.photos/1200/600',
            caption: data.caption,
            active: data.active !== undefined ? data.active : true,
            page: data.page || 'home'
        } as HeroSlide);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Slide' : 'Add Hero Slide'}</h3>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">
                        Image <span className="text-xs text-gray-500 font-normal ml-1">(Rec: 1600x600 px)</span>
                    </label>
                    <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Target Page</label>
                    <select 
                        className="w-full border p-2 rounded" 
                        value={data.page || 'home'} 
                        onChange={e => setData({...data, page: e.target.value as any})}
                    >
                        <option value="home">Home Page</option>
                        <option value="history">History Page</option>
                        <option value="tourism">Tourism Page</option>
                        <option value="jobs">Jobs Page</option>
                        <option value="freelancers">Freelancers Page</option>
                        <option value="realestate">Real Estate Page</option>
                    </select>
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Caption (Optional)</label>
                <input className="w-full border p-2 rounded" value={data.caption} onChange={e => setData({...data, caption: e.target.value})} placeholder="e.g. Welcome to Dhone" />
            </div>
            <div className="flex items-center gap-2">
                <input 
                    type="checkbox" 
                    checked={data.active} 
                    onChange={e => setData({...data, active: e.target.checked})} 
                    className="h-4 w-4 text-indigo-600 rounded"
                />
                <label className="text-sm font-medium">Active (Visible on Page)</label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Slide</button>
            </div>
        </form>
    );
};

// --- HISTORY FORM ---
interface HistoryFormProps {
    initialData?: HistoryEvent | null;
    onSave: (data: HistoryEvent) => void;
    onCancel: () => void;
}
export const HistoryForm: React.FC<HistoryFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<HistoryEvent>>({ year: '', title: '', description: '', iconType: 'fort', imageUrl: '' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            year: data.year!,
            title: data.title!,
            description: data.description!,
            iconType: data.iconType as any,
            imageUrl: data.imageUrl
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit History Event' : 'Add History Event'}</h3>
            <div className="grid grid-cols-3 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Year / Era</label>
                    <input required className="w-full border p-2 rounded" value={data.year} onChange={e => setData({...data, year: e.target.value})} placeholder="e.g. 15th Century" />
                </div>
                <div className="col-span-2">
                    <label className="block text-sm font-medium mb-1">Title</label>
                    <input required className="w-full border p-2 rounded" value={data.title} onChange={e => setData({...data, title: e.target.value})} placeholder="e.g. Construction of Fort" />
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea required rows={4} className="w-full border p-2 rounded" value={data.description} onChange={e => setData({...data, description: e.target.value})} />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Icon Type</label>
                    <select className="w-full border p-2 rounded" value={data.iconType} onChange={e => setData({...data, iconType: e.target.value as any})}>
                        <option value="fort">Fort/History</option>
                        <option value="train">Train/Transport</option>
                        <option value="war">War/Conflict</option>
                        <option value="ruler">Ruler/King</option>
                        <option value="industry">Industry</option>
                        <option value="agri">Agriculture</option>
                        <option value="govt">Government</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Image (Optional)</label>
                    <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
                </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Event</button>
            </div>
        </form>
    );
};

// --- TOURISM FORM ---
interface TourismFormProps {
    initialData?: TourismSpot | null;
    onSave: (data: TourismSpot) => void;
    onCancel: () => void;
}
export const TourismForm: React.FC<TourismFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<TourismSpot>>({ 
        name: '', 
        type: 'Temple', 
        location: '', 
        description: '', 
        highlights: '', 
        imageUrl: '',
        latitude: 0,
        longitude: 0
    });
    
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleGetLocation = () => {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition((position) => {
                setData(prev => ({
                    ...prev,
                    latitude: parseFloat(position.coords.latitude.toFixed(6)),
                    longitude: parseFloat(position.coords.longitude.toFixed(6))
                }));
            }, (error) => {
                alert('Error getting location: ' + error.message);
            });
        } else {
            alert('Geolocation is not supported by this browser.');
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            name: data.name!,
            type: data.type as any,
            location: data.location!,
            description: data.description!,
            highlights: data.highlights,
            imageUrl: data.imageUrl || 'https://picsum.photos/400/300',
            latitude: data.latitude,
            longitude: data.longitude
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit Spot' : 'Add Tourism Spot'}</h3>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1">Spot Name</label>
                    <input required className="w-full border p-2 rounded" value={data.name} onChange={e => setData({...data, name: e.target.value})} placeholder="e.g. Yaganti Temple" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select className="w-full border p-2 rounded" value={data.type} onChange={e => setData({...data, type: e.target.value as any})}>
                        <option value="Temple">Temple</option>
                        <option value="Fort">Fort</option>
                        <option value="Nature">Nature</option>
                        <option value="Landmark">Landmark</option>
                    </select>
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Location/Distance</label>
                <input required className="w-full border p-2 rounded" value={data.location} onChange={e => setData({...data, location: e.target.value})} placeholder="e.g. 42 km from Dhone" />
            </div>
            
            {/* GPS Section */}
            <div>
                 <div className="flex justify-between items-center mb-1">
                    <label className="block text-sm font-medium mb-1">GPS Coordinates (Optional)</label>
                    <button 
                        type="button" 
                        onClick={handleGetLocation}
                        className="text-xs bg-indigo-50 text-indigo-700 hover:bg-indigo-100 px-2 py-1 rounded flex items-center gap-1 transition-colors"
                    >
                        <IconMapPin className="w-3 h-3" /> Get Current Location
                    </button>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <input 
                        type="number" 
                        step="any" 
                        value={data.latitude || ''} 
                        onChange={e => setData({...data, latitude: parseFloat(e.target.value)})} 
                        placeholder="Latitude"
                        className="w-full border p-2 rounded" 
                    />
                    <input 
                        type="number" 
                        step="any" 
                        value={data.longitude || ''} 
                        onChange={e => setData({...data, longitude: parseFloat(e.target.value)})} 
                        placeholder="Longitude"
                        className="w-full border p-2 rounded" 
                    />
                 </div>
            </div>

            <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea required rows={3} className="w-full border p-2 rounded" value={data.description} onChange={e => setData({...data, description: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Highlights (Optional)</label>
                <input className="w-full border p-2 rounded" value={data.highlights} onChange={e => setData({...data, highlights: e.target.value})} placeholder="e.g. Best time to visit is Oct-Mar" />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Image</label>
                <ImageUpload value={data.imageUrl || ''} onChange={val => setData({...data, imageUrl: val})} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save Spot</button>
            </div>
        </form>
    );
};

// --- FM PROGRAM FORM ---
interface FMProgramFormProps {
    initialData?: FMProgram | null;
    onSave: (data: FMProgram) => void;
    onCancel: () => void;
}
export const FMProgramForm: React.FC<FMProgramFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<FMProgram>>({ time: '', title: '', host: '', active: true, audioUrl: '', videoUrl: '', status: 'approved' });
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setData(prev => ({ ...prev, audioUrl: reader.result as string }));
            reader.readAsDataURL(file);
        }
    };

    const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setData(prev => ({ ...prev, videoUrl: reader.result as string }));
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            time: data.time!,
            title: data.title!,
            host: data.host!,
            audioUrl: data.audioUrl,
            videoUrl: data.videoUrl,
            active: data.active !== undefined ? data.active : true,
            status: data.status || 'approved'
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-2xl shadow-xl max-w-lg mx-auto">
            <h3 className="font-black text-2xl text-gray-900 border-b pb-4">{initialData ? 'Edit FM Slot' : 'Add New FM Slot'}</h3>
            
            {/* Status Field (Admin Only) */}
            <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                <label className="block text-xs font-black text-yellow-800 uppercase tracking-widest mb-2">Program Status</label>
                <select 
                    className="w-full border border-yellow-300 p-2 rounded bg-white text-gray-800 font-bold"
                    value={data.status}
                    onChange={e => setData({...data, status: e.target.value as any})}
                >
                    <option value="pending">Pending Approval</option>
                    <option value="approved">Approved (Publicly Visible)</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>

            <div className="grid grid-cols-1 gap-4">
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Broadcast Time</label>
                    <input required className="w-full border-2 border-gray-100 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all" value={data.time} onChange={e => setData({...data, time: e.target.value})} placeholder="e.g. 09:00 AM" />
                </div>
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Program Title</label>
                    <input required className="w-full border-2 border-gray-100 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all" value={data.title} onChange={e => setData({...data, title: e.target.value})} placeholder="e.g. Morning Hits" />
                </div>
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-1">RJ / Host Name</label>
                    <input required className="w-full border-2 border-gray-100 p-3 rounded-xl focus:border-indigo-500 outline-none transition-all" value={data.host} onChange={e => setData({...data, host: e.target.value})} placeholder="e.g. RJ Priya" />
                </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-50">
                {/* Audio Section */}
                <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
                    <label className="block text-xs font-black text-indigo-400 uppercase tracking-widest mb-2">Program Audio (MP3, WAV, FLAC, M4A...)</label>
                    <div className="space-y-2">
                        <input 
                            type="url" 
                            className="w-full border border-indigo-100 p-2 rounded-lg text-xs" 
                            value={data.audioUrl} 
                            onChange={e => setData({...data, audioUrl: e.target.value})} 
                            placeholder="Paste Universal Audio URL" 
                        />
                        <label className="cursor-pointer bg-white border border-indigo-200 text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-50 flex items-center justify-center gap-2 transition-all shadow-sm text-xs font-bold">
                            <IconUpload className="w-4 h-4" />
                            {data.audioUrl?.startsWith('data:') ? 'HQ Audio File Uploaded' : 'Upload Any Format Audio'}
                            <input type="file" onChange={handleAudioUpload} className="hidden" accept="audio/*" />
                        </label>
                    </div>
                </div>

                {/* Video Section */}
                <div className="bg-pink-50/50 p-4 rounded-2xl border border-pink-100">
                    <label className="block text-xs font-black text-pink-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                        <IconFilm className="w-4 h-4" />
                        Program Video (Optional)
                    </label>
                    <div className="space-y-2">
                        <input 
                            type="url" 
                            className="w-full border border-pink-100 p-2 rounded-lg text-xs" 
                            value={data.videoUrl} 
                            onChange={e => setData({...data, videoUrl: e.target.value})} 
                            placeholder="Paste Video URL (MP4/WebM)" 
                        />
                        <label className="cursor-pointer bg-white border border-pink-200 text-pink-600 px-4 py-2 rounded-lg hover:bg-indigo-50 flex items-center justify-center gap-2 transition-all shadow-sm text-xs font-bold">
                            <IconUpload className="w-4 h-4" />
                            {data.videoUrl?.startsWith('data:') ? 'Video File Uploaded' : 'Upload Video File'}
                            <input type="file" onChange={handleVideoUpload} className="hidden" accept="video/*" />
                        </label>
                    </div>
                </div>

                {(data.audioUrl || data.videoUrl) && (
                    <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-xl text-[10px] font-black uppercase tracking-widest">
                        <IconPlay className="w-3 h-3 fill-current" /> Content Linked Ready
                    </div>
                )}
            </div>

            <div className="flex items-center gap-2 pt-2">
                <input 
                    type="checkbox" 
                    id="fm-active"
                    checked={data.active} 
                    onChange={e => setData({...data, active: e.target.checked})} 
                    className="h-4 w-4 text-indigo-600 rounded cursor-pointer"
                />
                <label htmlFor="fm-active" className="text-sm font-bold text-gray-600 cursor-pointer">Show in Schedule</label>
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
                <button type="button" onClick={onCancel} className="px-6 py-3 border-2 border-gray-100 rounded-xl text-gray-500 font-bold hover:bg-gray-50 transition-all">Cancel</button>
                <button type="submit" className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-black shadow-lg hover:bg-indigo-700 transition-all transform active:scale-95">Save Program</button>
            </div>
        </form>
    );
};

// --- USER FORM ---
interface UserFormProps {
    initialData?: User | null;
    onSave: (data: User) => void;
    onCancel: () => void;
}
export const UserForm: React.FC<UserFormProps> = ({ initialData, onSave, onCancel }) => {
    const [data, setData] = useState<Partial<User>>({ name: '', email: '', username: '', role: 'user', password: '' });
    // Fix: Corrected variable name from 'initialStats' to 'initialData'
    useEffect(() => { if (initialData) setData(initialData); }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: initialData?.id || Date.now().toString(),
            name: data.name!,
            email: data.email!,
            username: data.username!,
            role: data.role as 'user' | 'admin',
            password: data.password || initialData?.password || 'password123'
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md max-md mx-auto">
            <h3 className="font-bold text-lg">{initialData ? 'Edit User' : 'Add New User'}</h3>
            <div>
                <label className="block text-sm font-medium mb-1">Full Name</label>
                <input required className="w-full border p-2 rounded" value={data.name} onChange={e => setData({...data, name: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input required type="email" className="w-full border p-2 rounded" value={data.email} onChange={e => setData({...data, email: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Username</label>
                <input required className="w-full border p-2 rounded" value={data.username} onChange={e => setData({...data, username: e.target.value})} />
            </div>
            {initialData ? (
                <div className="bg-gray-50 p-2 rounded text-xs text-gray-500">
                    Password is not shown for security. Reset below if needed.
                </div>
            ) : (
                 <div>
                    <label className="block text-sm font-medium mb-1">Initial Password</label>
                    <input required className="w-full border p-2 rounded" type="password" value={data.password} onChange={e => setData({...data, password: e.target.value})} />
                </div>
            )}
            <div>
                <label className="block text-sm font-medium mb-1">Role</label>
                <select className="w-full border p-2 rounded" value={data.role} onChange={e => setData({...data, role: e.target.value as any})}>
                    <option value="user">Standard User</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Save User</button>
            </div>
        </form>
    );
};
