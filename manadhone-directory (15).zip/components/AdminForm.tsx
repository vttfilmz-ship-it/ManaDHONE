
import React, { useState, useEffect, useMemo } from 'react';
import { Business, Category } from '../types';
import { generateBusinessDescription, enhanceDescription, generateBusinessImage, generateFullBusinessDescription } from '../services/geminiService';
import { IconWand, IconMapPin, IconFacebook, IconInstagram, IconTwitter, IconClock, IconTrash, IconUpload, IconStar, IconEdit } from './Icons';

interface AdminFormProps {
  initialData?: Business | null;
  onSave: (data: Business) => void;
  onCancel: () => void;
}

const AdminForm: React.FC<AdminFormProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Partial<Business>>({
    name: '',
    category: Category.OTHER,
    phone: '',
    email: '',
    whatsapp: '',
    facebook: '',
    instagram: '',
    twitter: '',
    address: '',
    latitude: 0,
    longitude: 0,
    shortDescription: '',
    description: '',
    rating: 4.0,
    imageUrl: '',
    images: [],
    verified: false,
    isFeatured: false,
    openTime: '',
    closeTime: '',
    daysOpen: '',
    status: 'approved',
    reviews: []
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [keywords, setKeywords] = useState('');
  
  // Slider Preview State
  const [previewIndex, setPreviewIndex] = useState(0);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  // Combine Main Image and Gallery Images for Slider Preview
  const allImages = useMemo(() => {
      const main = formData.imageUrl ? [formData.imageUrl] : [];
      const gallery = formData.images || [];
      return [...main, ...gallery].filter(url => url && typeof url === 'string');
  }, [formData.imageUrl, formData.images]);

  // Auto-play slider in preview
  useEffect(() => {
      if (allImages.length < 2) return;
      const interval = setInterval(() => {
          setPreviewIndex(prev => (prev + 1) % allImages.length);
      }, 3000);
      return () => clearInterval(interval);
  }, [allImages.length]);

  // Reset index if out of bounds
  useEffect(() => {
      if (previewIndex >= allImages.length && allImages.length > 0) {
          setPreviewIndex(0);
      }
  }, [allImages.length, previewIndex]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  // Enhanced: Main Image upload now accepts multiple files to populate gallery too
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const fileList = Array.from(files);
      
      const readAsDataURL = (file: File) => new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
      });

      const processedImages = await Promise.all(fileList.map(readAsDataURL));
      
      setFormData(prev => {
          const mainImageUrl = processedImages[0];
          const remainingForGallery = processedImages.slice(1);
          
          return {
              ...prev,
              imageUrl: mainImageUrl,
              images: [...(prev.images || []), ...remainingForGallery]
          };
      });
    }
  };

  const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (files && files.length > 0) {
          const filePromises = Array.from(files).map((file: File) => {
              return new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onloadend = () => resolve(reader.result as string);
                  reader.readAsDataURL(file);
              });
          });
          
          const newBase64Images = await Promise.all(filePromises);
          setFormData(prev => ({
              ...prev,
              images: [...(prev.images || []), ...newBase64Images]
          }));
      }
  };

  const removeGalleryImage = (indexToRemove: number) => {
      setFormData(prev => ({
          ...prev,
          images: prev.images?.filter((_, index) => index !== indexToRemove)
      }));
  };

  const removeReview = (indexToRemove: number) => {
      if (window.confirm("Are you sure you want to delete this review?")) {
          setFormData(prev => ({
              ...prev,
              reviews: prev.reviews?.filter((_, index) => index !== indexToRemove)
          }));
      }
  };

  const handleGetLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setFormData(prev => ({
          ...prev,
          latitude: parseFloat(position.coords.latitude.toFixed(6)),
          longitude: parseFloat(position.coords.longitude.toFixed(6))
        }));
      }, (error) => {
        alert('Error getting location: ' + error.message);
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const handleGenerateDescription = async () => {
    if (!formData.name) {
      alert("Please enter a business name first.");
      return;
    }
    setIsGenerating(true);
    const desc = await generateBusinessDescription(
        formData.name!, 
        formData.category || Category.OTHER, 
        keywords || 'General Services in ManaDHONE'
    );
    setFormData(prev => ({ ...prev, shortDescription: desc }));
    setIsGenerating(false);
  };

  const handleEnhanceLongDescription = async () => {
    if (!formData.name) {
        alert("Please enter a business name.");
        return;
    }
    
    setIsGenerating(true);
    
    if (formData.description && formData.description.length > 10) {
        const improved = await enhanceDescription(formData.description, keywords);
        setFormData(prev => ({ ...prev, description: improved }));
    } else {
        const generated = await generateFullBusinessDescription(
            formData.name!, 
            formData.category || Category.OTHER, 
            keywords || 'Local services in ManaDHONE'
        );
        setFormData(prev => ({ ...prev, description: generated }));
    }
    
    setIsGenerating(false);
  };

  const handleGenerateImage = async () => {
    if (!formData.name) {
      alert("Please enter a business name to generate an image context.");
      return;
    }
    setIsGenerating(true);
    const context = keywords || formData.shortDescription || `A representative image for a ${formData.category} business`;
    const prompt = `
        Create a photorealistic, professional commercial placeholder image for a business directory.
        Business Name: "${formData.name}"
        Category: ${formData.category}
        Specific Context: ${context}
        Location Vibe: Busy, sunny Indian town (ManaDHONE), authentic, inviting.
        Style: Wide shot, eye-level, bright lighting. Show a modern storefront or a professional interior appropriate for this category.
    `;
    const base64Image = await generateBusinessImage(prompt);
    if (base64Image) {
        setFormData(prev => ({ ...prev, imageUrl: base64Image }));
    } else {
        alert("Could not generate image. Please ensure API Key is valid or try again.");
    }
    setIsGenerating(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    
    const finalData: Business = {
        id: formData.id || Date.now().toString(),
        createdAt: formData.createdAt || Date.now(),
        status: formData.status || 'approved',
        name: formData.name!,
        category: formData.category!,
        shortDescription: formData.shortDescription || '',
        description: formData.description || '',
        phone: formData.phone || '',
        email: formData.email || '',
        whatsapp: formData.whatsapp || '',
        facebook: formData.facebook || '',
        instagram: formData.instagram || '',
        twitter: formData.twitter || '',
        address: formData.address || '',
        latitude: formData.latitude || 0,
        longitude: formData.longitude || 0,
        imageUrl: formData.imageUrl || `https://picsum.photos/seed/${formData.name.replace(/\s/g, '')}/800/600`,
        images: formData.images || [],
        rating: formData.rating || 4.0,
        verified: formData.verified || false,
        isFeatured: formData.isFeatured || false,
        openTime: formData.openTime || '',
        closeTime: formData.closeTime || '',
        daysOpen: formData.daysOpen || '',
        reviews: formData.reviews || []
    };
    
    onSave(finalData);
  };

  return (
    <div className="bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl max-w-5xl mx-auto border border-gray-100">
      <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight">{initialData ? 'Edit Business' : 'Register New Business'}</h2>
            <p className="text-gray-500 font-medium">Populate your listing with rich media and AI-enhanced descriptions.</p>
          </div>
          <button onClick={onCancel} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          
          {/* Basic Info Section */}
          <div className="space-y-6">
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100 pb-2">Identity & Category</h3>
            <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Business Name</label>
                  <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all font-medium" placeholder="e.g. ManaDHONE Spice House" />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                  <select name="category" value={formData.category} onChange={handleChange} className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all font-medium appearance-none">
                    {Object.values(Category).map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
            </div>

            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100 pb-2 mt-8">Communication</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Phone</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all" />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">WhatsApp</label>
                  <input type="text" name="whatsapp" value={formData.whatsapp} onChange={handleChange} className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all" placeholder="91..." />
                </div>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all" placeholder="business@example.com" />
            </div>
          </div>

          {/* Location & Visibility Section */}
          <div className="space-y-6">
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100 pb-2">Map & Visibility</h3>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Physical Address</label>
              <input type="text" name="address" value={formData.address} onChange={handleChange} className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-indigo-500 outline-none transition-all" placeholder="Main Road, ManaDHONE" />
            </div>

            <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100">
                 <div className="flex justify-between items-center mb-4">
                    <label className="block text-sm font-bold text-gray-700">GPS Coordinates</label>
                    <button 
                        type="button" 
                        onClick={handleGetLocation}
                        className="text-xs bg-white text-indigo-600 border border-indigo-100 hover:bg-indigo-50 px-3 py-1.5 rounded-full font-bold flex items-center gap-1.5 transition-all shadow-sm"
                    >
                        <IconMapPin className="w-3 h-3" /> Pin Current Location
                    </button>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <input type="number" step="any" name="latitude" value={formData.latitude} onChange={handleChange} placeholder="Lat" className="w-full rounded-xl border-2 border-gray-100 p-3 outline-none focus:border-indigo-500 transition-all font-mono text-sm" />
                    <input type="number" step="any" name="longitude" value={formData.longitude} onChange={handleChange} placeholder="Long" className="w-full rounded-xl border-2 border-gray-100 p-3 outline-none focus:border-indigo-500 transition-all font-mono text-sm" />
                 </div>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-2">
                <label className="flex items-center gap-3 cursor-pointer group select-none">
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${formData.verified ? 'bg-indigo-600' : 'bg-gray-200'}`}>
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.verified ? 'left-7' : 'left-1'}`}></div>
                    </div>
                    <input type="checkbox" name="verified" checked={formData.verified} onChange={handleCheckboxChange} className="hidden" />
                    <span className="text-sm font-bold text-gray-600 group-hover:text-indigo-600">Verified</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer group select-none">
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${formData.isFeatured ? 'bg-amber-500' : 'bg-gray-200'}`}>
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.isFeatured ? 'left-7' : 'left-1'}`}></div>
                    </div>
                    <input type="checkbox" name="isFeatured" checked={formData.isFeatured} onChange={handleCheckboxChange} className="hidden" />
                    <span className="text-sm font-bold text-gray-600 group-hover:text-amber-600">Featured</span>
                </label>
            </div>
          </div>
        </div>
        
        {/* Operating Hours Section */}
        <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100">
            <h3 className="text-lg font-black text-slate-800 mb-6 flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-xl text-indigo-600"><IconClock className="w-5 h-5" /></div>
                Operating Hours
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase mb-2">Days Open</label>
                    <input type="text" name="daysOpen" value={formData.daysOpen} onChange={handleChange} placeholder="e.g. Mon - Sat" className="w-full p-4 rounded-2xl border-2 border-slate-200 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700" />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase mb-2">Opening Time</label>
                    <input type="time" name="openTime" value={formData.openTime} onChange={handleChange} className="w-full p-4 rounded-2xl border-2 border-slate-200 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700" />
                </div>
                <div>
                    <label className="block text-xs font-black text-slate-400 uppercase mb-2">Closing Time</label>
                    <input type="time" name="closeTime" value={formData.closeTime} onChange={handleChange} className="w-full p-4 rounded-2xl border-2 border-slate-200 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700" />
                </div>
            </div>
        </div>

        {/* Media Management Section */}
        <div className="space-y-8">
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100 pb-2">Business Media Assets</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Enhanced: Cover Image Selection with Preview and Multiple Support */}
                <div className="md:col-span-1">
                    <label className="block text-sm font-bold text-gray-700 mb-3">Cover Image (Featured)</label>
                    <div className="relative group aspect-[4/3] bg-gray-50 rounded-3xl overflow-hidden border-2 border-dashed border-gray-200 hover:border-indigo-400 transition-all cursor-pointer">
                        {formData.imageUrl ? (
                            <>
                                <img src={formData.imageUrl} alt="Main Preview" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-3">
                                    <label className="cursor-pointer bg-white text-gray-900 px-4 py-2 rounded-xl shadow-lg hover:scale-105 transition-transform flex items-center gap-2 font-bold text-xs">
                                        <IconEdit className="w-4 h-4" /> Replace / Add More
                                        <input type="file" multiple onChange={handleImageUpload} className="hidden" accept="image/*" />
                                    </label>
                                    <button 
                                        type="button"
                                        onClick={() => setFormData(prev => ({...prev, imageUrl: ''}))}
                                        className="bg-red-500 text-white p-2.5 rounded-xl shadow-lg hover:scale-105 transition-transform"
                                    >
                                        <IconTrash className="w-4 h-4" />
                                    </button>
                                </div>
                                <div className="absolute bottom-3 left-3 bg-indigo-600 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-tighter shadow-lg">Cover Photo</div>
                            </>
                        ) : (
                            <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer hover:bg-indigo-50/30 transition-colors">
                                <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-500">
                                    <IconUpload className="w-8 h-8 text-indigo-500" />
                                </div>
                                <span className="text-xs font-bold text-gray-500">Click to Upload Cover</span>
                                <span className="text-[10px] text-gray-400 mt-1 font-medium italic">Selecting multiple will populate gallery</span>
                                <input type="file" multiple onChange={handleImageUpload} className="hidden" accept="image/*" />
                            </label>
                        )}
                    </div>
                    <div className="mt-3">
                         <input 
                            type="text" 
                            name="imageUrl" 
                            value={formData.imageUrl} 
                            onChange={handleChange} 
                            className="w-full text-[10px] p-2 bg-gray-50 border border-gray-100 rounded-lg text-gray-400 outline-none font-mono" 
                            placeholder="Or paste asset URL here..." 
                        />
                    </div>
                    <button 
                        type="button" 
                        onClick={handleGenerateImage}
                        disabled={isGenerating}
                        className="mt-3 w-full py-3 border-2 border-purple-100 text-purple-600 rounded-2xl hover:bg-purple-50 transition-all font-bold text-xs flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        <IconWand className="w-4 h-4" /> {isGenerating ? 'Synthesizing...' : 'Generate Placeholder'}
                    </button>
                </div>

                {/* Additional Gallery */}
                <div className="md:col-span-2">
                    <label className="block text-sm font-bold text-gray-700 mb-3">Additional Gallery Images</label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {formData.images?.map((img, idx) => (
                            <div key={idx} className="relative group aspect-square bg-gray-100 rounded-2xl overflow-hidden border border-gray-100 shadow-sm transition-transform hover:scale-[1.02]">
                                <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                    <button 
                                        type="button"
                                        onClick={() => removeGalleryImage(idx)}
                                        className="bg-red-500 text-white p-2 rounded-xl shadow-lg hover:scale-110 transition-transform"
                                    >
                                        <IconTrash className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        ))}
                        <label className="cursor-pointer flex flex-col items-center justify-center aspect-square bg-gray-50 border-2 border-dashed border-gray-300 rounded-2xl hover:bg-indigo-50 hover:border-indigo-300 transition-all group">
                            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform mb-2">
                                <IconUpload className="w-6 h-6 text-gray-400 group-hover:text-indigo-500" />
                            </div>
                            <span className="text-[10px] text-gray-500 group-hover:text-indigo-600 font-black uppercase tracking-widest">Add Photos</span>
                            <input type="file" multiple onChange={handleGalleryUpload} className="hidden" accept="image/*" />
                        </label>
                    </div>
                </div>
            </div>
        </div>

        {/* AI & Content Section */}
        <div className="border-t border-gray-100 pt-10">
           <div className="flex items-center gap-3 mb-8">
             <div className="p-2 bg-purple-100 rounded-xl text-purple-600"><IconWand className="w-5 h-5" /></div>
             <h3 className="text-lg font-black text-gray-900">AI Content Optimization</h3>
           </div>
           
           <div className="space-y-6">
             <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Target Keywords / Services</label>
                <input 
                  type="text" 
                  value={keywords} 
                  onChange={(e) => setKeywords(e.target.value)} 
                  placeholder="e.g. Best Biryani, AC Rooms, 24/7 Service, Free Wi-Fi"
                  className="w-full rounded-2xl border-2 border-gray-100 p-4 focus:border-purple-500 outline-none transition-all font-medium"
                />
                <p className="text-[10px] text-gray-400 mt-2 italic">These keywords guide the AI in generating SEO-friendly descriptions for your listing.</p>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col">
                   <div className="flex justify-between items-center mb-4">
                      <label className="text-sm font-bold text-gray-700">Catchy Summary (Short)</label>
                      <button 
                        type="button" 
                        onClick={handleGenerateDescription}
                        disabled={isGenerating}
                        className="text-[10px] bg-purple-600 text-white hover:bg-purple-700 px-3 py-1.5 rounded-full font-black uppercase tracking-tighter transition-all disabled:opacity-50 shadow-md shadow-purple-100"
                      >
                        {isGenerating ? '...' : 'Auto-Gen'}
                      </button>
                   </div>
                   <textarea name="shortDescription" value={formData.shortDescription} onChange={handleChange} rows={3} className="w-full rounded-xl border-2 border-gray-50 p-4 outline-none focus:border-purple-500 transition-all font-medium text-sm flex-1 resize-none bg-gray-50/30" />
                </div>

                <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col">
                   <div className="flex justify-between items-center mb-4">
                      <label className="text-sm font-bold text-gray-700">Full Story (Long)</label>
                      <button 
                        type="button" 
                        onClick={handleEnhanceLongDescription}
                        disabled={isGenerating}
                        className="text-[10px] bg-purple-600 text-white hover:bg-purple-700 px-3 py-1.5 rounded-full font-black uppercase tracking-tighter transition-all disabled:opacity-50 shadow-md shadow-purple-100"
                      >
                        {isGenerating ? '...' : (formData.description ? 'Enhance' : 'Draft Full')}
                      </button>
                   </div>
                   <textarea name="description" value={formData.description} onChange={handleChange} rows={5} className="w-full rounded-xl border-2 border-gray-50 p-4 outline-none focus:border-purple-500 transition-all font-medium text-sm flex-1 resize-none bg-gray-50/30" />
                </div>
             </div>
           </div>
        </div>

        {/* Form Submission Controls */}
        <div className="flex flex-col sm:flex-row justify-end gap-4 pt-12 border-t border-gray-100">
            <button type="button" onClick={onCancel} className="px-10 py-4 border-2 border-gray-100 rounded-2xl shadow-sm text-sm font-bold text-gray-500 bg-white hover:bg-gray-50 transition-all active:scale-95">
                Discard Changes
            </button>
            <button type="submit" className="px-12 py-4 border-transparent rounded-2xl shadow-xl text-sm font-black text-white bg-indigo-600 hover:bg-indigo-700 transition-all transform hover:-translate-y-1 active:translate-y-0 shadow-indigo-200">
                {initialData ? 'Sync Updates' : 'Publish Business'}
            </button>
        </div>
      </form>
    </div>
  );
};

export default AdminForm;
