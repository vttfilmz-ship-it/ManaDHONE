
import React, { useState, useEffect } from 'react';
import { Advert } from '../types';

interface AdSliderProps {
    ads: Advert[];
}

const AdSlider: React.FC<AdSliderProps> = ({ ads }) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        if (ads.length <= 1) return;
        
        const interval = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % ads.length);
        }, 5000);
        return () => clearInterval(interval);
    }, [ads.length]);

    if (!ads.length) return null;

    return (
        <div className="relative w-full h-64 md:h-96 rounded-3xl overflow-hidden shadow-2xl my-8 group bg-slate-900 border border-white/10">
             {/* Slides */}
             {ads.map((ad, index) => (
                <div
                    key={ad.id}
                    className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                        index === currentIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
                    }`}
                >
                    {/* Zooming background image */}
                    <img 
                        src={ad.imageUrl} 
                        alt={ad.title} 
                        className={`w-full h-full object-cover transition-transform duration-[5000ms] ease-out ${
                            index === currentIndex ? 'scale-110' : 'scale-100'
                        }`} 
                    />
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent flex flex-col justify-end p-8 md:p-16">
                         <div className="max-w-4xl">
                             <span className={`bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase mb-4 inline-block tracking-widest transition-all duration-700 ease-out ${
                                 index === currentIndex ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
                             }`}>
                                 Sponsored Spotlight
                             </span>
                             
                             <h3 className={`text-white text-4xl md:text-6xl font-black mb-4 leading-tight transition-all duration-1000 cubic-bezier(0.16, 1, 0.3, 1) ${
                                 index === currentIndex 
                                    ? 'translate-y-0 opacity-100 scale-100' 
                                    : 'translate-y-12 opacity-0 scale-90'
                             }`}>
                                 {ad.title}
                             </h3>
                             
                             <p className={`text-gray-300 text-base md:text-xl font-medium leading-relaxed max-w-2xl transition-all duration-1000 delay-300 cubic-bezier(0.16, 1, 0.3, 1) ${
                                 index === currentIndex 
                                    ? 'translate-y-0 opacity-100' 
                                    : 'translate-y-10 opacity-0'
                             }`}>
                                 {ad.description}
                             </p>
                         </div>
                    </div>
                </div>
             ))}

             {/* Indicators */}
             <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 z-20">
                {ads.map((_, index) => (
                    <button
                        key={index}
                        onClick={() => setCurrentIndex(index)}
                        className={`h-2 rounded-full transition-all duration-500 border border-white/20 ${
                            index === currentIndex ? 'bg-white w-12 shadow-[0_0_15px_rgba(255,255,255,0.6)]' : 'bg-white/20 w-3 hover:bg-white/40'
                        }`}
                        aria-label={`Go to slide ${index + 1}`}
                    />
                ))}
             </div>
             
             {/* Enhanced Navigation Arrows */}
             <button 
                className="absolute left-6 top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-white/100 hover:text-indigo-900 backdrop-blur-xl text-white p-5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500 hover:scale-125 active:scale-90 border border-white/20 shadow-2xl hover:shadow-indigo-500/50"
                onClick={() => setCurrentIndex((prev) => (prev - 1 + ads.length) % ads.length)}
             >
                 <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
             </button>
             <button 
                className="absolute right-6 top-1/2 -translate-y-1/2 z-30 bg-white/5 hover:bg-white/100 hover:text-indigo-900 backdrop-blur-xl text-white p-5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500 hover:scale-125 active:scale-90 border border-white/20 shadow-2xl hover:shadow-indigo-500/50"
                onClick={() => setCurrentIndex((prev) => (prev + 1) % ads.length)}
             >
                 <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
             </button>
        </div>
    );
};

export default AdSlider;
