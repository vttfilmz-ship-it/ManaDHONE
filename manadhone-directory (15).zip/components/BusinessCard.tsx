
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Business } from '../types';
import { IconMapPin, IconPhone, IconStar, IconWhatsapp, IconBookmark } from './Icons';
import { isBusinessSaved, toggleSaveBusiness } from '../services/storageService';

interface BusinessCardProps {
  business: Business;
  onToggleSaved?: () => void;
}

const BusinessCard: React.FC<BusinessCardProps> = ({ business, onToggleSaved }) => {
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    setIsSaved(isBusinessSaved(business.id));
  }, [business.id]);

  const handleToggleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const result = toggleSaveBusiness(business.id);
    setIsSaved(result);
    if (onToggleSaved) onToggleSaved();
  };

  return (
    <Link 
      to={`/business/${business.id}`}
      className={`group bg-white dark:bg-slate-800 rounded-[2rem] shadow-soft hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 overflow-hidden cursor-pointer border flex flex-col h-full relative ${
        business.isFeatured 
          ? 'border-amber-200 dark:border-amber-900/50 ring-1 ring-amber-100 dark:ring-amber-900/20 shadow-amber-50 dark:shadow-none' 
          : 'border-slate-100 dark:border-slate-700/50 hover:border-indigo-200 dark:hover:border-indigo-900/50'
      }`}
    >
      <div className="relative h-56 overflow-hidden">
        <img 
          src={business.imageUrl || 'https://picsum.photos/400/300?grayscale'} 
          alt={business.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
            <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-slate-300 shadow-xl">
                {business.category}
            </div>
            {business.isFeatured && (
                <div className="bg-gradient-to-r from-amber-400 to-orange-500 text-white px-3 py-1 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl border border-white/20">
                    Featured
                </div>
            )}
        </div>

        <button 
            onClick={handleToggleSave}
            className={`absolute top-4 left-4 p-3 rounded-2xl shadow-2xl backdrop-blur-xl transition-all transform hover:scale-110 z-10 ${
              isSaved 
                ? 'bg-rose-500 text-white ring-2 ring-rose-300' 
                : 'bg-white/70 dark:bg-slate-900/70 text-slate-500 dark:text-slate-400 hover:text-rose-500 hover:bg-white dark:hover:bg-slate-800'
            }`}
        >
            <IconBookmark fill={isSaved} className="w-5 h-5" />
        </button>

        {business.verified && (
            <div className="absolute bottom-4 left-4 bg-indigo-600 text-white px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-2 z-10 border border-white/10">
                <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                Verified
            </div>
        )}
      </div>
      
      <div className="p-7 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-2xl font-black text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors line-clamp-1 tracking-tight">{business.name}</h3>
          <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-lg">
            <IconStar fill className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-black text-amber-700 dark:text-amber-400">{business.rating}</span>
          </div>
        </div>
        
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 line-clamp-2 flex-grow font-medium leading-relaxed">{business.shortDescription}</p>
        
        <div className="space-y-3 mt-auto border-t border-slate-50 dark:border-slate-700 pt-5">
          <div className="flex items-center gap-3 text-slate-400 dark:text-slate-500 text-xs font-bold">
            <IconMapPin className="w-4 h-4 text-indigo-500" />
            <span className="truncate">{business.address}</span>
          </div>
          <div className="flex items-center gap-3 text-slate-400 dark:text-slate-500 text-xs font-bold">
            <IconPhone className="w-4 h-4 text-emerald-500" />
            <span>{business.phone}</span>
          </div>
        </div>
        
        <div className="mt-6 flex gap-3">
            <div className={`flex-1 text-[10px] font-black uppercase tracking-[0.2em] py-4 rounded-2xl transition-all flex items-center justify-center border ${business.isFeatured ? 'bg-amber-500 text-white border-amber-400 shadow-xl shadow-amber-200 dark:shadow-none' : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white shadow-xl shadow-slate-200 dark:shadow-none'} hover:scale-[1.02] active:scale-95`}>
                View Profile
            </div>
            {business.whatsapp && (
                 <button 
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        window.open(`https://wa.me/${business.whatsapp}`, '_blank');
                    }}
                    className="w-14 flex items-center justify-center bg-emerald-50 dark:bg-emerald-900/20 hover:bg-emerald-600 hover:text-white text-emerald-600 dark:text-emerald-400 rounded-2xl transition-all border border-emerald-100 dark:border-emerald-800/50 shadow-sm"
                 >
                    <IconWhatsapp className="w-6 h-6" />
                 </button>
            )}
        </div>
      </div>
    </Link>
  );
};

export default BusinessCard;
