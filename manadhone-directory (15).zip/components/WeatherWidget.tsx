
import React, { useEffect, useState } from 'react';
import { getWeather } from '../services/storageService';
import { WeatherData } from '../types';
import { IconSun, IconCloud } from './Icons';

const WeatherWidget: React.FC = () => {
    const [weather, setWeather] = useState<WeatherData | null>(null);

    useEffect(() => {
        getWeather().then(setWeather);
    }, []);

    if (!weather) return null;

    return (
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-4 text-white flex items-center gap-4">
            <div>
                {weather.condition === 'Sunny' ? <IconSun className="w-10 h-10 text-yellow-400" /> : <IconCloud className="w-10 h-10 text-gray-300" />}
            </div>
            <div>
                <div className="text-2xl font-bold">{weather.temp}°C</div>
                <div className="text-xs opacity-80">{weather.condition} • H: {weather.humidity}%</div>
            </div>
        </div>
    );
};

export default WeatherWidget;
