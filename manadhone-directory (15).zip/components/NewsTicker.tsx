import React from 'react';
import { NewsItem } from '../types';

interface NewsTickerProps {
    news: NewsItem[];
}

const NewsTicker: React.FC<NewsTickerProps> = ({ news }) => {
    if (!news || news.length === 0) return null;

    return (
        <div className="bg-red-600 text-white h-10 flex items-center relative overflow-hidden shadow-sm border-b border-red-700 z-20">
            {/* Badge */}
            <div className="bg-red-800 h-full px-4 flex items-center justify-center font-bold text-xs md:text-sm uppercase tracking-wider shrink-0 z-10 shadow-lg relative">
                <span className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></span>
                Live News
                <div className="absolute right-0 top-0 bottom-0 w-4 bg-gradient-to-r from-red-800 to-transparent translate-x-full"></div>
            </div>

            {/* Scrolling Content */}
            <div className="flex-1 relative h-full overflow-hidden">
                <div className="animate-marquee absolute top-0 bottom-0 flex items-center whitespace-nowrap will-change-transform">
                    {news.map((item, index) => (
                        <React.Fragment key={item.id}>
                            <span className="inline-flex items-center mx-8 text-sm font-medium">
                                <span className="text-red-200 mr-2">[{new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]</span>
                                <span className="font-bold mr-2">{item.title}:</span>
                                <span className="text-red-50">{item.summary}</span>
                            </span>
                            <span className="w-1.5 h-1.5 bg-red-400 rounded-full opacity-50"></span>
                        </React.Fragment>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default NewsTicker;