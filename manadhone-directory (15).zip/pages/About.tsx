import React from 'react';
import { IconMail, IconMapPin, IconPhone } from '../components/Icons';

const About: React.FC = () => {
    return (
        <div className="bg-gray-50 min-h-screen py-12">
            <div className="container mx-auto px-4 max-w-4xl">
                {/* Hero Section */}
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6">
                        About <span className="text-indigo-600">ManaDHONE</span>
                    </h1>
                    <p className="text-xl text-gray-600 leading-relaxed max-w-2xl mx-auto">
                        Connecting the community, one business at a time. We are the digital heartbeat of our town.
                    </p>
                </div>

                {/* Mission Card */}
                <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-12">
                    <div className="md:flex">
                        <div className="md:w-1/2 bg-indigo-600 p-10 flex flex-col justify-center text-white">
                            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
                            <p className="text-indigo-100 text-lg leading-relaxed">
                                To provide a comprehensive, accessible, and up-to-date digital platform for the residents and visitors of ManaDHONE. We aim to empower local businesses by giving them a digital presence while helping citizens find what they need instantly.
                            </p>
                        </div>
                        <div className="md:w-1/2 relative h-64 md:h-auto">
                            <img 
                                src="https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=2669&auto=format&fit=crop" 
                                alt="Community" 
                                className="absolute inset-0 w-full h-full object-cover"
                            />
                        </div>
                    </div>
                </div>

                {/* Content Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
                    <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                        <h3 className="text-2xl font-bold text-gray-900 mb-4">For Businesses</h3>
                        <p className="text-gray-600 mb-4">
                            Are you a local business owner? Join ManaDHONE to reach thousands of local customers. 
                            Showcase your products, services, and offers to the people who matter most - your neighbors.
                        </p>
                        <ul className="space-y-2 text-gray-600">
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-green-500 rounded-full"></span> Free Basic Listing
                            </li>
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-green-500 rounded-full"></span> GPS Location tagging
                            </li>
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-green-500 rounded-full"></span> Direct Customer Reviews
                            </li>
                        </ul>
                    </div>

                    <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                        <h3 className="text-2xl font-bold text-gray-900 mb-4">For Residents</h3>
                        <p className="text-gray-600 mb-4">
                            Find everything you need in town without hassle. From the nearest pharmacy open at midnight to the best biryani spot for Sunday lunch.
                        </p>
                        <ul className="space-y-2 text-gray-600">
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-blue-500 rounded-full"></span> Verified Business Information
                            </li>
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-blue-500 rounded-full"></span> Daily Local News Updates
                            </li>
                            <li className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-blue-500 rounded-full"></span> Emergency Contacts
                            </li>
                        </ul>
                    </div>
                </div>

                {/* Contact Section */}
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-gray-900 mb-8">Get in Touch</h2>
                    <div className="flex flex-col md:flex-row justify-center gap-8">
                        <div className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm border border-gray-100 w-full md:w-64">
                            <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mb-4">
                                <IconMail className="w-6 h-6" />
                            </div>
                            <h4 className="font-bold text-gray-900 mb-1">Email Us</h4>
                            <p className="text-gray-500 text-sm">contact@manadhone.com</p>
                        </div>
                        <div className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm border border-gray-100 w-full md:w-64">
                            <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600 mb-4">
                                <IconPhone className="w-6 h-6" />
                            </div>
                            <h4 className="font-bold text-gray-900 mb-1">Call Us</h4>
                            <p className="text-gray-500 text-sm">+91 98765 00000</p>
                        </div>
                        <div className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm border border-gray-100 w-full md:w-64">
                            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center text-red-600 mb-4">
                                <IconMapPin className="w-6 h-6" />
                            </div>
                            <h4 className="font-bold text-gray-900 mb-1">Visit Us</h4>
                            <p className="text-gray-500 text-sm">Municipal Complex, ManaDHONE</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default About;