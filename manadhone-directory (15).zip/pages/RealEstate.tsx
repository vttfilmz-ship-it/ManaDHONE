
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { getProperties, getAgents, getAds, getHeroSlides, saveProperty } from '../services/storageService';
import { Property, RealEstateAgent, Advert, HeroSlide } from '../types';
import AdSlider from '../components/AdSlider';
import { IconHome, IconMapPin, IconPhone, IconSearch, IconFilter, IconBriefcase, IconStar, IconTrendingUp, IconEdit, IconUpload, IconClock, IconTrash, IconBed, IconBath, IconCar, IconCheck, IconSend } from '../components/Icons';

const RealEstate: React.FC = () => {
    const [properties, setProperties] = useState<Property[]>([]);
    const [agents, setAgents] = useState<RealEstateAgent[]>([]);
    const [ads, setAds] = useState<Advert[]>([]);
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    const [search, setSearch] = useState('');
    const [filterPurpose, setFilterPurpose] = useState<'All' | 'Sale' | 'Rent'>('All');
    const [filterType, setFilterType] = useState<string>('All');

    // User submission modal
    const [isPostModalOpen, setIsPostModalOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);

    const [newProperty, setNewProperty] = useState<Partial<Property>>({
        title: '', 
        type: 'Plot', 
        purpose: 'Sale', 
        price: '', 
        area: '', 
        location: '', 
        description: '', 
        imageUrl: '',
        images: [],
        bedrooms: 0,
        bathrooms: 0,
        parking: false,
        amenities: [],
        featured: false
    });

    const commonAmenities = ["CCTV", "24/7 Water", "Power Backup", "Lift", "Garden", "Security", "Parking", "Vaastu Compliant", "Borewell"];

    useEffect(() => {
        setProperties(getProperties());
        setAgents(getAgents());
        setAds(getAds().filter(ad => ad.page === 'realestate'));
        setHeroSlides(getHeroSlides().filter(s => s.page === 'realestate' && s.active));
    }, []);

    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    const filteredProperties = useMemo(() => {
        // Map items to include original admin index for priority tie-breaking
        const itemsWithMeta = properties.map((p, index) => ({ p, originalIndex: index }));
        
        let result = itemsWithMeta.filter(item => {
            const isApproved = item.p.status === 'available' || item.p.status === 'sold';
            const matchesSearch = !search || item.p.title.toLowerCase().includes(search.toLowerCase()) || 
                                  item.p.location.toLowerCase().includes(search.toLowerCase()) ||
                                  item.p.description?.toLowerCase().includes(search.toLowerCase());
            const matchesPurpose = filterPurpose === 'All' || item.p.purpose === filterPurpose;
            const matchesType = filterType === 'All' || item.p.type === filterType;
            return isApproved && matchesSearch && matchesPurpose && matchesType;
        });

        // Multi-tier sort
        result.sort((a, b) => {
            // Tier 1: Featured/Priority status
            if (a.p.featured && !b.p.featured) return -1;
            if (!a.p.featured && b.p.featured) return 1;

            // Tier 2: Search Score (if searching) - simplified here to admin manual order
            // Tier 3: Admin Manual Order (the tie-breaker)
            return a.originalIndex - b.originalIndex;
        });

        return result.map(item => item.p);
    }, [properties, search, filterPurpose, filterType]);

    const hasActiveFilters = search !== '' || filterPurpose !== 'All' || filterType !== 'All';

    const clearFilters = () => {
        setSearch('');
        setFilterPurpose('All');
        setFilterType('All');
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const fileList = Array.from(files);
            const readAsDataURL = (file: File) => new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result as string);
                reader.readAsDataURL(file);
            });

            const processedImages = await Promise.all(fileList.map(readAsDataURL));
            
            setNewProperty(prev => {
                const updatedImages = [...(prev.images || []), ...processedImages];
                return {
                    ...prev,
                    images: updatedImages,
                    imageUrl: prev.imageUrl || updatedImages[0]
                };
            });
        }
    };

    const removePhoto = (index: number) => {
        setNewProperty(prev => {
            const updated = (prev.images || []).filter((_, i) => i !== index);
            return {
                ...prev,
                images: updated,
                imageUrl: prev.imageUrl === (prev.images || [])[index] ? (updated[0] || '') : prev.imageUrl
            };
        });
    };

    const toggleAmenity = (amenity: string) => {
        setNewProperty(prev => {
            const current = prev.amenities || [];
            if (current.includes(amenity)) {
                return { ...prev, amenities: current.filter(a => a !== amenity) };
            } else {
                return { ...prev, amenities: [...current, amenity] };
            }
        });
    };

    const handlePostProperty = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newProperty.title || !newProperty.price) {
            alert("Please provide at least a title and price.");
            return;
        }

        setIsSubmitting(true);

        const propertyToSave: Property = {
            id: Date.now().toString(),
            status: 'pending',
            title: newProperty.title || 'Untitled Property',
            type: (newProperty.type as any) || 'Plot',
            purpose: (newProperty.purpose as any) || 'Sale',
            price: newProperty.price || 'Contact for Price',
            area: newProperty.area || 'N/A',
            location: newProperty.location || 'Dhone',
            description: newProperty.description || '',
            imageUrl: newProperty.imageUrl || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=2573&auto=format&fit=crop',
            images: newProperty.images || [],
            createdAt: Date.now(),
            bedrooms: newProperty.bedrooms,
            bathrooms: newProperty.bathrooms,
            parking: newProperty.parking,
            amenities: newProperty.amenities || [],
            featured: false
        };

        // Simulate network delay
        setTimeout(() => {
            saveProperty(propertyToSave);
            setIsSubmitting(false);
            setIsSuccess(true);
            setProperties(getProperties());
        }, 800);
    };

    const resetForm = () => {
        setNewProperty({ title: '', type: 'Plot', purpose: 'Sale', price: '', area: '', location: '', description: '', imageUrl: '', images: [], bedrooms: 0, bathrooms: 0, parking: false, amenities: [], featured: false });
        setIsSuccess(false);
        setIsPostModalOpen(false);
    };

    const goToPrevHero = () => setCurrentSlide(prev => (prev - 1 + heroSlides.length) % heroSlides.length);
    const goToNextHero = () => setCurrentSlide(prev => (prev + 1) % heroSlides.length);

    return (
        <div className="bg-slate-50 dark:bg-slate-950 min-h-screen pb-20 transition-colors duration-300">
            {/* Real Estate Hero Slider */}
            <div className="relative h-[450px] md:h-[550px] bg-slate-900 overflow-hidden group">
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, idx) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-all duration-1000 ease-in-out ${idx === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover opacity-50" alt={slide.caption} />
                            <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-transparent to-slate-950/80"></div>
                            
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
                                <div className={`transition-all duration-1000 transform ${idx === currentSlide ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                                    <span className="inline-block bg-amber-500 text-slate-950 text-[10px] font-black uppercase tracking-[0.4em] px-4 py-1.5 rounded-full mb-6 shadow-xl shadow-amber-500/20">
                                        Premium Real Estate
                                    </span>
                                    <h1 className="text-4xl md:text-7xl font-black text-white mb-6 tracking-tighter drop-shadow-2xl">
                                        {slide.caption}
                                    </h1>
                                    <p className="text-lg md:text-xl text-slate-200 max-w-2xl mx-auto font-medium drop-shadow-lg">
                                        Connecting buyers and sellers across ManaDHONE.
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="absolute inset-0">
                         <img src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=2573&auto=format&fit=crop" className="w-full h-full object-cover opacity-40" alt="Real Estate" />
                         <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-transparent to-slate-950/80"></div>
                    </div>
                )}

                {/* Hero Controls */}
                {heroSlides.length > 1 && (
                    <>
                        <button 
                            onClick={goToPrevHero}
                            className="absolute left-6 top-1/2 -translate-y-1/2 z-30 p-4 rounded-full bg-white/5 border border-white/10 text-white backdrop-blur-xl hover:bg-white hover:text-slate-900 transition-all opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"></path></svg>
                        </button>
                        <button 
                            onClick={goToNextHero}
                            className="absolute right-6 top-1/2 -translate-y-1/2 z-30 p-4 rounded-full bg-white/5 border border-white/10 text-white backdrop-blur-xl hover:bg-white hover:text-slate-900 transition-all opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"></path></svg>
                        </button>

                        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-3 z-30">
                            {heroSlides.map((_, i) => (
                                <button
                                    key={i}
                                    onClick={() => setCurrentSlide(i)}
                                    className={`h-1 transition-all duration-500 rounded-full ${i === currentSlide ? 'bg-amber-500 w-8' : 'bg-white/20 w-3'}`}
                                />
                            ))}
                        </div>
                    </>
                )}
            </div>

            {/* --- Dedicated Search & Action Section --- */}
            <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-white/5 py-12 relative z-30 shadow-sm transition-colors duration-300">
                <div className="container mx-auto px-4">
                    <div className="max-w-5xl mx-auto flex flex-col gap-8">
                        <div className="bg-slate-50 dark:bg-white/5 p-2 rounded-[2.5rem] shadow-inner flex flex-col md:flex-row gap-2 border border-slate-200/50 dark:border-white/10 overflow-hidden transition-colors duration-300">
                            <div className="flex-1 flex items-center px-6">
                                <IconSearch className="w-6 h-6 text-indigo-400" />
                                <input 
                                    type="text" 
                                    placeholder="Search by area, location or property name..." 
                                    className="w-full p-5 bg-transparent outline-none text-slate-800 dark:text-white font-bold text-lg"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                            </div>
                            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-black px-12 py-5 md:py-0 rounded-[2rem] transition-all shadow-xl shadow-indigo-600/20 active:scale-95 text-sm uppercase tracking-widest">
                                Search Properties
                            </button>
                        </div>
                        
                        <div className="flex justify-center">
                            <button 
                                onClick={() => setIsPostModalOpen(true)}
                                className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-10 py-4 rounded-full font-black inline-flex items-center gap-3 transition-all active:scale-95 shadow-xl shadow-amber-500/20 uppercase tracking-widest text-xs"
                            >
                                <IconEdit className="w-5 h-5" /> Post Your Property Listing
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 mt-12 relative z-20">
                <AdSlider ads={ads} />

                {/* --- FILTER BAR --- */}
                <div className="mt-12 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-white/5 flex flex-col lg:flex-row items-center gap-8 transition-colors duration-300">
                    <div className="flex flex-col md:flex-row items-center gap-6 w-full lg:w-auto">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] whitespace-nowrap">Purpose</span>
                        <div className="flex p-1 bg-slate-100 dark:bg-white/5 rounded-2xl w-full md:w-auto">
                            {(['All', 'Sale', 'Rent'] as const).map(p => (
                                <button
                                    key={p}
                                    onClick={() => setFilterPurpose(p)}
                                    className={`flex-1 md:px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                                        filterPurpose === p 
                                        ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-md scale-105' 
                                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
                                    }`}
                                >
                                    {p === 'All' ? 'Any' : `For ${p}`}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="h-px lg:h-12 w-full lg:w-px bg-slate-100 dark:bg-white/10"></div>

                    <div className="flex flex-col md:flex-row items-center gap-6 flex-1 w-full overflow-hidden">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] whitespace-nowrap">Type</span>
                        <div className="flex gap-2 overflow-x-auto no-scrollbar w-full p-1">
                            {['All', 'House', 'Plot', 'Commercial', 'Apartment'].map(type => (
                                <button
                                    key={type}
                                    onClick={() => setFilterType(type)}
                                    className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shrink-0 border ${
                                        filterType === type 
                                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white shadow-lg' 
                                        : 'bg-white dark:bg-transparent border-slate-200 dark:border-white/10 text-slate-500 hover:border-slate-400'
                                    }`}
                                >
                                    {type === 'All' ? 'All Types' : type}
                                </button>
                            ))}
                        </div>
                    </div>

                    {hasActiveFilters && (
                        <button 
                            onClick={clearFilters}
                            className="text-[10px] font-black text-red-500 hover:text-red-600 uppercase tracking-widest flex items-center gap-1.5 transition-colors whitespace-nowrap bg-red-50 dark:bg-red-500/10 px-4 py-2 rounded-xl"
                        >
                            Reset &times;
                        </button>
                    )}
                </div>

                {/* Property Grid */}
                <div className="mt-16">
                    <div className="flex justify-between items-center mb-10 px-2">
                        <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Verified Listings</h2>
                        <div className="text-xs font-bold text-slate-400 bg-slate-100 dark:bg-white/5 px-3 py-1 rounded-full">
                            {filteredProperties.length} Properties Found
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredProperties.length > 0 ? filteredProperties.map(prop => (
                            <div key={prop.id} className={`bg-white dark:bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-2xl border transition-all group flex flex-col h-full ${prop.featured ? 'border-amber-400 ring-1 ring-amber-100' : 'border-slate-100 dark:border-white/5'}`}>
                                <div className="relative h-64 overflow-hidden">
                                    <img src={prop.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={prop.title} />
                                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                                        <span className="bg-white/90 backdrop-blur px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest text-slate-900 shadow-xl w-fit">
                                            For {prop.purpose}
                                        </span>
                                        {prop.featured && (
                                            <span className="bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-4 py-1.5 rounded-full shadow-xl w-fit">
                                                Featured
                                            </span>
                                        )}
                                    </div>
                                    <div className="absolute bottom-4 right-4 bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 px-5 py-2 rounded-2xl font-black text-xl shadow-2xl">
                                        {prop.price}
                                    </div>
                                </div>
                                <div className="p-8 flex-1 flex flex-col">
                                    <div className="flex items-center gap-2 text-amber-500 text-[10px] font-black uppercase tracking-widest mb-3">
                                        <IconHome className="w-3 h-3" /> {prop.type}
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 leading-tight line-clamp-2">{prop.title}</h3>
                                    <div className="flex items-center gap-1.5 text-slate-500 text-sm mb-6">
                                        <IconMapPin className="w-4 h-4 text-red-500" /> {prop.location}
                                    </div>
                                    
                                    {/* Feature Bar */}
                                    <div className="flex gap-4 mb-6 pb-6 border-b border-slate-50 dark:border-white/5">
                                        {(prop.type === 'House' || prop.type === 'Apartment') && (
                                            <>
                                                <div className="flex items-center gap-1.5 text-slate-500">
                                                    <IconBed className="w-4 h-4 text-indigo-500" />
                                                    <span className="text-xs font-bold">{prop.bedrooms || 0} Beds</span>
                                                </div>
                                                <div className="flex items-center gap-1.5 text-slate-500">
                                                    <IconBath className="w-4 h-4 text-teal-500" />
                                                    <span className="text-xs font-bold">{prop.bathrooms || 0} Baths</span>
                                                </div>
                                            </>
                                        )}
                                        {prop.parking && (
                                            <div className="flex items-center gap-1.5 text-slate-500">
                                                <IconCar className="w-4 h-4 text-amber-500" />
                                                <span className="text-xs font-bold">Parking</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="grid grid-cols-2 gap-4 mb-8">
                                        <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-slate-100 dark:border-white/5">
                                            <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Area</span>
                                            <span className="text-sm font-bold text-slate-800 dark:text-slate-200">{prop.area}</span>
                                        </div>
                                        <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-slate-100 dark:border-white/5">
                                            <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Status</span>
                                            <span className={`text-sm font-black uppercase ${prop.status === 'available' ? 'text-green-600' : 'text-orange-500'}`}>
                                                {prop.status}
                                            </span>
                                        </div>
                                    </div>

                                    <div className="mt-auto pt-6 border-t border-slate-50 dark:border-white/5 flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            {prop.agentId ? (
                                                <>
                                                    {agents.find(a => a.id === prop.agentId)?.imageUrl && (
                                                        <img src={agents.find(a => a.id === prop.agentId)?.imageUrl} className="w-8 h-8 rounded-full object-cover border border-slate-200" alt="Agent" />
                                                    )}
                                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expert Advice</span>
                                                </>
                                            ) : (
                                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Direct Seller</span>
                                            )}
                                        </div>
                                        <Link to={`/property/${prop.id}`} className="text-amber-500 font-black text-xs uppercase tracking-[0.2em] flex items-center gap-2 group/btn cursor-pointer">
                                            View
                                            <span className="w-6 h-px bg-amber-500 group-hover/btn:w-10 transition-all"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        )) : (
                            <div className="col-span-full py-24 text-center bg-white dark:bg-slate-900 rounded-[4rem] border-2 border-dashed border-slate-200 dark:border-white/5">
                                <div className="w-20 h-20 bg-slate-100 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                                    <IconSearch className="w-10 h-10 text-gray-300" />
                                </div>
                                <h3 className="text-2xl font-black text-slate-800 dark:text-white">No properties found</h3>
                                <p className="text-slate-500 mt-2">Adjust your filters or try a different search term.</p>
                                <button onClick={clearFilters} className="mt-8 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">Clear All Filters</button>
                            </div>
                        )}
                    </div>
                </div>

                {/* Agents Section */}
                <div className="mt-32 pb-20">
                    <div className="text-center mb-16">
                        <span className="text-amber-500 text-xs font-black uppercase tracking-[0.3em] mb-4 inline-block">Local Experts</span>
                        <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter">Verified Agents</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                        {agents.map(agent => (
                            <div key={agent.id} className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-xl flex flex-col sm:flex-row items-center gap-8 group transition-colors duration-300">
                                <div className="relative shrink-0">
                                    <div className="absolute -inset-2 bg-gradient-to-tr from-amber-400 to-orange-500 rounded-[2.5rem] blur-xl opacity-0 group-hover:opacity-20 transition-opacity"></div>
                                    <img src={agent.imageUrl} className="relative w-40 h-40 rounded-[2.5rem] object-cover shadow-2xl border-4 border-white dark:border-slate-800" alt={agent.name} />
                                    {agent.verified && (
                                        <div className="absolute -bottom-2 -right-2 bg-blue-500 text-white p-2 rounded-full shadow-lg">
                                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.64.304 1.24.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"></path></svg>
                                        </div>
                                    )}
                                </div>
                                <div className="text-center sm:text-left flex-1">
                                    <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-1">{agent.name}</h3>
                                    <p className="text-amber-500 font-bold text-sm mb-4">{agent.agency}</p>
                                    <p className="text-slate-500 text-sm leading-relaxed mb-6 font-medium italic">"{agent.bio}"</p>
                                    
                                    <div className="flex flex-col sm:flex-row gap-4">
                                        <div className="flex-1 bg-slate-50 dark:bg-white/5 p-3 rounded-2xl border border-slate-100 dark:border-white/5">
                                            <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Exp.</span>
                                            <span className="text-xs font-black text-slate-700 dark:text-slate-300">{agent.experience}</span>
                                        </div>
                                        <a href={`tel:${agent.phone}`} className="flex-[2] bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black py-3 px-6 rounded-2xl text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95">
                                            <IconPhone className="w-4 h-4" /> Call
                                        </a>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Post Property Modal */}
            {isPostModalOpen && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
                        <div className="bg-amber-500 p-8 text-slate-900 flex justify-between items-center shrink-0">
                            <div>
                                <h3 className="text-2xl font-black">List Your Property</h3>
                                <p className="text-amber-900 text-sm font-medium mt-1">Submit your details for verification.</p>
                            </div>
                            <button onClick={resetForm} className="bg-black/10 hover:bg-black/20 p-2 rounded-full transition-colors text-slate-900">
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        
                        <div className="p-8 overflow-y-auto custom-scrollbar">
                            {isSuccess ? (
                                <div className="py-12 text-center animate-in zoom-in duration-500">
                                    <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-green-100">
                                        <IconCheck className="w-10 h-10" />
                                    </div>
                                    <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-4">Submission Sent!</h3>
                                    <p className="text-slate-500 max-w-sm mx-auto mb-10 leading-relaxed">
                                        Your listing has been submitted for review. It will appear on the platform once verified by our admin.
                                    </p>
                                    <button 
                                        onClick={resetForm}
                                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-4 rounded-2xl font-black shadow-lg transition-all active:scale-95"
                                    >
                                        Back to Listings
                                    </button>
                                </div>
                            ) : (
                                <form onSubmit={handlePostProperty} className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Property Name*</label>
                                            <input 
                                                required
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 transition-all font-bold" 
                                                value={newProperty.title} 
                                                onChange={e => setNewProperty({...newProperty, title: e.target.value})}
                                                placeholder="e.g. 150Sqyd Plot in Boyanapalli"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Category</label>
                                            <select 
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none appearance-none font-bold" 
                                                value={newProperty.type} 
                                                onChange={e => setNewProperty({...newProperty, type: e.target.value as any})}
                                            >
                                                <option value="Plot">Plot</option>
                                                <option value="House">House</option>
                                                <option value="Apartment">Apartment</option>
                                                <option value="Commercial">Commercial</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Market Action</label>
                                            <select 
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none appearance-none font-bold" 
                                                value={newProperty.purpose} 
                                                onChange={e => setNewProperty({...newProperty, purpose: e.target.value as any})}
                                            >
                                                <option value="Sale">For Sale</option>
                                                <option value="Rent">For Rent</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Expected Price*</label>
                                            <input 
                                                required
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 transition-all font-bold" 
                                                value={newProperty.price} 
                                                onChange={e => setNewProperty({...newProperty, price: e.target.value})}
                                                placeholder="e.g. ₹20 Lakhs"
                                            />
                                        </div>
                                    </div>

                                    {/* Feature Inputs */}
                                    {(newProperty.type === 'House' || newProperty.type === 'Apartment') && (
                                        <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-3xl space-y-6">
                                            <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">Residential Specifications</h4>
                                            <div className="grid grid-cols-3 gap-4">
                                                <div>
                                                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2">Bedrooms</label>
                                                    <input 
                                                        type="number" 
                                                        className="w-full p-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 dark:text-white outline-none font-bold"
                                                        value={newProperty.bedrooms}
                                                        onChange={e => setNewProperty({...newProperty, bedrooms: parseInt(e.target.value) || 0})}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2">Bathrooms</label>
                                                    <input 
                                                        type="number" 
                                                        className="w-full p-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 dark:text-white outline-none font-bold"
                                                        value={newProperty.bathrooms}
                                                        onChange={e => setNewProperty({...newProperty, bathrooms: parseInt(e.target.value) || 0})}
                                                    />
                                                </div>
                                                <div className="flex flex-col justify-end items-center">
                                                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 text-center w-full">Parking</label>
                                                    <button 
                                                        type="button"
                                                        onClick={() => setNewProperty({...newProperty, parking: !newProperty.parking})}
                                                        className={`w-full p-3 rounded-xl border-2 transition-all font-bold ${newProperty.parking ? 'bg-amber-500 border-amber-500 text-slate-900' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'}`}
                                                    >
                                                        {newProperty.parking ? 'Yes' : 'No'}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Amenities Picker */}
                                    <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-3xl space-y-4">
                                        <h4 className="text-xs font-black text-teal-500 uppercase tracking-widest flex items-center gap-2">
                                            <IconCheck className="w-4 h-4" /> Property Amenities
                                        </h4>
                                        <div className="flex flex-wrap gap-2">
                                            {commonAmenities.map(amenity => {
                                                const isSelected = newProperty.amenities?.includes(amenity);
                                                return (
                                                    <button
                                                        key={amenity}
                                                        type="button"
                                                        onClick={() => toggleAmenity(amenity)}
                                                        className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${
                                                            isSelected 
                                                                ? 'bg-teal-500 border-teal-500 text-white shadow-lg shadow-teal-500/20' 
                                                                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 hover:border-teal-200'
                                                        }`}
                                                    >
                                                        {amenity}
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Size / Area</label>
                                            <input 
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 transition-all font-bold" 
                                                value={newProperty.area} 
                                                onChange={e => setNewProperty({...newProperty, area: e.target.value})}
                                                placeholder="e.g. 1200 Sqft"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Location</label>
                                            <input 
                                                className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 transition-all font-bold" 
                                                value={newProperty.location} 
                                                onChange={e => setNewProperty({...newProperty, location: e.target.value})}
                                                placeholder="e.g. Near Market, Dhone"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">About Property</label>
                                        <textarea 
                                            className="w-full p-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 transition-all font-medium resize-none" 
                                            rows={3}
                                            value={newProperty.description} 
                                            onChange={e => setNewProperty({...newProperty, description: e.target.value})}
                                            placeholder="Add any specific details here..."
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Property Photos</label>
                                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4">
                                            {newProperty.images?.map((img, idx) => (
                                                <div key={idx} className="relative aspect-video rounded-2xl overflow-hidden group border border-slate-100 dark:border-slate-800 transition-transform hover:scale-105">
                                                    <img src={img} className="w-full h-full object-cover" alt={`Upload ${idx}`} />
                                                    <button 
                                                        type="button" 
                                                        onClick={() => removePhoto(idx)}
                                                        className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-all"
                                                    >
                                                        <IconTrash className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            ))}
                                            <label className="cursor-pointer flex flex-col items-center justify-center aspect-video border-2 border-dashed border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 rounded-2xl hover:bg-amber-50 dark:hover:bg-amber-900/10 hover:border-amber-400 transition-all group">
                                                <IconUpload className="w-8 h-8 text-slate-300 group-hover:text-amber-500 mb-1" />
                                                <span className="text-[10px] font-black text-slate-400 uppercase group-hover:text-amber-600">Add Photos</span>
                                                <input type="file" multiple onChange={handleImageUpload} className="hidden" accept="image/*" />
                                            </label>
                                        </div>
                                    </div>

                                    <div className="pt-6 flex gap-4">
                                        <button 
                                            type="button" 
                                            onClick={resetForm}
                                            className="flex-1 px-8 py-4 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-slate-400 font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                                        >
                                            Discard
                                        </button>
                                        <button 
                                            type="submit" 
                                            disabled={isSubmitting}
                                            className="flex-1 px-8 py-4 bg-amber-500 text-slate-900 font-black rounded-2xl hover:bg-amber-600 shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-70"
                                        >
                                            {isSubmitting ? (
                                                <div className="w-5 h-5 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"></div>
                                            ) : (
                                                <>
                                                    <IconSend className="w-5 h-5" /> Send for Approval
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default RealEstate;
