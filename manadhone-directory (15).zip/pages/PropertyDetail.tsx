
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProperties, getAgents } from '../services/storageService';
import { Property, RealEstateAgent } from '../types';
import { IconMapPin, IconPhone, IconHome, IconBed, IconBath, IconCar, IconCheck, IconNavigation, IconStar } from '../components/Icons';

const PropertyDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [property, setProperty] = useState<Property | null>(null);
    const [agent, setAgent] = useState<RealEstateAgent | null>(null);
    const [activeImage, setActiveImage] = useState<string>('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchDetails = () => {
            const allProperties = getProperties();
            const found = allProperties.find(p => p.id === id);
            
            if (found) {
                setProperty(found);
                setActiveImage(found.imageUrl);
                
                if (found.agentId) {
                    const allAgents = getAgents();
                    const foundAgent = allAgents.find(a => a.id === found.agentId);
                    setAgent(foundAgent || null);
                }
            }
            setLoading(false);
        };

        fetchDetails();
    }, [id]);

    const gallery = useMemo(() => {
        if (!property) return [];
        return [property.imageUrl, ...(property.images || [])].filter(Boolean);
    }, [property]);

    if (loading) {
        return (
            <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
                <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Fetching Listing Details...</p>
            </div>
        );
    }

    if (!property) {
        return (
            <div className="min-h-[60vh] flex flex-col items-center justify-center p-4 text-center">
                <IconHome className="w-16 h-16 text-slate-200 mb-6" />
                <h2 className="text-3xl font-black text-slate-800 mb-2 tracking-tight">Property Not Found</h2>
                <p className="text-slate-500 mb-8 max-w-sm">The listing you're looking for might have been sold or removed from our directory.</p>
                <Link to="/realestate" className="bg-indigo-600 text-white px-8 py-3 rounded-2xl font-black shadow-lg">Back to Real Estate</Link>
            </div>
        );
    }

    return (
        <div className="bg-slate-50 dark:bg-slate-950 min-h-screen pb-20 transition-colors duration-300">
            {/* Header Breadcrumb */}
            <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-white/5 py-4 transition-colors duration-300">
                <div className="container mx-auto px-4">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
                        <Link to="/" className="hover:text-indigo-600">Home</Link>
                        <span>/</span>
                        <Link to="/realestate" className="hover:text-indigo-600">Real Estate</Link>
                        <span>/</span>
                        <span className="text-slate-900 dark:text-white truncate">{property.title}</span>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 py-10">
                <div className="flex flex-col lg:flex-row gap-10">
                    
                    {/* Main Content Column */}
                    <div className="flex-1 space-y-10">
                        
                        {/* Gallery Section */}
                        <div className="space-y-4">
                            <div className="relative aspect-[16/9] md:aspect-[21/9] bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 group">
                                <img src={activeImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" alt={property.title} />
                                <div className="absolute top-6 left-6 flex gap-2">
                                    <span className="bg-amber-500 text-slate-900 text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-lg">
                                        For {property.purpose}
                                    </span>
                                    <span className="bg-white/90 backdrop-blur text-slate-900 text-[10px] font-black uppercase px-3 py-1 rounded-full shadow-lg">
                                        {property.type}
                                    </span>
                                </div>
                            </div>
                            
                            {gallery.length > 1 && (
                                <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 px-1">
                                    {gallery.map((img, i) => (
                                        <button 
                                            key={i} 
                                            onClick={() => setActiveImage(img)}
                                            className={`relative w-24 md:w-32 aspect-video rounded-xl overflow-hidden border-2 transition-all shrink-0 ${activeImage === img ? 'border-amber-500 scale-105 shadow-xl' : 'border-transparent opacity-60 hover:opacity-100'}`}
                                        >
                                            <img src={img} className="w-full h-full object-cover" alt="" />
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Property Overview */}
                        <div className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 transition-colors duration-300">
                            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 mb-10">
                                <div className="space-y-2">
                                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-tight">
                                        {property.title}
                                    </h1>
                                    <p className="text-slate-500 flex items-center gap-2 font-medium">
                                        <IconMapPin className="w-4 h-4 text-red-500" /> {property.location}
                                    </p>
                                </div>
                                <div className="text-left md:text-right">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Asking Price</p>
                                    <p className="text-4xl font-black text-indigo-600 dark:text-indigo-400 tracking-tight">{property.price}</p>
                                </div>
                            </div>

                            {/* Core Specs */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
                                <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/10 text-center space-y-1 transition-all hover:bg-slate-100">
                                    <IconHome className="w-6 h-6 mx-auto text-indigo-500" />
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</p>
                                    <p className="text-sm font-black text-slate-800 dark:text-white">{property.type}</p>
                                </div>
                                <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/10 text-center space-y-1 transition-all hover:bg-slate-100">
                                    <IconStar className="w-6 h-6 mx-auto text-amber-500" />
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Area</p>
                                    <p className="text-sm font-black text-slate-800 dark:text-white">{property.area}</p>
                                </div>
                                {(property.type === 'House' || property.type === 'Apartment') && (
                                    <>
                                        <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/10 text-center space-y-1 transition-all hover:bg-slate-100">
                                            <IconBed className="w-6 h-6 mx-auto text-blue-500" />
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Beds</p>
                                            <p className="text-sm font-black text-slate-800 dark:text-white">{property.bedrooms || 0}</p>
                                        </div>
                                        <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/10 text-center space-y-1 transition-all hover:bg-slate-100">
                                            <IconBath className="w-6 h-6 mx-auto text-teal-500" />
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Baths</p>
                                            <p className="text-sm font-black text-slate-800 dark:text-white">{property.bathrooms || 0}</p>
                                        </div>
                                    </>
                                )}
                            </div>

                            <div className="space-y-8">
                                <div>
                                    <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                                        <span className="w-8 h-1 bg-amber-500 rounded-full"></span>
                                        Description
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-lg whitespace-pre-wrap">
                                        {property.description}
                                    </p>
                                </div>

                                {property.amenities && property.amenities.length > 0 && (
                                    <div>
                                        <h3 className="text-lg font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                                            <span className="w-8 h-1 bg-teal-500 rounded-full"></span>
                                            Key Amenities
                                        </h3>
                                        <div className="flex flex-wrap gap-3">
                                            {property.amenities.map(a => (
                                                <span key={a} className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-5 py-2 rounded-full text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-2">
                                                    <IconCheck className="w-3 h-3 text-teal-500" /> {a}
                                                </span>
                                            ))}
                                            {property.parking && (
                                                <span className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800 px-5 py-2 rounded-full text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-2">
                                                    <IconCar className="w-3 h-3 text-amber-500" /> Secure Parking
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Location Preview Section */}
                        <div className="bg-white dark:bg-slate-900 rounded-[3rem] overflow-hidden shadow-sm border border-slate-100 dark:border-white/5 transition-colors duration-300">
                             <div className="h-64 md:h-80 relative group">
                                <img src={`https://picsum.photos/seed/${id}map/1200/600?blur=1`} className="w-full h-full object-cover opacity-60 transition-opacity group-hover:opacity-40" alt="Map Preview" />
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="p-4 bg-red-500 text-white rounded-full shadow-2xl animate-bounce border-4 border-white">
                                        <IconMapPin className="w-8 h-8" />
                                    </div>
                                </div>
                             </div>
                             <div className="p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
                                <div className="flex-1 text-center md:text-left">
                                    <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Location & Neighborhood</h3>
                                    <p className="text-slate-500 font-medium text-lg">{property.location}</p>
                                </div>
                                <a 
                                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(property.location + ' Dhone')}`} 
                                    target="_blank" 
                                    rel="noreferrer"
                                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-black px-10 py-5 rounded-2xl shadow-xl shadow-indigo-500/20 flex items-center gap-3 transition-all active:scale-95 text-sm uppercase tracking-widest"
                                >
                                    <IconNavigation className="w-5 h-5" /> Get Precise Directions
                                </a>
                             </div>
                        </div>
                    </div>

                    {/* Agent Sidebar Column */}
                    <div className="lg:w-96 space-y-8">
                        
                        <div className="sticky top-28 space-y-8">
                            
                            {/* Listing Info Box */}
                            <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 space-y-6 transition-colors duration-300">
                                <div>
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Status</p>
                                    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-black uppercase tracking-tighter ${property.status === 'available' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'}`}>
                                        <span className={`w-2 h-2 rounded-full ${property.status === 'available' ? 'bg-green-500' : 'bg-orange-500'}`}></span>
                                        {property.status}
                                    </div>
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Listed On</p>
                                    <p className="font-bold text-slate-700 dark:text-slate-300">{new Date(property.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                                </div>
                                <div className="pt-6 border-t border-slate-50 dark:border-white/5">
                                    <button className="w-full bg-slate-100 dark:bg-white/5 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 text-slate-600 dark:text-slate-400 hover:text-indigo-600 py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all">
                                        Save To Favorites
                                    </button>
                                </div>
                            </div>

                            {/* Agent Card */}
                            <div className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden transition-colors duration-300">
                                <div className="bg-indigo-600 p-8 text-white relative overflow-hidden">
                                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
                                    <div className="relative z-10">
                                        <h4 className="text-xs font-black uppercase tracking-widest mb-4 opacity-70">Expert Advisor</h4>
                                        <div className="flex items-center gap-4">
                                            {agent ? (
                                                <>
                                                    <div className="relative">
                                                        <img src={agent.imageUrl} className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20 shadow-xl" alt={agent.name} />
                                                        {agent.verified && (
                                                            <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white p-1 rounded-full shadow-lg border-2 border-indigo-600">
                                                                <IconCheck className="w-2.5 h-2.5" />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div>
                                                        <div className="flex items-center gap-1.5">
                                                            <p className="font-black text-lg leading-tight">{agent.name}</p>
                                                            {agent.verified && (
                                                                <span className="bg-white/20 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter">Verified</span>
                                                            )}
                                                        </div>
                                                        <p className="text-xs font-bold text-indigo-200">{agent.agency}</p>
                                                    </div>
                                                </>
                                            ) : (
                                                <>
                                                    <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
                                                        <IconHome className="w-8 h-8" />
                                                    </div>
                                                    <div>
                                                        <p className="font-black text-lg leading-tight">Direct Seller</p>
                                                        <p className="text-xs font-bold text-indigo-200">Verified Listing</p>
                                                    </div>
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="p-8 space-y-6">
                                    {agent && (
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between text-sm">
                                                <span className="font-bold text-slate-400">Experience</span>
                                                <span className="font-black text-slate-800 dark:text-white">{agent.experience}</span>
                                            </div>
                                            <p className="text-sm text-slate-500 italic leading-relaxed">
                                                "{agent.bio}"
                                            </p>
                                        </div>
                                    )}
                                    
                                    <div className="flex flex-col gap-3">
                                        <a 
                                            href={`tel:${agent ? agent.phone : property.phone || '+91 99999 99999'}`} 
                                            className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black py-5 rounded-2xl shadow-xl flex items-center justify-center gap-3 transition-all active:scale-95 text-xs uppercase tracking-widest"
                                        >
                                            <IconPhone className="w-5 h-5" /> Quick Call
                                        </a>
                                        <button 
                                            className="w-full bg-green-500 hover:bg-green-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-green-100 flex items-center justify-center gap-3 transition-all active:scale-95 text-xs uppercase tracking-widest"
                                        >
                                            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.01 2.01c-5.52 0-9.99 4.47-9.99 9.99 0 1.76.46 3.41 1.27 4.84l-1.35 4.93 5.05-1.33c1.4.78 3.01 1.23 4.73 1.23 5.52 0 10-4.48 10-10s-4.48-9.99-10-9.99zM17.6 15.65c-.24.68-1.24 1.25-1.71 1.34-.46.09-.9.23-2.92-.58-2.43-.97-3.99-3.44-4.11-3.6-.12-.16-.99-1.31-.99-2.51 0-1.19.62-1.78.84-2.02.22-.24.48-.3.63-.3.16 0 .31.01.45.01.14 0 .34-.05.53.4.19.46.65 1.58.71 1.7.06.12.1.26.02.42-.08.16-.12.26-.25.41-.12.14-.26.32-.38.43-.13.12-.26.25-.11.51.15.26.68 1.12 1.46 1.81.79.69 1.46.91 1.73 1.05.27.14.42.11.58-.06.16-.18.69-.8 1.13-1.33.15-.17.3-.14.51-.06.2.08 1.28.6 1.5 1.13.23.14.23.2.11.41z"/></svg>
                                            WhatsApp Inquiry
                                        </button>
                                    </div>
                                    
                                    <p className="text-[10px] text-center font-black text-slate-400 uppercase tracking-widest">
                                        Mention ID: {id} for Priority Response
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PropertyDetail;
