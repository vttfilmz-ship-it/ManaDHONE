
import React, { useState, useEffect } from 'react';
import Timeline from '../components/Timeline';
import { getHistory, getHeroSlides } from '../services/storageService';
import { HeroSlide } from '../types';

const History: React.FC = () => {
    const historyEvents = getHistory();
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    useEffect(() => {
        const slides = getHeroSlides().filter(s => s.page === 'history' && s.active);
        setHeroSlides(slides);
    }, []);

    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    return (
        <div className="bg-gray-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
            {/* Hero Header with Slider */}
            <div className="bg-slate-900 text-white py-20 px-4 text-center relative overflow-hidden h-[400px] flex items-center justify-center">
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, index) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-40' : 'opacity-0'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover" alt={slide.caption} />
                        </div>
                    ))
                ) : (
                    <div className="absolute inset-0 opacity-20">
                        <img src="https://images.unsplash.com/photo-1590120688653-5d754714f24f?q=80&w=2574&auto=format&fit=crop" className="w-full h-full object-cover" alt="History Background" />
                    </div>
                )}
                
                <div className="relative z-10">
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4 drop-shadow-lg">
                        {heroSlides.length > 0 && heroSlides[currentSlide]?.caption ? heroSlides[currentSlide].caption : "History of Dhone"}
                    </h1>
                    <p className="text-xl text-indigo-100 max-w-2xl mx-auto drop-shadow-md font-medium">
                        From the 14th century Vijayanagara fort to the modern "Groundnut City".
                    </p>
                </div>
            </div>

            <div className="container mx-auto px-4 max-w-4xl py-12">
                <Timeline events={historyEvents} />
            </div>
        </div>
    );
};

export default History;
