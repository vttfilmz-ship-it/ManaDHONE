import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getBusinesses, addReview, incrementViewCount, isBusinessSaved, toggleSaveBusiness } from '../services/storageService';
import { Business } from '../types';
import { 
    IconMapPin, IconPhone, IconMail, IconNavigation, 
    IconWhatsapp, IconFacebook, IconInstagram, IconTwitter, 
    IconStar, IconClock, IconBookmark
} from '../components/Icons';

const BusinessDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [business, setBusiness] = useState<Business | null>(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'details' | 'reviews' | 'location'>('details');
    const [heroImage, setHeroImage] = useState<string>('');
    const [isContactModalOpen, setIsContactModalOpen] = useState(false);
    const [isSaved, setIsSaved] = useState(false);

    // Review Form State
    const [reviewForm, setReviewForm] = useState({
        author: '',
        rating: 5,
        comment: ''
    });
    const [isSubmittingReview, setIsSubmittingReview] = useState(false);

    useEffect(() => {
        setLoading(true);
        // Find business logic
        const allBusinesses = getBusinesses();
        const found = allBusinesses.find(b => b.id === id);
        
        setBusiness(found || null);
        if (found) {
            setHeroImage(found.imageUrl);
            setIsSaved(isBusinessSaved(found.id));
            // Increment view count when page loads
            incrementViewCount(found.id);

            // Schema Markup (SEO Enhancement)
            const schemaData = {
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                "name": found.name,
                "image": found.imageUrl,
                "description": found.shortDescription || found.description,
                "telephone": found.phone,
                "email": found.email,
                "address": {
                    "@type": "PostalAddress",
                    "streetAddress": found.address,
                    "addressLocality": "Dhone",
                    "addressRegion": "Andhra Pradesh",
                    "addressCountry": "IN"
                },
                "geo": {
                    "@type": "GeoCoordinates",
                    "latitude": found.latitude,
                    "longitude": found.longitude
                },
                "url": window.location.href,
                "aggregateRating": found.reviews && found.reviews.length > 0 ? {
                    "@type": "AggregateRating",
                    "ratingValue": found.rating,
                    "reviewCount": found.reviews.length
                } : undefined,
                "openingHoursSpecification": found.openTime && found.closeTime ? {
                    "@type": "OpeningHoursSpecification",
                    "dayOfWeek": found.daysOpen ? found.daysOpen.split(' - ') : ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    "opens": found.openTime,
                    "closes": found.closeTime
                } : undefined
            };

            const script = document.createElement('script');
            script.type = 'application/ld+json';
            script.id = 'business-schema';
            script.innerHTML = JSON.stringify(schemaData);
            document.head.appendChild(script);

            // SEO: Update Document Title and Meta Description
            document.title = `${found.name} - ManaDHONE Directory`;
            const metaDescription = document.querySelector('meta[name="description"]');
            if (metaDescription) {
                metaDescription.setAttribute('content', found.shortDescription || found.description);
            }
        } else {
            document.title = "Business Not Found - ManaDHONE";
        }

        setLoading(false);

        // Cleanup function to reset title and remove schema when leaving
        return () => {
            document.title = "ManaDHONE - Business Directory";
            const existingScript = document.getElementById('business-schema');
            if (existingScript) {
                existingScript.remove();
            }
        };
    }, [id]);

    const handleToggleSave = () => {
        if (!business) return;
        const result = toggleSaveBusiness(business.id);
        setIsSaved(result);
    };

    const handleSubmitReview = (e: React.FormEvent) => {
        e.preventDefault();
        if (!business) return;
        
        setIsSubmittingReview(true);
        
        setTimeout(() => {
            const updatedBusiness = addReview(business.id, reviewForm);
            
            if (updatedBusiness) {
                setBusiness(updatedBusiness);
                setReviewForm({ author: '', rating: 5, comment: '' });
            }
            setIsSubmittingReview(false);
        }, 600);
    };

    const formatDate = (timestamp: number) => {
        return new Date(timestamp).toLocaleDateString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric'
        });
    };

    const formatTime = (time: string) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const h = parseInt(hours, 10);
        const ampm = h >= 12 ? 'PM' : 'AM';
        const formattedHour = h % 12 || 12;
        return `${formattedHour}:${minutes} ${ampm}`;
    };

    if (loading) {
        return (
            <div className="min-h-[60vh] flex flex-col items-center justify-center p-4 text-center">
                <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-gray-500 font-medium">Loading business details...</p>
            </div>
        );
    }

    if (!business) {
        return (
            <div className="min-h-[60vh] flex flex-col items-center justify-center p-4 text-center">
                <h2 className="text-3xl font-bold text-gray-800 mb-4">Business Not Found</h2>
                <p className="text-gray-600 mb-8">The business you are looking for does not exist or has been removed.</p>
                <Link to="/" className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                    Back to Directory
                </Link>
            </div>
        );
    }

    return (
        <div className="bg-gray-50 min-h-screen pb-20">
            {/* Header / Breadcrumb */}
            <div className="bg-white border-b border-gray-200">
                <div className="container mx-auto px-4 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Link to="/" className="hover:text-indigo-600">Home</Link>
                        <span>/</span>
                        <span className="text-gray-900 font-medium truncate">{business.name}</span>
                    </div>
                </div>
            </div>

            {/* Hero Image & Title */}
            <div className="relative h-64 md:h-96 bg-gray-900 overflow-hidden group">
                <img 
                    src={heroImage || business.imageUrl || 'https://picsum.photos/800/600'} 
                    alt={business.name} 
                    className="w-full h-full object-cover opacity-60 transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                
                {/* Thumbnail Gallery Overlay */}
                <div className="absolute bottom-4 right-4 flex gap-2 overflow-x-auto max-w-full pb-2 md:pb-0 z-20 px-4 md:px-0 no-scrollbar">
                    {[business.imageUrl, ...(business.images || [])].filter(Boolean).map((img, idx) => (
                        <button
                            key={idx}
                            onClick={() => setHeroImage(img!)}
                            className={`w-16 h-16 md:w-20 md:h-20 rounded-lg border-2 overflow-hidden shadow-lg transition-transform hover:scale-105 flex-shrink-0 ${heroImage === img ? 'border-indigo-500 ring-2 ring-indigo-500 ring-offset-2 ring-offset-black/50' : 'border-white/50 opacity-70 hover:opacity-100'}`}
                        >
                            <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                        </button>
                    ))}
                </div>
                
                <div className="absolute bottom-0 left-0 right-0 container mx-auto px-4 py-8 text-white pointer-events-none">
                    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
                        <div>
                            <span className="inline-block bg-indigo-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide mb-2">
                                {business.category}
                            </span>
                            <div className="flex items-center gap-3">
                                <h1 className="text-3xl md:text-5xl font-extrabold shadow-sm">{business.name}</h1>
                                {business.verified && (
                                    <div className="bg-blue-500 p-1.5 rounded-full" title="Verified Business">
                                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                                    </div>
                                )}
                            </div>
                            <p className="mt-2 text-lg text-gray-200 max-w-2xl hidden md:block">{business.shortDescription}</p>
                        </div>
                        
                        <div className="flex flex-col md:flex-row items-start md:items-center gap-4 pointer-events-auto">
                            <div className="flex gap-2 w-full md:w-auto">
                                <button 
                                    onClick={() => setIsContactModalOpen(true)}
                                    className="flex-1 md:flex-none bg-white text-indigo-700 hover:bg-indigo-50 px-6 py-3 rounded-xl font-bold shadow-lg transition-all transform hover:scale-105 flex items-center justify-center gap-2"
                                >
                                    <IconPhone className="w-5 h-5" />
                                    Contact Us
                                </button>
                                <button 
                                    onClick={handleToggleSave}
                                    className={`p-3 rounded-xl shadow-lg transition-all transform hover:scale-105 flex items-center justify-center border-2 ${isSaved ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white/20 text-white backdrop-blur-md border-white/40 hover:bg-white/30'}`}
                                    title={isSaved ? 'Saved to Bookmarks' : 'Save for Later'}
                                >
                                    <IconBookmark fill={isSaved} className="w-6 h-6" />
                                </button>
                            </div>

                            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-3 rounded-lg border border-white/20 h-full">
                                <span className="text-2xl font-bold">{business.rating}</span>
                                <div className="flex text-yellow-400">
                                    {Array.from({ length: 5 }).map((_, i) => (
                                        <IconStar key={i} fill={i < Math.round(business.rating)} className="w-5 h-5" />
                                    ))}
                                </div>
                                <span className="text-xs text-gray-300 ml-1">({business.reviews?.length || 0})</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 -mt-8 relative z-10">
                <div className="bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden flex flex-col md:flex-row min-h-[500px]">
                    
                    {/* Navigation Sidebar (Desktop) / Topbar (Mobile) */}
                    <div className="md:w-64 bg-gray-50 border-r border-gray-100 flex md:flex-col shrink-0 overflow-x-auto md:overflow-visible">
                        <button 
                            onClick={() => setActiveTab('details')}
                            className={`flex-1 md:flex-none p-4 md:py-6 md:px-8 text-sm font-semibold text-center md:text-left transition-colors border-b-2 md:border-b-0 md:border-l-4 ${activeTab === 'details' ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                        >
                            Details
                        </button>
                        <button 
                            onClick={() => setActiveTab('reviews')}
                            className={`flex-1 md:flex-none p-4 md:py-6 md:px-8 text-sm font-semibold text-center md:text-left transition-colors border-b-2 md:border-b-0 md:border-l-4 ${activeTab === 'reviews' ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                        >
                            Reviews
                        </button>
                        <button 
                            onClick={() => setActiveTab('location')}
                            className={`flex-1 md:flex-none p-4 md:py-6 md:px-8 text-sm font-semibold text-center md:text-left transition-colors border-b-2 md:border-b-0 md:border-l-4 ${activeTab === 'location' ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50' : 'border-transparent text-gray-600 hover:bg-gray-100'}`}
                        >
                            Location
                        </button>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 p-6 md:p-10">
                        {/* DETAILS TAB */}
                        {activeTab === 'details' && (
                            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-300">
                                {/* About */}
                                <div className="prose max-w-none">
                                    <h3 className="text-2xl font-bold text-gray-900 mb-4">About Us</h3>
                                    <p className="text-gray-600 leading-relaxed text-lg">
                                        {business.description || business.shortDescription}
                                    </p>
                                </div>

                                {/* Business Hours */}
                                {(business.daysOpen || business.openTime) && (
                                    <div>
                                        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                                            <IconClock className="w-6 h-6 text-gray-400" />
                                            Business Hours
                                        </h3>
                                        <div className="bg-gray-50 p-6 rounded-xl border border-gray-100 inline-block min-w-[300px]">
                                            <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-200">
                                                <span className="text-sm font-semibold text-gray-500 uppercase">Days</span>
                                                <span className="font-bold text-gray-900">{business.daysOpen || 'Daily'}</span>
                                            </div>
                                            {business.openTime && business.closeTime && (
                                                <div className="flex justify-between items-center">
                                                    <span className="text-sm font-semibold text-gray-500 uppercase">Hours</span>
                                                    <span className="font-bold text-indigo-600">
                                                        {formatTime(business.openTime)} - {formatTime(business.closeTime)}
                                                    </span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )}

                                {/* Contact Grid */}
                                <div>
                                    <h3 className="text-xl font-bold text-gray-900 mb-6">Contact & Social</h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        <a href={`tel:${business.phone}`} className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md border border-gray-200 hover:border-indigo-200 transition-all group">
                                            <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                                <IconPhone className="w-6 h-6" />
                                            </div>
                                            <div>
                                                <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Phone</p>
                                                <p className="font-bold text-gray-900">{business.phone}</p>
                                            </div>
                                        </a>
                                        
                                        {business.whatsapp && (
                                            <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md border border-gray-200 hover:border-green-200 transition-all group">
                                                <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-colors">
                                                    <IconWhatsapp className="w-6 h-6" />
                                                </div>
                                                <div>
                                                    <p className="text-xs text-gray-500 font-semibold uppercase mb-1">WhatsApp</p>
                                                    <p className="font-bold text-gray-900">Chat on WA</p>
                                                </div>
                                            </a>
                                        )}

                                        {business.email && (
                                            <a href={`mailto:${business.email}`} className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md border border-gray-200 hover:border-purple-200 transition-all group">
                                                <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                                                    <IconMail className="w-6 h-6" />
                                                </div>
                                                <div className="overflow-hidden">
                                                    <p className="text-xs text-gray-500 font-semibold uppercase mb-1">Email</p>
                                                    <p className="font-bold text-gray-900 truncate">{business.email}</p>
                                                </div>
                                            </a>
                                        )}
                                    </div>

                                    {/* Social Media Links */}
                                    {(business.facebook || business.instagram || business.twitter) && (
                                        <div className="flex gap-4 mt-6">
                                            {business.facebook && (
                                                <a href={business.facebook} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-5 py-2 bg-gray-100 hover:bg-blue-600 hover:text-white text-gray-700 rounded-full transition-all font-medium">
                                                    <IconFacebook className="w-5 h-5" /> Facebook
                                                </a>
                                            )}
                                            {business.instagram && (
                                                <a href={business.instagram} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-5 py-2 bg-gray-100 hover:bg-pink-600 hover:text-white text-gray-700 rounded-full transition-all font-medium">
                                                    <IconInstagram className="w-5 h-5" /> Instagram
                                                </a>
                                            )}
                                            {business.twitter && (
                                                <a href={business.twitter} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-5 py-2 bg-gray-100 hover:bg-sky-500 hover:text-white text-gray-700 rounded-full transition-all font-medium">
                                                    <IconTwitter className="w-5 h-5" /> Twitter
                                                </a>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* REVIEWS TAB */}
                        {activeTab === 'reviews' && (
                            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-3xl">
                                {/* Rating Summary */}
                                <div className="flex flex-col sm:flex-row items-center gap-8 bg-gray-50 p-8 rounded-2xl border border-gray-200">
                                    <div className="text-center">
                                        <div className="text-6xl font-extrabold text-gray-900">{business.rating}</div>
                                        <div className="flex justify-center text-yellow-400 my-2">
                                            {Array.from({ length: 5 }).map((_, i) => (
                                                <IconStar key={i} fill={i < Math.round(business.rating)} className="w-6 h-6" />
                                            ))}
                                        </div>
                                        <div className="text-sm text-gray-500 font-medium">{business.reviews?.length || 0} customer reviews</div>
                                    </div>
                                    <div className="hidden sm:block w-px h-24 bg-gray-200"></div>
                                    <div className="flex-1 text-center sm:text-left">
                                        <h4 className="text-lg font-bold text-gray-900 mb-2">Customer Satisfaction</h4>
                                        <p className="text-gray-600">
                                            "We strive to provide the best service in ManaDHONE. Your feedback helps us improve and serve you better."
                                        </p>
                                    </div>
                                </div>

                                {/* Review Form */}
                                <div>
                                    <h3 className="text-2xl font-bold text-gray-900 mb-6">Write a Review</h3>
                                    <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm">
                                        <form onSubmit={handleSubmitReview} className="space-y-5">
                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Your Rating</label>
                                                <div className="flex gap-2">
                                                    {[1, 2, 3, 4, 5].map((star) => (
                                                        <button 
                                                            key={star} 
                                                            type="button"
                                                            onClick={() => setReviewForm(prev => ({ ...prev, rating: star }))}
                                                            className="focus:outline-none transition-transform hover:scale-110"
                                                        >
                                                            <IconStar 
                                                                fill={star <= reviewForm.rating} 
                                                                className={`w-10 h-10 ${star <= reviewForm.rating ? 'text-yellow-400' : 'text-gray-200'}`} 
                                                            />
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                            
                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Name</label>
                                                <input 
                                                    type="text" 
                                                    required
                                                    placeholder="John Doe" 
                                                    value={reviewForm.author}
                                                    onChange={e => setReviewForm(prev => ({ ...prev, author: e.target.value }))}
                                                    className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-gray-50"
                                                />
                                            </div>

                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Review</label>
                                                <textarea 
                                                    required
                                                    placeholder="Share details of your own experience at this place..."
                                                    rows={4}
                                                    value={reviewForm.comment}
                                                    onChange={e => setReviewForm(prev => ({ ...prev, comment: e.target.value }))}
                                                    className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none bg-gray-50"
                                                />
                                            </div>

                                            <button 
                                                type="submit" 
                                                disabled={isSubmittingReview}
                                                className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 shadow-lg shadow-indigo-200"
                                            >
                                                {isSubmittingReview ? 'Submitting...' : 'Post Review'}
                                            </button>
                                        </form>
                                    </div>
                                </div>

                                {/* Reviews List */}
                                <div>
                                    <h3 className="text-2xl font-bold text-gray-900 mb-6">User Reviews</h3>
                                    <div className="space-y-6">
                                        {business.reviews && business.reviews.length > 0 ? (
                                            business.reviews.map(review => (
                                                <div key={review.id} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                                                    <div className="flex justify-between items-start mb-4">
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold shadow-md">
                                                                {review.author.charAt(0).toUpperCase()}
                                                            </div>
                                                            <div>
                                                                <div className="font-bold text-gray-900">{review.author}</div>
                                                                <div className="flex text-yellow-400 mt-0.5">
                                                                    {Array.from({ length: 5 }).map((_, i) => (
                                                                        <IconStar key={i} fill={i < review.rating} className="w-3.5 h-3.5" />
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <span className="text-sm text-gray-400 font-medium">{formatDate(review.date)}</span>
                                                    </div>
                                                    <p className="text-gray-600 leading-relaxed">{review.comment}</p>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-300">
                                                <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                                                    <IconStar className="w-8 h-8 text-gray-300" />
                                                </div>
                                                <p className="text-gray-500 font-medium">No reviews yet. Be the first to share your experience!</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* LOCATION TAB */}
                        {activeTab === 'location' && (
                            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-3xl">
                                <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                                    {/* Simulated Map */}
                                    <div className="h-64 w-full bg-slate-100 relative group">
                                         <img 
                                            src="https://picsum.photos/seed/map/1200/600?blur=1" 
                                            className="w-full h-full object-cover opacity-50 group-hover:opacity-40 transition-opacity" 
                                            alt="Map"
                                         />
                                         <div className="absolute inset-0 flex items-center justify-center">
                                             <div className="bg-red-500 text-white p-3 rounded-full shadow-xl animate-bounce">
                                                 <IconMapPin className="w-8 h-8" />
                                             </div>
                                         </div>
                                    </div>
                                    
                                    <div className="p-8">
                                        <h4 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                                            <IconMapPin className="w-6 h-6 text-indigo-600" />
                                            Address
                                        </h4>
                                        <p className="text-gray-600 text-lg mb-8 pl-8">{business.address}</p>
                                        
                                        <a 
                                            href={`https://www.google.com/maps/search/?api=1&query=${business.latitude},${business.longitude}`}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl flex items-center justify-center gap-3 text-lg font-bold transition-all shadow-lg shadow-indigo-100 transform hover:-translate-y-1"
                                        >
                                            <IconNavigation className="w-5 h-5" />
                                            Get Directions on Google Maps
                                        </a>
                                    </div>
                                </div>
                                
                                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                                    <h4 className="font-bold text-slate-800 mb-4">GPS Coordinates</h4>
                                    <div className="grid grid-cols-2 gap-4 text-sm font-mono">
                                        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                                            <span className="block text-xs text-slate-400 font-bold uppercase mb-1">Latitude</span>
                                            <span className="text-lg text-slate-700">{business.latitude}</span>
                                        </div>
                                        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                                            <span className="block text-xs text-slate-400 font-bold uppercase mb-1">Longitude</span>
                                            <span className="text-lg text-slate-700">{business.longitude}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Contact Modal */}
            {isContactModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="bg-indigo-600 p-6 flex justify-between items-center text-white">
                            <h3 className="text-xl font-bold">Contact {business.name}</h3>
                            <button 
                                onClick={() => setIsContactModalOpen(false)}
                                className="bg-white/20 hover:bg-white/30 p-2 rounded-full transition-colors"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <a href={`tel:${business.phone}`} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-indigo-50 border border-gray-100 hover:border-indigo-200 transition-all group">
                                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                    <IconPhone className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500 font-bold uppercase">Call Now</p>
                                    <p className="font-bold text-gray-900 text-lg">{business.phone}</p>
                                </div>
                            </a>

                            {business.whatsapp && (
                                <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-green-50 border border-gray-100 hover:border-green-200 transition-all group">
                                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-colors">
                                        <IconWhatsapp className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 font-bold uppercase">WhatsApp</p>
                                        <p className="font-bold text-gray-900 text-lg">Chat with us</p>
                                    </div>
                                </a>
                            )}

                            {business.email && (
                                <a href={`mailto:${business.email}`} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-purple-50 border border-gray-100 hover:border-purple-200 transition-all group">
                                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                                        <IconMail className="w-6 h-6" />
                                    </div>
                                    <div className="overflow-hidden">
                                        <p className="text-xs text-gray-500 font-bold uppercase">Email</p>
                                        <p className="font-bold text-gray-900 truncate">{business.email}</p>
                                    </div>
                                </a>
                            )}
                            
                            {(business.facebook || business.instagram || business.twitter) && (
                                <div className="pt-4 border-t border-gray-100">
                                    <p className="text-center text-sm text-gray-500 mb-4 font-medium">Follow us on Social Media</p>
                                    <div className="flex justify-center gap-6">
                                        {business.facebook && (
                                            <a href={business.facebook} target="_blank" rel="noopener noreferrer" className="p-3 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-600 hover:text-white transition-colors">
                                                <IconFacebook className="w-6 h-6" />
                                            </a>
                                        )}
                                        {business.instagram && (
                                            <a href={business.instagram} target="_blank" rel="noopener noreferrer" className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-600 hover:text-white transition-colors">
                                                <IconInstagram className="w-6 h-6" />
                                            </a>
                                        )}
                                        {business.twitter && (
                                            <a href={business.twitter} target="_blank" rel="noopener noreferrer" className="p-3 bg-sky-50 text-sky-500 rounded-full hover:bg-sky-500 hover:text-white transition-colors">
                                                <IconTwitter className="w-6 h-6" />
                                            </a>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BusinessDetail;