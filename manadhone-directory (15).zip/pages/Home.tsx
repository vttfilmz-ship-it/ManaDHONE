
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { getBusinesses, getAds, getNews, getInfluencers, getEvents, getContacts, getHeroSlides, getFMSchedule } from '../services/storageService.ts';
import { Business, Category, Advert, NewsItem, Influencer, LocalEvent, EmergencyContact, HeroSlide, FMProgram } from '../types.ts';
import BusinessCard from '../components/BusinessCard.tsx';
import AdSlider from '../components/AdSlider.tsx';
import NewsTicker from '../components/NewsTicker.tsx';
import WeatherWidget from '../components/WeatherWidget.tsx';
// Added missing IconPhone import to the named imports below
import { IconSearch, IconFilm, IconTicket, IconInstagram, IconFacebook, IconRadio, IconPlay, IconPause, IconBriefcase, IconMapPin, IconStar, IconTrendingUp, IconClock, IconCheck, IconPhone } from '../components/Icons.tsx';

const Home: React.FC = () => {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [ads, setAds] = useState<Advert[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [events, setEvents] = useState<LocalEvent[]>([]);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
  const [currentHeroSlide, setCurrentHeroSlide] = useState(0);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');

  useEffect(() => {
    setBusinesses(getBusinesses());
    setAds(getAds());
    setNews(getNews());
    setEvents(getEvents());
    setHeroSlides(getHeroSlides().filter(s => s.active && s.page === 'home'));
  }, []);

  useEffect(() => {
      if (heroSlides.length <= 1) return;
      const timer = setInterval(() => {
          setCurrentHeroSlide(prev => (prev + 1) % heroSlides.length);
      }, 5000);
      return () => clearInterval(timer);
  }, [heroSlides.length]);

  const filteredBusinesses = useMemo(() => {
    let result = businesses.filter(b => b.status === 'approved');
    
    if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        result = result.filter(b => 
            b.name.toLowerCase().includes(q) || 
            b.category.toLowerCase().includes(q) ||
            b.shortDescription.toLowerCase().includes(q)
        );
    }
    
    if (selectedCategory !== 'All') {
        result = result.filter(b => b.category === selectedCategory);
    }
    
    // Featured first, then by date
    return result.sort((a, b) => {
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return b.createdAt - a.createdAt;
    });
  }, [businesses, searchQuery, selectedCategory]);

  return (
    <div className="bg-gray-50">
      <NewsTicker news={news} />

      {/* Hero Section */}
      <div className="relative h-[500px] bg-slate-900 flex items-center justify-center text-center overflow-hidden">
         {heroSlides.length > 0 ? (
            heroSlides.map((slide, index) => (
                <div 
                    key={slide.id} 
                    className={`absolute inset-0 transition-opacity duration-1000 ${index === currentHeroSlide ? 'opacity-60' : 'opacity-0'}`}
                >
                    <img src={slide.imageUrl} className="w-full h-full object-cover" alt="" />
                </div>
            ))
         ) : (
            <div className="absolute inset-0 opacity-40 bg-indigo-900"></div>
         )}
         
         <div className="relative z-10 px-4 max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tighter">
                Explore Mana<span className="text-indigo-400">DHONE</span>
            </h1>
            <p className="text-xl text-gray-200 mb-10 font-medium">Find the best local shops, services, and landmarks in our town.</p>
            
            <div className="max-w-2xl mx-auto flex flex-col md:flex-row bg-white rounded-2xl shadow-2xl p-2 gap-2">
                <div className="flex-1 flex items-center px-4">
                    <IconSearch className="w-5 h-5 text-gray-400 mr-2" />
                    <input 
                        type="text" 
                        placeholder="Search for biryani, clinic, plumber..." 
                        className="w-full py-3 bg-transparent outline-none text-gray-800 font-bold"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-8 py-3 rounded-xl transition-all">
                    Search
                </button>
            </div>
         </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <AdSlider ads={ads.filter(a => a.status === 'approved')} />

        <div className="flex flex-col lg:flex-row gap-12 mt-16">
            {/* Main Listings */}
            <div className="flex-1">
                <div className="flex justify-between items-end mb-8">
                    <div>
                        <h2 className="text-3xl font-black text-gray-900 tracking-tight">Local Directory</h2>
                        <p className="text-gray-500 font-medium">Browse verified local businesses</p>
                    </div>
                    <div className="hidden sm:flex gap-2 overflow-x-auto no-scrollbar pb-1">
                        <button 
                            onClick={() => setSelectedCategory('All')}
                            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${selectedCategory === 'All' ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-500 hover:border-indigo-400'}`}
                        >
                            All
                        </button>
                        {Object.values(Category).slice(0, 5).map(cat => (
                            <button 
                                key={cat}
                                onClick={() => setSelectedCategory(cat)}
                                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${selectedCategory === cat ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-500 hover:border-indigo-400'}`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {filteredBusinesses.map(business => (
                        <BusinessCard key={business.id} business={business} />
                    ))}
                </div>

                {filteredBusinesses.length === 0 && (
                    <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
                        <IconSearch className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-gray-900">No results found</h3>
                        <p className="text-gray-500 mt-1">Try a different keyword or category.</p>
                    </div>
                )}
            </div>

            {/* Sidebar Widgets */}
            <div className="w-full lg:w-80 space-y-8">
                {/* Emergency Widget */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-black text-gray-900 mb-4 flex items-center gap-2">
                        <IconPhone className="w-5 h-5 text-red-500" /> Emergency
                    </h3>
                    <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-red-50 rounded-xl">
                            <span className="text-sm font-bold text-red-700">Police</span>
                            <a href="tel:100" className="bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-black">100</a>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-red-50 rounded-xl">
                            <span className="text-sm font-bold text-red-700">Ambulance</span>
                            <a href="tel:108" className="bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-black">108</a>
                        </div>
                    </div>
                </div>

                {/* Events Widget */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-black text-gray-900 mb-4 flex items-center gap-2">
                        <IconTicket className="w-5 h-5 text-indigo-500" /> Upcoming
                    </h3>
                    <div className="space-y-4">
                        {events.slice(0, 3).map(event => (
                            <div key={event.id} className="flex gap-3">
                                <img src={event.imageUrl} className="w-12 h-12 rounded-lg object-cover" alt="" />
                                <div>
                                    <h4 className="text-xs font-bold text-gray-900 line-clamp-1">{event.title}</h4>
                                    <p className="text-[10px] text-gray-400 font-bold">{event.date}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <Link to="/explore" className="block text-center text-xs font-bold text-indigo-600 mt-6 hover:underline uppercase tracking-widest">See more events</Link>
                </div>

                {/* Stars Widget */}
                <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-xl">
                    <h3 className="text-lg font-black mb-4 flex items-center gap-2">
                        <IconStar fill className="w-5 h-5 text-yellow-300" /> Dhone Stars
                    </h3>
                    <p className="text-sm text-indigo-100 mb-6">Meet our local creators and influencers.</p>
                    <Link to="/stars" className="block w-full py-3 bg-white text-indigo-600 rounded-xl text-center text-xs font-black uppercase tracking-widest">View Directory</Link>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
