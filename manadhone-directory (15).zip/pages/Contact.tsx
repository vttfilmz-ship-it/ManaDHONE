
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { IconMail, IconMapPin, IconPhone, IconSend, IconWhatsapp, IconClock, IconTrendingUp } from '../components/Icons';

const Contact: React.FC = () => {
    const [formState, setFormState] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSent, setIsSent] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        // Simulate API call
        setTimeout(() => {
            setIsSubmitting(false);
            setIsSent(true);
            setFormState({ name: '', email: '', subject: '', message: '' });
        }, 1500);
    };

    return (
        <div className="bg-gray-50 min-h-screen py-12">
            <div className="container mx-auto px-4 max-w-6xl">
                {/* Hero Section */}
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6 tracking-tight">
                        Get in <span className="text-indigo-600">Touch</span>
                    </h1>
                    <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
                        Have questions about a listing or want to promote your business? 
                        Our team is here to help you connect with the Dhone community.
                    </p>
                </div>

                <div className="flex flex-col lg:flex-row gap-12">
                    {/* Contact Information */}
                    <div className="lg:w-1/3 space-y-8">
                        <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                            <h2 className="text-2xl font-bold text-gray-900 mb-8">Contact Information</h2>
                            
                            <div className="space-y-6">
                                <div className="flex items-start gap-4">
                                    <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 shrink-0">
                                        <IconMapPin className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <p className="font-bold text-gray-900 mb-1">Our Office</p>
                                        <p className="text-gray-500 text-sm leading-relaxed">
                                            ManaDHONE Digital Center<br />
                                            Municipal Building, Main Road<br />
                                            Dhone, Andhra Pradesh 518222
                                        </p>
                                    </div>
                                </div>

                                <div className="flex items-start gap-4">
                                    <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 shrink-0">
                                        <IconPhone className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <p className="font-bold text-gray-900 mb-1">Phone Number</p>
                                        <p className="text-gray-500 text-sm">+91 98765 43210</p>
                                        <p className="text-gray-400 text-xs mt-1">Mon-Sat, 9am - 6pm</p>
                                    </div>
                                </div>

                                <div className="flex items-start gap-4">
                                    <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 shrink-0">
                                        <IconMail className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <p className="font-bold text-gray-900 mb-1">Email Support</p>
                                        <p className="text-gray-500 text-sm">support@manadhone.com</p>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-12 pt-8 border-t border-gray-50">
                                <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                                    <IconClock className="w-5 h-5 text-gray-400" />
                                    Business Hours
                                </h3>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between text-gray-600">
                                        <span>Monday - Friday</span>
                                        <span className="font-medium">9:00 - 18:00</span>
                                    </div>
                                    <div className="flex justify-between text-gray-600">
                                        <span>Saturday</span>
                                        <span className="font-medium">10:00 - 14:00</span>
                                    </div>
                                    <div className="flex justify-between text-red-500 font-medium">
                                        <span>Sunday</span>
                                        <span>Closed</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Advertise CTA Card */}
                        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 rounded-3xl shadow-xl text-white">
                             <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6">
                                <IconTrendingUp className="w-6 h-6" />
                             </div>
                             <h3 className="text-xl font-bold mb-3">Want more customers?</h3>
                             <p className="text-indigo-100 text-sm mb-8 leading-relaxed">
                                 Get your business noticed with our premium advertising spots. High visibility, local impact.
                             </p>
                             <Link 
                                to="/advertise" 
                                className="w-full bg-white text-indigo-600 font-black py-3 rounded-xl flex items-center justify-center hover:bg-indigo-50 transition-all shadow-lg active:scale-95"
                             >
                                Advertise With Us
                             </Link>
                        </div>
                    </div>

                    {/* Contact Form */}
                    <div className="lg:w-2/3">
                        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100">
                            <h2 className="text-2xl font-bold text-gray-900 mb-2">Send us a Message</h2>
                            <p className="text-gray-500 mb-10">We usually respond within 24 business hours.</p>

                            {isSent ? (
                                <div className="bg-green-50 border border-green-100 p-10 rounded-2xl text-center animate-in zoom-in duration-300">
                                    <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-200">
                                        <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                                    </div>
                                    <h3 className="text-2xl font-bold text-green-900 mb-2">Message Sent!</h3>
                                    <p className="text-green-700 mb-8">Thank you for reaching out. Our team will get back to you shortly.</p>
                                    <button 
                                        onClick={() => setIsSent(false)}
                                        className="px-8 py-3 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 transition-all shadow-md active:scale-95"
                                    >
                                        Send Another Message
                                    </button>
                                </div>
                            ) : (
                                <form onSubmit={handleSubmit} className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                                            <input 
                                                type="text" 
                                                required
                                                placeholder="Enter your name"
                                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                                                value={formState.name}
                                                onChange={e => setFormState({...formState, name: e.target.value})}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-2">Email Address</label>
                                            <input 
                                                type="email" 
                                                required
                                                placeholder="Enter your email"
                                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                                                value={formState.email}
                                                onChange={e => setFormState({...formState, email: e.target.value})}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-2">Subject</label>
                                        <input 
                                            type="text" 
                                            required
                                            placeholder="What is this regarding?"
                                            className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                                            value={formState.subject}
                                            onChange={e => setFormState({...formState, subject: e.target.value})}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-2">Your Message</label>
                                        <textarea 
                                            required
                                            rows={6}
                                            placeholder="Tell us how we can help you..."
                                            className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all resize-none"
                                            value={formState.message}
                                            onChange={e => setFormState({...formState, message: e.target.value})}
                                        />
                                    </div>

                                    <button 
                                        type="submit" 
                                        disabled={isSubmitting}
                                        className="w-full md:w-auto px-10 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-3 disabled:opacity-70 transform hover:-translate-y-1 active:translate-y-0"
                                    >
                                        {isSubmitting ? (
                                            <>
                                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                                Sending...
                                            </>
                                        ) : (
                                            <>
                                                <IconSend className="w-5 h-5" />
                                                Send Message
                                            </>
                                        )}
                                    </button>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Contact;