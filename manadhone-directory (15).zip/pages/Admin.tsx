
import React, { useState, useEffect, useMemo } from 'react';
import { 
    getBusinesses, deleteBusiness, saveBusiness, 
    getAnalytics, getUsers, saveUser, deleteUser, getAllReviews, deleteReview, 
    ReviewWithBusiness, getHeroSlides, saveHeroSlide, deleteHeroSlide,
    getNews, saveNews, deleteNews,
    getEvents, saveEvent, deleteEvent,
    getInfluencers, saveInfluencer, deleteInfluencer,
    getContacts, saveContact, deleteContact,
    getJobs, saveJob, deleteJob,
    getJobCategories, saveJobCategory, deleteJobCategory,
    getJobAlerts, deleteJobAlert,
    getFreelancers, saveFreelancer, deleteFreelancer,
    getHistory, saveHistoryEvent, deleteHistoryEvent,
    getTourismSpots, saveTourismSpot, deleteTourismSpot,
    getFMSchedule, saveFMProgram, deleteFMProgram,
    getTownStats, saveTownStats,
    getProperties, saveProperty, deleteProperty,
    getAgents, saveAgent, deleteAgent,
    // Fixed: Removed duplicate saveAllAds from this line to prevent redeclaration errors
    getAds, saveAd, deleteAd, 
    getTransactions, deleteTransaction,
    getBroadcasts, saveBroadcast, deleteBroadcast,
    saveAllHeroSlides, saveAllNews, saveAllEvents, saveAllTourismSpots, saveAllHistoryEvents, saveAllFMPrograms, saveAllInfluencers, saveAllContacts, saveAllJobs, saveAllFreelancers, saveAllProperties, saveAllAgents, saveAllBusinesses, saveAllAds, saveAllUsers
} from '../services/storageService';
import { 
    Business, AnalyticsData, User, HeroSlide, NewsItem, LocalEvent, 
    Influencer, EmergencyContact, Job, JobCategory, Freelancer, 
    HistoryEvent, TourismSpot, FMProgram, TownStats, Property, RealEstateAgent, JobAlert, Advert, Transaction, Broadcast, Category
} from '../types';
import AdminForm from '../components/AdminForm';
import AdminAdForm from '../components/AdminAdForm';
import { 
    NewsForm, EventForm, InfluencerForm, ContactForm, JobCategoryForm, 
    JobForm, FreelancerForm, HeroSlideForm, HistoryForm, TourismForm, FMProgramForm, UserForm,
    PropertyForm, AgentForm
} from '../components/AdminContentForms';
import { 
  IconEdit, IconTrash, IconUser, IconStar, IconMail, IconPhone, 
  IconTrendingUp, IconChart, IconHome, IconCloud, IconFilm, 
  IconTicket, IconBriefcase, IconMapPin, IconClock, IconRadio, IconBook, IconPalette,
  IconFilter, IconMessage, IconGrip, IconCheck, IconPause, IconSearch, IconCurrency, IconWhatsapp, IconSend
} from '../components/Icons';

type AdminSection = 
    | 'analytics' | 'businesses' | 'paid_ads' | 'hero' | 'news' | 'events' 
    | 'tourism' | 'history' | 'jobs' | 'job_cats' | 'job_alerts' | 'freelancers' 
    | 'fm' | 'influencers' | 'contacts' | 'reviews' | 'users' | 'stats'
    | 'properties' | 'agents' | 'finance' | 'alerts';

const Admin: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AdminSection>('analytics');
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [data, setData] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [townStats, setTownStatsState] = useState<TownStats>(getTownStats());

  const refreshData = () => {
    switch (activeSection) {
        case 'analytics': setAnalytics(getAnalytics()); break;
        case 'businesses': setData(getBusinesses()); break;
        case 'paid_ads': setData(getAds()); break;
        case 'hero': setData(getHeroSlides()); break;
        case 'news': setData(getNews()); break;
        case 'events': setData(getEvents()); break;
        case 'tourism': setData(getTourismSpots()); break;
        case 'history': setData(getHistory()); break;
        case 'jobs': setData(getJobs()); break;
        case 'job_cats': setData(getJobCategories()); break;
        case 'job_alerts': setData(getJobAlerts()); break;
        case 'freelancers': setData(getFreelancers()); break;
        case 'fm': setData(getFMSchedule()); break;
        case 'influencers': setData(getInfluencers()); break;
        case 'contacts': setData(getContacts()); break;
        case 'reviews': setData(getAllReviews()); break;
        case 'users': setData(getUsers()); break;
        case 'stats': setTownStatsState(getTownStats()); break;
        case 'properties': setData(getProperties()); break;
        case 'agents': setData(getAgents()); break;
        case 'finance': setData(getTransactions()); break;
        case 'alerts': setData(getBroadcasts()); break;
    }
  };

  useEffect(() => {
    refreshData();
    setView('list');
    setEditingId(null);
  }, [activeSection]);

  const handleEdit = (id: string) => {
    setEditingId(id);
    setView('form');
  };

  const handleDelete = (id: string) => {
    if (!window.confirm("Permamently delete this item?")) return;
    switch (activeSection) {
        case 'businesses': deleteBusiness(id); break;
        case 'paid_ads': deleteAd(id); break;
        case 'hero': deleteHeroSlide(id); break;
        case 'news': deleteNews(id); break;
        case 'events': deleteEvent(id); break;
        case 'tourism': deleteTourismSpot(id); break;
        case 'history': deleteHistoryEvent(id); break;
        case 'jobs': deleteJob(id); break;
        case 'job_cats': deleteJobCategory(id); break;
        case 'job_alerts': deleteJobAlert(id); break;
        case 'freelancers': deleteFreelancer(id); break;
        case 'fm': deleteFMProgram(id); break;
        case 'influencers': deleteInfluencer(id); break;
        case 'contacts': deleteContact(id); break;
        case 'users': if (id !== 'admin_01') deleteUser(id); break;
        case 'properties': deleteProperty(id); break;
        case 'agents': deleteAgent(id); break;
        case 'finance': deleteTransaction(id); break;
        case 'alerts': deleteBroadcast(id); break;
    }
    refreshData();
  };

  const handleSave = (item: any) => {
    switch (activeSection) {
        case 'businesses': saveBusiness(item); break;
        case 'paid_ads': saveAd(item); break;
        case 'hero': saveHeroSlide(item); break;
        case 'news': saveNews(item); break;
        case 'events': saveEvent(item); break;
        case 'tourism': saveTourismSpot(item); break;
        case 'history': saveHistoryEvent(item); break;
        case 'jobs': saveJob(item); break;
        case 'job_cats': saveJobCategory(item); break;
        case 'freelancers': saveFreelancer(item); break;
        case 'fm': saveFMProgram(item); break;
        case 'influencers': saveInfluencer(item); break;
        case 'contacts': saveContact(item); break;
        case 'users': saveUser(item); break;
        case 'stats': saveTownStats(item); break;
        case 'properties': saveProperty(item); break;
        case 'agents': saveAgent(item); break;
        case 'alerts': saveBroadcast(item); break;
    }
    setView('list');
    refreshData();
  };

  const handleReorderPersist = (newItems: any[]) => {
    setData(newItems);
    switch (activeSection) {
        case 'hero': saveAllHeroSlides(newItems); break;
        case 'news': saveAllNews(newItems); break;
        case 'events': saveAllEvents(newItems); break;
        case 'tourism': saveAllTourismSpots(newItems); break;
        case 'history': saveAllHistoryEvents(newItems); break;
        case 'fm': saveAllFMPrograms(newItems); break;
        case 'influencers': saveAllInfluencers(newItems); break;
        case 'contacts': saveAllContacts(newItems); break;
        case 'jobs': saveAllJobs(newItems); break;
        case 'freelancers': saveAllFreelancers(newItems); break;
        case 'properties': saveAllProperties(newItems); break;
        case 'agents': saveAllAgents(newItems); break;
        case 'businesses': saveAllBusinesses(newItems); break;
        case 'paid_ads': saveAllAds(newItems); break;
        case 'users': saveAllUsers(newItems); break;
    }
  };

  const sidebarItems: { id: AdminSection; label: string; icon: React.ReactNode }[] = [
    { id: 'analytics', label: 'Overview', icon: <IconChart className="w-4 h-4" /> },
    { id: 'finance', label: 'Finance', icon: <IconCurrency className="w-4 h-4" /> },
    { id: 'alerts', label: 'WhatsApp', icon: <IconWhatsapp className="w-4 h-4" /> },
    { id: 'stats', label: 'Town Stats', icon: <IconTrendingUp className="w-4 h-4" /> },
    { id: 'paid_ads', label: 'Paid Ads', icon: <IconTrendingUp className="w-4 h-4" /> },
    { id: 'properties', label: 'Real Estate', icon: <IconHome className="w-4 h-4" /> },
    { id: 'agents', label: 'Agents', icon: <IconUser className="w-4 h-4" /> },
    { id: 'businesses', label: 'Shops', icon: <IconHome className="w-4 h-4" /> },
    { id: 'hero', label: 'Sliders', icon: <IconPalette className="w-4 h-4" /> },
    { id: 'news', label: 'News', icon: <IconMail className="w-4 h-4" /> },
    { id: 'events', label: 'Events', icon: <IconTicket className="w-4 h-4" /> },
    { id: 'tourism', label: 'Visit', icon: <IconMapPin className="w-4 h-4" /> },
    { id: 'history', label: 'History', icon: <IconBook className="w-4 h-4" /> },
    { id: 'jobs', label: 'Jobs', icon: <IconBriefcase className="w-4 h-4" /> },
    { id: 'job_cats', label: 'Job Categories', icon: <IconFilter className="w-4 h-4" /> },
    { id: 'job_alerts', label: 'Job Alerts', icon: <IconMail className="w-4 h-4" /> },
    { id: 'freelancers', label: 'Talent', icon: <IconUser className="w-4 h-4" /> },
    { id: 'fm', label: 'Radio', icon: <IconRadio className="w-4 h-4" /> },
    { id: 'influencers', label: 'Stars', icon: <IconStar className="w-4 h-4" /> },
    { id: 'contacts', label: 'Emerg.', icon: <IconPhone className="w-4 h-4" /> },
    { id: 'reviews', label: 'Reviews', icon: <IconMessage className="w-4 h-4" /> },
    { id: 'users', label: 'Staff', icon: <IconUser className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50 lg:flex">
      <aside className="w-72 bg-white border-r border-gray-100 hidden lg:flex flex-col sticky top-20 h-[calc(100vh-80px)] overflow-y-auto no-scrollbar py-8 px-6">
        <h2 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">Management Panel</h2>
        <nav className="space-y-1">
            {sidebarItems.map(item => (
                <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-sm font-bold transition-all ${activeSection === item.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'text-gray-500 hover:bg-gray-50'}`}
                >
                    {item.icon} {item.label}
                </button>
            ))}
        </nav>
      </aside>

      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-12">
        <div className="max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-10">
                <div>
                    <h1 className="text-3xl sm:text-4xl font-black text-gray-900 tracking-tighter">Admin Dashboard</h1>
                    <p className="text-gray-500 font-medium text-sm mt-1 uppercase tracking-widest">{activeSection === 'job_cats' ? 'Job Categories' : activeSection} Management</p>
                </div>
                {view === 'list' && !['analytics', 'reviews', 'stats', 'job_alerts', 'finance', 'alerts'].includes(activeSection) && (
                    <button onClick={() => { setEditingId(null); setView('form'); }} className="w-full sm:w-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-sm shadow-xl shadow-indigo-100 active:scale-95 transition-all">
                        + New Record
                    </button>
                )}
            </div>

            <div className="lg:hidden flex overflow-x-auto gap-2 mb-8 no-scrollbar -mx-4 px-4 py-1">
                {sidebarItems.map(item => (
                    <button
                        key={item.id}
                        onClick={() => setActiveSection(item.id)}
                        className={`px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-widest whitespace-nowrap border transition-all ${activeSection === item.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-gray-500 border-gray-200'}`}
                    >
                        {item.label}
                    </button>
                ))}
            </div>

            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                {activeSection === 'stats' ? (
                    <StatsForm initialStats={townStats} onSave={handleSave} />
                ) : activeSection === 'alerts' ? (
                    <AlertsView broadcasts={data} onSend={handleSave} />
                ) : view === 'form' ? (
                    <div className="space-y-6">
                        <button onClick={() => setView('list')} className="text-indigo-600 font-black text-xs uppercase tracking-widest flex items-center gap-2 mb-4">&larr; Back to Listings</button>
                        {editingId ? (
                            activeSection === 'businesses' ? <AdminForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'paid_ads' ? <AdminAdForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'hero' ? <HeroSlideForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'news' ? <NewsForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'events' ? <EventForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'tourism' ? <TourismForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'history' ? <HistoryForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'jobs' ? <JobForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'job_cats' ? <JobCategoryForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'freelancers' ? <FreelancerForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'fm' ? <FMProgramForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'influencers' ? <InfluencerForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'contacts' ? <ContactForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> :
                            activeSection === 'users' ? <UserForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> : 
                            activeSection === 'properties' ? <PropertyForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> : 
                            activeSection === 'agents' ? <AgentForm initialData={data.find(d => d.id === editingId)} onSave={handleSave} onCancel={() => setView('list')} /> : null
                        ) : (
                             activeSection === 'businesses' ? <AdminForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'paid_ads' ? <AdminAdForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'hero' ? <HeroSlideForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'news' ? <NewsForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'events' ? <EventForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'tourism' ? <TourismForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'history' ? <HistoryForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'jobs' ? <JobForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'job_cats' ? <JobCategoryForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'freelancers' ? <FreelancerForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'fm' ? <FMProgramForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'influencers' ? <InfluencerForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'contacts' ? <ContactForm onSave={handleSave} onCancel={() => setView('list')} /> :
                             activeSection === 'users' ? <UserForm onSave={handleSave} onCancel={() => setView('list')} /> : 
                             activeSection === 'properties' ? <PropertyForm onSave={handleSave} onCancel={() => setView('list')} /> : 
                             activeSection === 'agents' ? <AgentForm onSave={handleSave} onCancel={() => setView('list')} /> : null
                        )}
                    </div>
                ) : (
                    <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden min-h-[500px]">
                        {activeSection === 'analytics' ? (
                            <AnalyticsView analytics={analytics || getAnalytics()} />
                        ) : activeSection === 'finance' ? (
                            <FinanceList transactions={data} onDelete={handleDelete} />
                        ) : activeSection === 'reviews' ? (
                            <ReviewsList reviews={data} onDelete={() => refreshData()} />
                        ) : activeSection === 'job_alerts' ? (
                            <JobAlertsList alerts={data} onDelete={handleDelete} />
                        ) : activeSection === 'paid_ads' ? (
                            <AdsManagementList 
                                ads={data} 
                                onEdit={handleEdit} 
                                onDelete={handleDelete} 
                                onStatusUpdate={(ids, status) => {
                                    const updatedAds = data.map(ad => 
                                        ids.includes(ad.id) ? { ...ad, status } : ad
                                    );
                                    handleReorderPersist(updatedAds);
                                }}
                            />
                        ) : (
                            <GenericAdminList 
                                items={data} 
                                onEdit={handleEdit} 
                                onDelete={handleDelete} 
                                onReorder={handleReorderPersist} 
                                allowReorder={!['analytics', 'reviews', 'stats', 'job_alerts', 'job_cats', 'finance'].includes(activeSection)}
                            />
                        )}
                    </div>
                )}
            </div>
        </div>
      </main>
    </div>
  );
};

const AlertsView = ({ broadcasts, onSend }: { broadcasts: Broadcast[], onSend: (b: Broadcast) => void }) => {
    const [msg, setMsg] = useState('');
    const [type, setType] = useState<Broadcast['recipientType']>('all');
    const [cat, setCat] = useState<Category>(Category.OTHER);
    const [isSending, setIsSending] = useState(false);
    const [progress, setProgress] = useState(0);

    const handleSend = () => {
        if (!msg.trim()) return;
        setIsSending(true);
        
        // Simulation of sending process
        let p = 0;
        const interval = setInterval(() => {
            p += 10;
            setProgress(p);
            if (p >= 100) {
                clearInterval(interval);
                const businesses = getBusinesses();
                let count = 0;
                if (type === 'all') count = businesses.length;
                else if (type === 'category') count = businesses.filter(b => b.category === cat).length;
                else count = getTransactions().filter(t => t.status === 'pending').length;

                onSend({
                    id: Date.now().toString(),
                    message: msg,
                    recipientType: type,
                    targetCategory: type === 'category' ? cat : undefined,
                    sentAt: Date.now(),
                    recipientCount: count,
                    status: 'completed'
                });
                setMsg('');
                setIsSending(false);
                setProgress(0);
                alert(`Broadcast sent to ${count} WhatsApp contacts!`);
            }
        }, 300);
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
                <div>
                    <h3 className="text-2xl font-black text-gray-900 mb-2">Compose WhatsApp Alert</h3>
                    <p className="text-gray-500 font-medium">Draft important town-wide updates or payment reminders.</p>
                </div>
                
                <div className="space-y-6">
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Recipient Group</label>
                        <div className="grid grid-cols-3 gap-2">
                            {[
                                { id: 'all', label: 'All Listings' },
                                { id: 'debtors', label: 'Unpaid Dues' },
                                { id: 'category', label: 'By Category' }
                            ].map(opt => (
                                <button
                                    key={opt.id}
                                    onClick={() => setType(opt.id as any)}
                                    className={`px-4 py-3 rounded-2xl text-[10px] font-black uppercase transition-all border ${type === opt.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-gray-50 text-gray-500 border-gray-200 hover:border-indigo-300'}`}
                                >
                                    {opt.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    {type === 'category' && (
                        <div className="animate-in slide-in-from-top-2">
                            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Target Sector</label>
                            <select 
                                value={cat} 
                                onChange={e => setCat(e.target.value as any)}
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none font-bold"
                            >
                                {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                    )}

                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Message Content</label>
                        <textarea 
                            value={msg}
                            onChange={e => setMsg(e.target.value)}
                            rows={6}
                            placeholder="Type your WhatsApp update here..."
                            className="w-full p-6 bg-emerald-50/30 border-2 border-emerald-100 rounded-3xl outline-none focus:border-emerald-500 transition-all font-medium text-gray-700 resize-none"
                        />
                        <div className="mt-3 flex flex-wrap gap-2">
                             <span className="text-[10px] font-black text-gray-400 uppercase mr-2 mt-1.5">Templates:</span>
                             <button onClick={() => setMsg("URGENT: Your Featured Listing for ManaDHONE expires in 2 days. Pay ₹499 to keep your top spot. Link: dhone.town/pay")} className="px-3 py-1.5 bg-gray-100 rounded-lg text-[10px] font-bold text-gray-600 hover:bg-indigo-100 hover:text-indigo-600 transition-colors">Payment Due</button>
                             <button onClick={() => setMsg("Namaskaram! A new town event has been added to ManaDHONE. Check the 'Events' section for details and movie timings.")} className="px-3 py-1.5 bg-gray-100 rounded-lg text-[10px] font-bold text-gray-600 hover:bg-indigo-100 hover:text-indigo-600 transition-colors">New Event</button>
                        </div>
                    </div>

                    <button 
                        onClick={handleSend}
                        disabled={isSending || !msg.trim()}
                        className={`w-full py-5 rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-xl transition-all active:scale-95 flex items-center justify-center gap-3 ${isSending ? 'bg-gray-100 text-gray-400' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200'}`}
                    >
                        {isSending ? (
                            <>Sending to Queue... {progress}%</>
                        ) : (
                            <><IconWhatsapp className="w-5 h-5" /> Blast WhatsApp Alert</>
                        )}
                    </button>
                </div>
            </div>

            <div className="space-y-6">
                <h3 className="text-xl font-black text-gray-900 px-2 flex items-center gap-3">
                    <IconSend className="w-5 h-5 text-indigo-500" />
                    Broadcast History
                </h3>
                <div className="space-y-4">
                    {broadcasts.length > 0 ? broadcasts.sort((a,b) => b.sentAt - a.sentAt).map(b => (
                        <div key={b.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm group">
                            <div className="flex justify-between items-start mb-4">
                                <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${b.recipientType === 'debtors' ? 'bg-red-50 text-red-600' : 'bg-indigo-50 text-indigo-600'}`}>
                                    Target: {b.recipientType}
                                </span>
                                <span className="text-[10px] font-bold text-gray-400">{new Date(b.sentAt).toLocaleString()}</span>
                            </div>
                            <p className="text-sm text-gray-600 font-medium mb-4 line-clamp-2 italic">"{b.message}"</p>
                            <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1.5">
                                    <IconCheck className="w-3 h-3" /> Sent to {b.recipientCount} Contacts
                                </span>
                                <button onClick={() => deleteBroadcast(b.id)} className="text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                                    <IconTrash className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    )) : (
                        <div className="p-20 bg-white rounded-[3rem] border border-gray-100 border-dashed text-center text-gray-400 font-bold italic">
                            No messages have been sent yet.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const FinanceList = ({ transactions, onDelete }: { transactions: Transaction[], onDelete: (id: string) => void }) => {
    const total = transactions.reduce((sum, t) => sum + (t.status === 'success' ? t.amount : 0), 0);
    
    const sendReminder = (txn: Transaction) => {
        const text = encodeURIComponent(`Namaskaram ${txn.customerName},\n\nThis is a friendly reminder from ManaDHONE Admin regarding your pending payment for: ${txn.itemName || txn.type}.\n\nAmount Due: ₹${txn.amount}\nReference: ${txn.id}\n\nPlease complete the payment to keep your listing active. Dhanyavadalu!`);
        window.open(`https://wa.me/?text=${text}`, '_blank');
    };

    return (
        <div className="flex flex-col h-full">
            <div className="p-8 bg-indigo-50 border-b border-indigo-100 flex justify-between items-center">
                <div>
                    <h3 className="text-2xl font-black text-indigo-900">Revenue Overview</h3>
                    <p className="text-indigo-600 text-sm font-bold mt-1">Town Directory Financial Ledger</p>
                </div>
                <div className="text-right">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Total Collected</p>
                    <p className="text-4xl font-black text-indigo-900">₹{total.toLocaleString()}</p>
                </div>
            </div>
            
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-100">
                        <tr>
                            <th className="p-6">Transaction ID</th>
                            <th className="p-6">Customer</th>
                            <th className="p-6">Service</th>
                            <th className="p-6">Amount</th>
                            <th className="p-6">Status</th>
                            <th className="p-6 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                        {transactions.length > 0 ? transactions.map(txn => (
                            <tr key={txn.id} className="group hover:bg-indigo-50/20 transition-colors">
                                <td className="p-6">
                                    <p className="font-mono text-xs font-bold text-slate-900">{txn.id}</p>
                                    <p className="text-[10px] text-slate-400 font-bold mt-1">{new Date(txn.createdAt).toLocaleString()}</p>
                                </td>
                                <td className="p-6">
                                    <p className="font-bold text-slate-800 text-sm">{txn.customerEmail}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{txn.method}</p>
                                </td>
                                <td className="p-6">
                                    <span className="text-xs font-black uppercase tracking-tighter bg-slate-100 text-slate-600 px-2 py-1 rounded">
                                        {txn.type}
                                    </span>
                                </td>
                                <td className="p-6">
                                    <p className="font-black text-slate-900">₹{txn.amount}</p>
                                </td>
                                <td className="p-6">
                                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                                        txn.status === 'success' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                                    }`}>
                                        {txn.status === 'success' ? 'Settled' : 'Pending'}
                                    </span>
                                </td>
                                <td className="p-6 text-right">
                                    <div className="flex justify-end gap-2">
                                        {txn.status === 'pending' && (
                                            <button 
                                                onClick={() => sendReminder(txn)} 
                                                className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-600 hover:text-white transition-all shadow-sm flex items-center gap-2 text-[10px] font-black uppercase"
                                            >
                                                <IconWhatsapp className="w-4 h-4" /> Remind
                                            </button>
                                        )}
                                        <button onClick={() => onDelete(txn.id)} className="p-2 text-slate-200 hover:text-red-500 transition-colors">
                                            <IconTrash className="w-4 h-4" />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={6} className="p-20 text-center text-slate-400 font-bold italic">No financial records found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const AdsManagementList = ({ ads, onEdit, onDelete, onStatusUpdate }: { ads: Advert[], onEdit: (id: string) => void, onDelete: (id: string) => void, onStatusUpdate: (ids: string[], status: any) => void }) => {
    const [filter, setFilter] = useState<'all' | 'approved' | 'pending' | 'rejected'>('all');
    const [selectedIds, setSelectedIds] = useState<string[]>([]);

    const filteredAds = useMemo(() => {
        if (filter === 'all') return ads;
        return ads.filter(ad => ad.status === filter);
    }, [ads, filter]);

    const toggleSelect = (id: string) => {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    const toggleSelectAll = () => {
        if (selectedIds.length === filteredAds.length) setSelectedIds([]);
        else setSelectedIds(filteredAds.map(ad => ad.id));
    };

    const handleBulkStatus = (status: 'approved' | 'pending' | 'rejected') => {
        onStatusUpdate(selectedIds, status);
        setSelectedIds([]);
    };

    const handleBulkDelete = () => {
        if (!window.confirm(`Delete ${selectedIds.length} ads permanently?`)) return;
        selectedIds.forEach(id => onDelete(id));
        setSelectedIds([]);
    };

    return (
        <div className="flex flex-col h-full">
            {/* Header / Filter Bar */}
            <div className="p-6 border-b border-gray-50 flex flex-wrap items-center justify-between gap-4 bg-gray-50/30">
                <div className="flex gap-2 p-1 bg-white rounded-xl shadow-sm border border-gray-100">
                    {[
                        { id: 'all', label: 'All Campaigns' },
                        { id: 'approved', label: 'Active' },
                        { id: 'pending', label: 'Pending' },
                        { id: 'rejected', label: 'Inactive' }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setFilter(tab.id as any)}
                            className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${filter === tab.id ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {selectedIds.length > 0 && (
                    <div className="flex items-center gap-2 animate-in slide-in-from-right-4">
                        <span className="text-[10px] font-black text-indigo-600 uppercase bg-indigo-50 px-3 py-2 rounded-lg border border-indigo-100">
                            {selectedIds.length} Selected
                        </span>
                        <div className="h-4 w-px bg-gray-200 mx-2"></div>
                        <button onClick={() => handleBulkStatus('approved')} className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-600 hover:text-white transition-all shadow-sm" title="Mark Active">
                            <IconCheck className="w-5 h-5" />
                        </button>
                        <button onClick={() => handleBulkStatus('rejected')} className="p-2 bg-slate-50 text-slate-600 rounded-lg hover:bg-slate-600 hover:text-white transition-all shadow-sm" title="Mark Inactive">
                            <IconPause className="w-5 h-5" />
                        </button>
                        <button onClick={handleBulkDelete} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-600 hover:text-white transition-all shadow-sm" title="Delete Selection">
                            <IconTrash className="w-5 h-5" />
                        </button>
                    </div>
                )}
            </div>

            {/* Ads List */}
            <div className="divide-y divide-gray-50">
                {filteredAds.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                <tr>
                                    <th className="p-6 w-12">
                                        <input 
                                            type="checkbox" 
                                            checked={selectedIds.length > 0 && selectedIds.length === filteredAds.length} 
                                            onChange={toggleSelectAll}
                                            className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                        />
                                    </th>
                                    <th className="p-6">Advertisement</th>
                                    <th className="p-6">Status</th>
                                    <th className="p-6">Placement</th>
                                    <th className="p-6 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {filteredAds.map(ad => (
                                    <tr key={ad.id} className={`group hover:bg-indigo-50/20 transition-colors ${selectedIds.includes(ad.id) ? 'bg-indigo-50/50' : ''}`}>
                                        <td className="p-6">
                                            <input 
                                                type="checkbox" 
                                                checked={selectedIds.includes(ad.id)} 
                                                onChange={() => toggleSelect(ad.id)}
                                                className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                            />
                                        </td>
                                        <td className="p-6">
                                            <div className="flex items-center gap-4">
                                                <img src={ad.imageUrl} className="w-20 h-12 rounded-lg object-cover border border-gray-100 shadow-sm" alt="" />
                                                <div className="min-w-0">
                                                    <h4 className="font-black text-gray-900 truncate">{ad.title}</h4>
                                                    <p className="text-xs text-gray-500 line-clamp-1">{ad.description}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="p-6">
                                            <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                                                ad.status === 'approved' ? 'bg-emerald-50 text-emerald-600' :
                                                ad.status === 'pending' ? 'bg-amber-50 text-amber-600' :
                                                'bg-slate-50 text-slate-500'
                                            }`}>
                                                <span className={`w-1.5 h-1.5 rounded-full ${
                                                    ad.status === 'approved' ? 'bg-emerald-500' :
                                                    ad.status === 'pending' ? 'bg-amber-500' :
                                                    'bg-slate-400'
                                                }`}></span>
                                                {ad.status === 'approved' ? 'Active' : ad.status === 'pending' ? 'Pending' : 'Inactive'}
                                            </span>
                                        </td>
                                        <td className="p-6 text-xs font-bold text-gray-400 uppercase tracking-widest">
                                            {ad.page || 'Home'} Slider
                                        </td>
                                        <td className="p-6 text-right">
                                            <div className="flex justify-end gap-2">
                                                <button onClick={() => onEdit(ad.id)} className="p-2 bg-white border border-gray-100 text-gray-400 hover:text-indigo-600 hover:border-indigo-100 rounded-lg transition-all shadow-sm">
                                                    <IconEdit className="w-4 h-4" />
                                                </button>
                                                <button onClick={() => onDelete(ad.id)} className="p-2 bg-white border border-gray-100 text-gray-400 hover:text-red-600 hover:border-red-100 rounded-lg transition-all shadow-sm">
                                                    <IconTrash className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="p-32 text-center flex flex-col items-center">
                        <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-6 text-gray-200">
                            <IconTrendingUp className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-400 italic">No advertisements found in this category.</h3>
                    </div>
                )}
            </div>
        </div>
    );
};

const JobAlertsList = ({ alerts, onDelete }: { alerts: JobAlert[], onDelete: (id: string) => void }) => (
    <div className="divide-y divide-gray-50">
        {alerts.length > 0 ? alerts.map(alert => (
            <div key={alert.id} className="p-6 flex items-center justify-between hover:bg-gray-50/50 transition-colors">
                <div>
                    <h4 className="font-black text-gray-900">{alert.email}</h4>
                    <div className="flex gap-2 mt-1">
                        <span className="text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">Category: {alert.category}</span>
                        <span className="text-[10px] font-black uppercase tracking-widest text-teal-600 bg-teal-50 px-2 py-0.5 rounded">Type: {alert.type}</span>
                        {alert.keywords && <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-2 py-0.5 rounded">KW: {alert.keywords}</span>}
                    </div>
                </div>
                <button onClick={() => onDelete(alert.id)} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm">
                    <IconTrash className="w-5 h-5" />
                </button>
            </div>
        )) : (
            <div className="p-20 text-center font-bold text-gray-400 italic">No job alerts registered yet.</div>
        )}
    </div>
);

const StatsForm = ({ initialStats, onSave }: { initialStats: TownStats, onSave: (stats: TownStats) => void }) => {
    const [stats, setStats] = useState<TownStats>(initialStats);
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setStats({ ...stats, [e.target.name]: e.target.value, lastUpdated: Date.now() });
    };

    return (
        <div className="bg-white p-8 sm:p-12 rounded-[2.5rem] shadow-xl border border-gray-100 max-w-2xl mx-auto">
            <h3 className="text-2xl font-black mb-8 text-gray-900 tracking-tight">Edit Town Demographics</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Town Residents</label>
                    <input name="residents" value={stats.residents} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold focus:border-indigo-500 outline-none" placeholder="e.g. 50k+" />
                </div>
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Daily Visitors</label>
                    <input name="dailyVisitors" value={stats.dailyVisitors} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold focus:border-indigo-500 outline-none" placeholder="e.g. 1.2k+" />
                </div>
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Verified Shops</label>
                    <input name="verifiedShops" value={stats.verifiedShops} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold focus:border-indigo-500 outline-none" placeholder="e.g. 250+" />
                </div>
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Active Listings</label>
                    <input name="activeListings" value={stats.activeListings} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl font-bold focus:border-indigo-500 outline-none" placeholder="e.g. 500+" />
                </div>
            </div>
            <button onClick={() => onSave(stats)} className="mt-10 w-full py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl hover:bg-indigo-700 transition-all active:scale-95">
                Save & Update Footer
            </button>
        </div>
    );
};

const AnalyticsView = ({ analytics }: { analytics: AnalyticsData }) => (
    <div className="p-6 sm:p-10 space-y-10">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
                { label: 'Total Engagement', val: analytics.totalViews, bg: 'bg-indigo-50', text: 'text-indigo-600' },
                { label: 'Community Reviews', val: analytics.totalReviews, bg: 'bg-emerald-50', text: 'text-emerald-600' },
                { label: 'Total Businesses', val: getBusinesses().length, bg: 'bg-amber-50', text: 'text-amber-600' }
            ].map((stat, i) => (
                <div key={i} className={`${stat.bg} p-8 rounded-[2rem] text-center border border-black/5 shadow-sm`}>
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">{stat.label}</p>
                    <h3 className={`text-4xl font-black ${stat.text}`}>{stat.val.toLocaleString()}</h3>
                </div>
            ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                <h4 className="font-black text-gray-900 mb-6 flex items-center gap-2"><IconTrendingUp className="w-5 h-5 text-indigo-500" /> Top Businesses</h4>
                <div className="space-y-4">
                    {analytics.topBusinesses.map(b => (
                        <div key={b.id} className="bg-white p-4 rounded-2xl shadow-sm flex justify-between items-center border border-gray-50">
                            <span className="font-bold text-gray-700 truncate mr-4">{b.name}</span>
                            <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">{b.views} hits</span>
                        </div>
                    ))}
                </div>
            </div>
            <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                <h4 className="font-black text-gray-900 mb-6 flex items-center gap-2"><IconChart className="w-5 h-5 text-emerald-500" /> Category Breakdown</h4>
                <div className="space-y-5">
                    {Object.entries(analytics.categoryViews).map(([cat, v]) => (
                        <div key={cat}>
                            <div className="flex justify-between text-xs font-black uppercase tracking-widest text-gray-400 mb-2"><span>{cat}</span><span>{v}</span></div>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${analytics.totalViews > 0 ? (v/analytics.totalViews)*100 : 0}%` }}></div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
);

const GenericAdminList = ({ items, onEdit, onDelete, onReorder, allowReorder }: { items: any[], onEdit: (id: string) => void, onDelete: (id: string) => void, onReorder?: (newItems: any[]) => void, allowReorder?: boolean }) => {
    const [localItems, setLocalItems] = useState<any[]>([]);
    const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
    const [search, setSearch] = useState('');

    // Keep local items in sync with parent when items prop changes (but not during drag)
    useEffect(() => {
        if (draggedIndex === null) {
            setLocalItems(items);
        }
    }, [items, draggedIndex]);

    const filteredItems = useMemo(() => {
        if (!search.trim()) return localItems;
        const q = search.toLowerCase();
        return localItems.filter(item => {
            const text = `${item.name || ''} ${item.title || ''} ${item.location || ''} ${item.company || ''}`.toLowerCase();
            return text.includes(q);
        });
    }, [localItems, search]);

    if (!items.length) return <div className="p-20 text-center font-bold text-gray-400 italic">No records available yet.</div>;

    const handleDragStart = (e: React.DragEvent, index: number) => {
        setDraggedIndex(index);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', index.toString());
    };

    const handleDragOver = (e: React.DragEvent, index: number) => {
        e.preventDefault();
        if (draggedIndex === null || draggedIndex === index) return;
        
        const newItems = [...localItems];
        const draggedItem = newItems[draggedIndex];
        newItems.splice(draggedIndex, 1);
        newItems.splice(index, 0, draggedItem);
        
        setLocalItems(newItems);
        setDraggedIndex(index);
    };

    const handleDragEnd = () => {
        if (onReorder) {
            onReorder(localItems);
        }
        setDraggedIndex(null);
    };

    return (
        <div className="flex flex-col">
            {/* Search Bar for Discovery */}
            <div className="p-4 border-b border-gray-50 bg-gray-50/20">
                <div className="relative">
                    <IconSearch className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                        type="text" 
                        placeholder="Search records by name or location..." 
                        className="w-full pl-10 pr-4 py-3 bg-white border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500/20 outline-none font-bold text-sm shadow-sm"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>

            <div className="divide-y divide-gray-50">
                {filteredItems.map((item, index) => {
                    const isPending = item.status === 'pending' || item.status === 'rejected';
                    const isDragging = draggedIndex === index;
                    const isPriority = item.isFeatured === true || item.featured === true;
                    const isVerified = item.verified === true;

                    return (
                        <div 
                            key={item.id} 
                            draggable={allowReorder && !search}
                            onDragStart={(e) => handleDragStart(e, index)}
                            onDragOver={(e) => handleDragOver(e, index)}
                            onDragEnd={handleDragEnd}
                            className={`p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all duration-200 ${isDragging ? 'opacity-10 scale-95 grayscale' : isPending ? 'bg-amber-50/50 hover:bg-amber-50' : 'hover:bg-gray-50/30'} ${allowReorder && !search ? 'cursor-grab active:cursor-grabbing' : ''}`}
                        >
                            <div className="flex items-center gap-4 min-w-0">
                                {allowReorder && !search && (
                                    <div className="text-gray-300 shrink-0 hover:text-indigo-400 transition-colors">
                                        <IconGrip className="w-5 h-5" />
                                    </div>
                                )}
                                {item.imageUrl && <img src={item.imageUrl} className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-gray-100 shadow-sm" alt="" />}
                                <div className="min-w-0">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <h4 className="font-black text-gray-900 truncate text-base">{item.name || item.title || item.time || item.year}</h4>
                                        <div className="flex gap-1">
                                            {isPending && <span className="bg-amber-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest">Awaiting Verification</span>}
                                            {isVerified && <span className="bg-blue-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest flex items-center gap-1 shadow-sm"><IconCheck className="w-2 h-2" /> Verified</span>}
                                            {isPriority && <span className="bg-indigo-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest flex items-center gap-1 shadow-sm"><IconStar fill className="w-2 h-2" /> Top Priority</span>}
                                        </div>
                                    </div>
                                    <p className="text-xs font-bold text-gray-400 truncate mt-0.5">{item.category || item.company || item.location || (item.purpose ? `For ${item.purpose}` : 'Active Record')}</p>
                                </div>
                            </div>
                            <div className="flex gap-2 shrink-0">
                                <button onClick={() => onEdit(item.id)} className={`flex-1 sm:flex-none p-3 rounded-xl transition-all shadow-sm ${isPending ? 'bg-amber-500 text-white hover:bg-amber-600' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white'}`}>
                                    <IconEdit className="w-5 h-5 mx-auto" />
                                </button>
                                <button onClick={() => onDelete(item.id)} className="flex-1 sm:flex-none p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm">
                                    <IconTrash className="w-5 h-5 mx-auto" />
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const ReviewsList = ({ reviews, onDelete }: { reviews: ReviewWithBusiness[], onDelete: () => void }) => (
    <div className="divide-y divide-gray-50">
        {reviews.map(r => (
            <div key={r.id} className="p-8 flex flex-col sm:flex-row justify-between gap-6 hover:bg-gray-50/30 transition-colors">
                <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                        <span className="font-black text-gray-900 text-lg">{r.author}</span>
                        <span className="text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">on {r.businessName}</span>
                    </div>
                    <div className="flex text-amber-400 mb-3">
                        {Array.from({ length: 5 }).map((_, i) => <IconStar key={i} fill={i < r.rating} className="w-4 h-4" />)}
                    </div>
                    <p className="text-gray-600 italic font-medium leading-relaxed">"{r.comment}"</p>
                </div>
                <button onClick={() => { deleteReview(r.businessId, r.id); onDelete(); }} className="self-end sm:self-center p-4 bg-red-50 text-red-600 rounded-2xl hover:bg-red-600 hover:text-white transition-all"><IconTrash className="w-6 h-6" /></button>
            </div>
        ))}
    </div>
);

export default Admin;
