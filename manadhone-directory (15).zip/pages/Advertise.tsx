
import React, { useState } from 'react';
/* Added missing Link import */
import { Link } from 'react-router-dom';
import { AdType, AdRequest } from '../types';
import { saveAdRequest } from '../services/storageService';
/* Added missing IconCheck import */
import { IconSend, IconChart, IconTrendingUp, IconUser, IconCheck } from '../components/Icons';
import PaymentModal from '../components/PaymentModal';

const Advertise: React.FC = () => {
    const [formState, setFormState] = useState<Partial<AdRequest>>({
        businessName: '',
        contactPerson: '',
        email: '',
        phone: '',
        adType: AdType.BANNER,
        message: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSent, setIsSent] = useState(false);
    
    // Payment State
    const [showPayment, setShowPayment] = useState(false);
    const [pendingRequest, setPendingRequest] = useState<AdRequest | null>(null);

    const adPrices: Record<AdType, number> = {
        [AdType.BANNER]: 999,
        [AdType.FEATURED]: 499,
        [AdType.SIDEBAR]: 299,
        [AdType.NEWS_NATIVE]: 599
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        const request: AdRequest = {
            id: Date.now().toString(),
            businessName: formState.businessName!,
            contactPerson: formState.contactPerson!,
            email: formState.email!,
            phone: formState.phone!,
            adType: formState.adType!,
            message: formState.message || '',
            status: 'pending',
            createdAt: Date.now()
        };

        setPendingRequest(request);
        
        // Simulate quick validation delay before showing payment
        setTimeout(() => {
            setIsSubmitting(false);
            setShowPayment(true);
        }, 1000);
    };

    const handlePaymentSuccess = (transactionId: string) => {
        if (pendingRequest) {
            const finalRequest = { ...pendingRequest, paymentId: transactionId };
            saveAdRequest(finalRequest);
            setShowPayment(false);
            setIsSent(true);
        }
    };

    const options = [
        { 
            type: AdType.BANNER, 
            title: 'Main Banner Slider', 
            desc: 'Maximum visibility on our homepage with high-impact visuals.', 
            icon: <IconTrendingUp className="w-8 h-8 text-indigo-600" />,
            price: 999
        },
        { 
            type: AdType.FEATURED, 
            title: 'Featured Listing', 
            desc: 'Always appear at the top of search results and category pages.', 
            icon: <IconChart className="w-8 h-8 text-indigo-600" />,
            price: 499
        },
        { 
            type: AdType.SIDEBAR, 
            title: 'Sidebar Widget', 
            desc: 'Target users across multiple pages with consistent branding.', 
            icon: <IconUser className="w-8 h-8 text-indigo-600" />,
            price: 299
        }
    ];

    return (
        <div className="bg-gray-50 min-h-screen py-16">
            <div className="container mx-auto px-4 max-w-6xl">
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 tracking-tight">Grow with <span className="text-indigo-600">ManaDHONE</span></h1>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                        Connect your business with thousands of local residents and visitors every day. 
                        Choose an advertising package that fits your goals.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
                    {options.map((opt) => (
                        <div key={opt.type} className={`bg-white p-8 rounded-[2.5rem] shadow-sm border transition-all duration-300 relative overflow-hidden ${formState.adType === opt.type ? 'border-indigo-600 shadow-xl ring-1 ring-indigo-500' : 'border-gray-100 hover:shadow-xl'}`}>
                            <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
                                {opt.icon}
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 mb-1">{opt.title}</h3>
                            <p className="text-indigo-600 font-black mb-3 text-lg">₹{opt.price}</p>
                            <p className="text-gray-500 text-sm leading-relaxed mb-8">{opt.desc}</p>
                            <button 
                                onClick={() => setFormState(prev => ({...prev, adType: opt.type}))}
                                className={`w-full py-3 rounded-xl font-bold transition-all ${formState.adType === opt.type ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}`}
                            >
                                {formState.adType === opt.type ? 'Selected' : 'Select Package'}
                            </button>
                        </div>
                    ))}
                </div>

                <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-gray-100">
                    <div className="flex flex-col lg:flex-row">
                        <div className="lg:w-1/2 bg-indigo-600 p-12 md:p-16 text-white flex flex-col justify-center">
                            <h2 className="text-3xl md:text-4xl font-black mb-6">Get Started Now</h2>
                            <p className="text-indigo-100 text-lg mb-10 leading-relaxed">
                                Complete your details and proceed to secure payment. Your ad will go live within 12 hours after verification.
                            </p>
                            
                            <div className="space-y-6">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md">
                                        <IconTrendingUp className="w-5 h-5 text-white" />
                                    </div>
                                    <span className="font-medium">Direct reach to Dhone community</span>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md">
                                        <IconChart className="w-5 h-5 text-white" />
                                    </div>
                                    <span className="font-medium">Actionable performance analytics</span>
                                </div>
                            </div>

                            <div className="mt-12 pt-12 border-t border-white/10">
                                <p className="text-sm font-black uppercase tracking-widest opacity-60 mb-2">Selected Package</p>
                                <div className="bg-white/10 p-5 rounded-2xl flex justify-between items-center backdrop-blur-md">
                                    <span className="font-bold">{formState.adType}</span>
                                    <span className="text-2xl font-black">₹{formState.adType ? adPrices[formState.adType] : 0}</span>
                                </div>
                            </div>
                        </div>

                        <div className="lg:w-1/2 p-12 md:p-16">
                            {isSent ? (
                                <div className="text-center py-10 animate-in zoom-in duration-300">
                                    <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-green-100">
                                        <IconCheck className="w-10 h-10" />
                                    </div>
                                    <h3 className="text-3xl font-black text-gray-900 mb-2">Ad Submitted!</h3>
                                    <p className="text-gray-500 mb-8">Payment received successfully. Our team will review and activate your campaign shortly.</p>
                                    <Link to="/" className="text-indigo-600 font-black hover:underline">Return to Homepage</Link>
                                </div>
                            ) : (
                                <form onSubmit={handleSubmit} className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Business Name</label>
                                            <input 
                                                required
                                                type="text" 
                                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold"
                                                value={formState.businessName}
                                                onChange={e => setFormState({...formState, businessName: e.target.value})}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Contact Name</label>
                                            <input 
                                                required
                                                type="text" 
                                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold"
                                                value={formState.contactPerson}
                                                onChange={e => setFormState({...formState, contactPerson: e.target.value})}
                                            />
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Email</label>
                                            <input 
                                                required
                                                type="email" 
                                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold"
                                                value={formState.email}
                                                onChange={e => setFormState({...formState, email: e.target.value})}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Phone</label>
                                            <input 
                                                required
                                                type="tel" 
                                                className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold"
                                                value={formState.phone}
                                                onChange={e => setFormState({...formState, phone: e.target.value})}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Ad Details</label>
                                        <textarea 
                                            rows={4}
                                            className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all resize-none font-medium"
                                            placeholder="What would you like to say in your ad?"
                                            value={formState.message}
                                            onChange={e => setFormState({...formState, message: e.target.value})}
                                        />
                                    </div>

                                    <button 
                                        type="submit" 
                                        disabled={isSubmitting}
                                        className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-3 disabled:opacity-70 transform hover:-translate-y-1 active:translate-y-0 text-sm uppercase tracking-widest"
                                    >
                                        {isSubmitting ? 'Validating...' : `Proceed to Payment (₹${formState.adType ? adPrices[formState.adType] : 0})`}
                                    </button>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Payment Integration */}
            {showPayment && pendingRequest && (
                <PaymentModal 
                    isOpen={showPayment}
                    onClose={() => setShowPayment(false)}
                    onSuccess={handlePaymentSuccess}
                    amount={adPrices[pendingRequest.adType]}
                    itemName={pendingRequest.adType}
                    itemType="advert"
                    referenceId={pendingRequest.id}
                    customerEmail={pendingRequest.email}
                />
            )}
        </div>
    );
};

export default Advertise;
