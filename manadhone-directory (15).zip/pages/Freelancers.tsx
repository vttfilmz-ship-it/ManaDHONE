
import React, { useEffect, useState, useMemo } from 'react';
import { getFreelancers, saveFreelancer, getHeroSlides } from '../services/storageService';
import { Freelancer, HeroSlide } from '../types';
// Added missing IconStar import
import { IconUser, IconSearch, IconPhone, IconMapPin, IconClock, IconLaptop, IconHome, IconBook, IconPalette, IconBriefcase, IconStar } from '../components/Icons';

const Freelancers: React.FC = () => {
    const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
    const [search, setSearch] = useState('');
    const [filterCategory, setFilterCategory] = useState<string>('All');
    
    // Hero Slider State
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    // Post Profile Modal State
    const [isPostModalOpen, setIsPostModalOpen] = useState(false);
    const [newProfile, setNewProfile] = useState<Partial<Freelancer>>({
        name: '', skill: '', category: 'Other', experience: '', contact: '', description: '', hourlyRate: '', location: 'Dhone', isFeatured: false
    });

    useEffect(() => {
        setFreelancers(getFreelancers());
        const slides = getHeroSlides().filter(s => s.page === 'freelancers' && s.active);
        setHeroSlides(slides);
    }, []);

    // Slider Timer
    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    const categories = [
        { id: 'All', name: 'All Talent', icon: <IconUser className="w-5 h-5" />, color: 'bg-indigo-600', text: 'text-indigo-600', border: 'border-indigo-200' },
        { id: 'Tech', name: 'Tech & Design', icon: <IconLaptop className="w-5 h-5" />, color: 'bg-blue-600', text: 'text-blue-600', border: 'border-blue-200' },
        { id: 'Home Service', name: 'Home Service', icon: <IconHome className="w-5 h-5" />, color: 'bg-orange-600', text: 'text-orange-600', border: 'border-orange-200' },
        { id: 'Education', name: 'Education', icon: <IconBook className="w-5 h-5" />, color: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-200' },
        { id: 'Creative', name: 'Creative', icon: <IconPalette className="w-5 h-5" />, color: 'bg-rose-600', text: 'text-rose-600', border: 'border-rose-200' },
        { id: 'Other', name: 'Other Skills', icon: <IconBriefcase className="w-5 h-5" />, color: 'bg-slate-600', text: 'text-slate-600', border: 'border-slate-200' }
    ];

    const filteredFreelancers = useMemo(() => {
        // Map items to include original admin index for priority tie-breaking
        const itemsWithMeta = freelancers.map((f, index) => ({ f, originalIndex: index }));

        let result = itemsWithMeta.filter(item => {
            // Only show approved
            if (item.f.status !== 'approved') return false;

            const matchesSearch = !search || 
                                  item.f.name.toLowerCase().includes(search.toLowerCase()) || 
                                  item.f.skill.toLowerCase().includes(search.toLowerCase()) ||
                                  item.f.description.toLowerCase().includes(search.toLowerCase());
            const matchesCategory = filterCategory === 'All' || item.f.category === filterCategory;
            return matchesSearch && matchesCategory;
        });

        // Multi-tier sort
        result.sort((a, b) => {
            // Tier 1: Featured/Priority status
            if (a.f.isFeatured && !b.f.isFeatured) return -1;
            if (!a.f.isFeatured && b.f.isFeatured) return 1;

            // Tier 2: Admin Manual Order (the tie-breaker)
            return a.originalIndex - b.originalIndex;
        });

        return result.map(item => item.f);
    }, [freelancers, search, filterCategory]);

    const handlePostProfile = (e: React.FormEvent) => {
        e.preventDefault();
        
        const profileToSave: Freelancer = {
            id: Date.now().toString(),
            status: 'pending',
            name: newProfile.name!,
            skill: newProfile.skill!,
            category: newProfile.category! as any,
            experience: newProfile.experience!,
            contact: newProfile.contact!,
            description: newProfile.description!,
            hourlyRate: newProfile.hourlyRate!,
            location: newProfile.location!,
            imageUrl: `https://i.pravatar.cc/150?u=${Date.now()}`,
            joinedDate: Date.now(),
            isFeatured: false
        };

        saveFreelancer(profileToSave);
        setIsPostModalOpen(false);
        setNewProfile({ name: '', skill: '', category: 'Other', experience: '', contact: '', description: '', hourlyRate: '', location: 'Dhone', isFeatured: false });
        alert("Profile submitted! It will be listed after admin approval.");
        setFreelancers(getFreelancers());
    };

    const getCategoryStyles = (category: string) => {
        return categories.find(c => c.id === category) || categories[5];
    };

    return (
        <div className="bg-gray-50 dark:bg-slate-900 min-h-screen pb-12 transition-colors duration-300 font-sans">
            {/* Hero Section */}
            <div className="bg-teal-800 text-white py-16 relative overflow-hidden h-[400px] flex flex-col items-center justify-center">
                {/* Background Slider */}
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, index) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-60' : 'opacity-0'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover" alt={slide.caption} />
                            <div className="absolute inset-0 bg-teal-900/60 mix-blend-multiply"></div>
                        </div>
                    ))
                ) : (
                    <>
                        <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
                            <div className="absolute -top-20 -left-20 w-80 h-80 bg-white rounded-full blur-[100px]"></div>
                            <div className="absolute top-1/2 right-0 w-60 h-60 bg-teal-400 rounded-full blur-[80px]"></div>
                        </div>
                    </>
                )}
                
                <div className="container mx-auto px-4 text-center relative z-10">
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4 tracking-tight drop-shadow-md">
                        {heroSlides.length > 0 && heroSlides[currentSlide]?.caption 
                            ? heroSlides[currentSlide].caption 
                            : <span>Hire Local Talent in <span className="text-teal-300">Dhone</span></span>}
                    </h1>
                    <p className="text-lg text-teal-100 max-w-2xl mx-auto mb-8 drop-shadow-sm">
                        Find skilled professionals for your needs. Electricians, Tutors, Designers, and more available instantly.
                    </p>

                    {/* Search Bar */}
                    <div className="max-w-3xl mx-auto bg-white p-2 rounded-2xl shadow-xl flex flex-col md:flex-row gap-2">
                        <div className="flex-1 flex items-center px-4 bg-gray-50 rounded-xl border border-gray-100">
                            <IconSearch className="w-5 h-5 text-gray-400" />
                            <input 
                                type="text" 
                                placeholder="Search by name or specific skill (e.g. Electrician, Dev)..." 
                                className="w-full p-3 bg-transparent outline-none text-gray-800 placeholder-gray-500"
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                            />
                        </div>
                    </div>
                    
                    <button 
                        onClick={() => setIsPostModalOpen(true)}
                        className="mt-6 text-sm bg-white text-teal-800 hover:bg-teal-50 font-bold px-6 py-2.5 rounded-full transition-all inline-flex items-center gap-2 shadow-lg"
                    >
                        <IconUser className="w-4 h-4" /> Join as a Freelancer
                    </button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="container mx-auto px-4 py-12 max-w-7xl">
                {/* Visual Category Filter Bar */}
                <div className="flex overflow-x-auto pb-6 gap-3 no-scrollbar mb-8">
                    {categories.map(cat => {
                        const isActive = filterCategory === cat.id;
                        return (
                            <button
                                key={cat.id}
                                onClick={() => setFilterCategory(cat.id)}
                                className={`flex items-center gap-2 px-5 py-3 rounded-2xl border transition-all shrink-0 font-bold text-sm ${
                                    isActive 
                                        ? `${cat.color} text-white shadow-lg scale-105 border-transparent` 
                                        : `bg-white text-gray-600 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/30`
                                }`}
                            >
                                <span className={isActive ? 'text-white' : cat.text}>{cat.icon}</span>
                                {cat.name}
                            </button>
                        );
                    })}
                </div>

                <div className="flex justify-between items-center mb-8">
                    <h2 className="text-2xl font-black text-gray-900 dark:text-white">
                        {filterCategory === 'All' ? 'All Professionals' : filterCategory}
                    </h2>
                    <span className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 text-xs font-bold text-gray-500 px-3 py-1 rounded-full shadow-sm">
                        {filteredFreelancers.length} listing{filteredFreelancers.length !== 1 ? 's' : ''}
                    </span>
                </div>

                {/* Freelancers Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredFreelancers.length > 0 ? (
                        filteredFreelancers.map(f => {
                            const style = getCategoryStyles(f.category);
                            return (
                                <div key={f.id} className={`bg-white dark:bg-slate-800 rounded-[2rem] shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 dark:border-slate-700 overflow-hidden flex flex-col group hover:-translate-y-2 ${f.isFeatured ? 'ring-2 ring-indigo-500 dark:ring-indigo-400' : ''}`}>
                                    <div className="p-8 pb-4 flex items-start gap-5">
                                        <div className="relative shrink-0">
                                            <img 
                                                src={f.imageUrl} 
                                                alt={f.name} 
                                                className="w-20 h-20 rounded-2xl object-cover border-4 border-gray-50 dark:border-slate-700 shadow-md group-hover:rotate-3 transition-transform"
                                            />
                                            <div className={`absolute -bottom-2 -right-2 p-1.5 rounded-lg shadow-md ${style.color} text-white`}>
                                                {/* Fix: cast to React.ReactElement with className prop to satisfy TypeScript */}
                                                {React.cloneElement(style.icon as React.ReactElement<{ className?: string }>, { className: 'w-4 h-4' })}
                                            </div>
                                        </div>
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <h3 className="text-xl font-bold text-gray-900 dark:text-white leading-tight group-hover:text-indigo-600 transition-colors">{f.name}</h3>
                                                {f.isFeatured && <IconStar fill className="w-4 h-4 text-amber-500" />}
                                            </div>
                                            <p className={`font-bold text-sm ${style.text}`}>{f.skill}</p>
                                            <div className={`inline-flex items-center gap-1.5 mt-3 bg-gray-50 dark:bg-slate-700/50 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${style.text} border ${style.border}`}>
                                                {/* Fix: cast to React.ReactElement with className prop to satisfy TypeScript */}
                                                {React.cloneElement(style.icon as React.ReactElement<{ className?: string }>, { className: 'w-3 h-3' })}
                                                {f.category}
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="px-8 py-4 flex-1">
                                        <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed line-clamp-3 italic">
                                            "{f.description}"
                                        </p>
                                        
                                        <div className="grid grid-cols-2 gap-3 mt-6">
                                            <div className="bg-gray-50 dark:bg-slate-700/50 p-2 rounded-xl border border-gray-100 dark:border-slate-600">
                                                <span className="block text-[8px] font-black text-gray-400 uppercase">Experience</span>
                                                <span className="text-xs font-bold text-gray-700 dark:text-gray-200 flex items-center gap-1">
                                                    <IconClock className="w-3 h-3 text-indigo-500" /> {f.experience}
                                                </span>
                                            </div>
                                            <div className="bg-gray-50 dark:bg-slate-700/50 p-2 rounded-xl border border-gray-100 dark:border-slate-600">
                                                <span className="block text-[8px] font-black text-gray-400 uppercase">Location</span>
                                                <span className="text-xs font-bold text-gray-700 dark:text-gray-200 flex items-center gap-1">
                                                    <IconMapPin className="w-3 h-3 text-red-500" /> {f.location}
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="p-6 bg-gray-50/50 dark:bg-slate-900/30 border-t border-gray-50 dark:border-slate-700 flex items-center justify-between">
                                        <div>
                                            <span className="block text-[8px] font-black text-gray-400 uppercase">Service Fee</span>
                                            <span className="text-sm font-black text-gray-900 dark:text-white">{f.hourlyRate || 'Flexible'}</span>
                                        </div>
                                        <a 
                                            href={`tel:${f.contact}`} 
                                            className={`flex items-center justify-center gap-2 ${style.color} hover:brightness-110 text-white font-bold py-2.5 px-6 rounded-xl transition-all shadow-lg active:scale-95`}
                                        >
                                            <IconPhone className="w-4 h-4" /> Contact
                                        </a>
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="col-span-full text-center py-32 bg-white dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-gray-200 dark:border-slate-700">
                            <div className="bg-gray-50 dark:bg-slate-700 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                                <IconUser className="w-12 h-12 text-gray-300" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">No Profiles Found</h3>
                            <p className="text-gray-500 max-w-sm mx-auto mt-2">We couldn't find any professionals matching your search or selected category.</p>
                            <button 
                                onClick={() => {setSearch(''); setFilterCategory('All');}}
                                className="mt-8 text-indigo-600 font-bold hover:underline"
                            >
                                Clear all filters
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {/* Join Modal */}
            {isPostModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-slate-800 rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
                        <div className="bg-teal-600 p-8 text-white flex justify-between items-center shrink-0">
                            <div>
                                <h3 className="text-2xl font-black">Join as a Freelancer</h3>
                                <p className="text-teal-100 text-sm font-medium mt-1">Create your profile and start getting local projects.</p>
                            </div>
                            <button onClick={() => setIsPostModalOpen(false)} className="bg-white/20 hover:bg-white/40 p-2 rounded-full transition-colors">
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        
                        <div className="p-8 overflow-y-auto custom-scrollbar">
                            <form onSubmit={handlePostProfile} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                                        <input 
                                            required 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all" 
                                            value={newProfile.name} 
                                            onChange={e => setNewProfile({...newProfile, name: e.target.value})}
                                            placeholder="e.g. Ramesh Varma"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Primary Skill / Title</label>
                                        <input 
                                            required 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all" 
                                            value={newProfile.skill} 
                                            onChange={e => setNewProfile({...newProfile, skill: e.target.value})}
                                            placeholder="e.g. Professional Electrician"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Category</label>
                                        <select 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all appearance-none" 
                                            value={newProfile.category} 
                                            onChange={e => setNewProfile({...newProfile, category: e.target.value as any})}
                                        >
                                            <option value="Tech">Tech & Design</option>
                                            <option value="Home Service">Home Service</option>
                                            <option value="Education">Education</option>
                                            <option value="Creative">Creative</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Experience</label>
                                        <input 
                                            required 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all" 
                                            value={newProfile.experience} 
                                            onChange={e => setNewProfile({...newProfile, experience: e.target.value})}
                                            placeholder="e.g. 5 Years"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Contact Number</label>
                                        <input 
                                            required 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all" 
                                            value={newProfile.contact} 
                                            onChange={e => setNewProfile({...newProfile, contact: e.target.value})}
                                            placeholder="+91"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Service Rate (Optional)</label>
                                        <input 
                                            className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all" 
                                            value={newProfile.hourlyRate} 
                                            onChange={e => setNewProfile({...newProfile, hourlyRate: e.target.value})}
                                            placeholder="e.g. ₹500/visit or Hourly"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Tell us about your services</label>
                                    <textarea 
                                        required 
                                        rows={4} 
                                        className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:border-slate-600 dark:text-white focus:border-teal-500 outline-none transition-all resize-none" 
                                        value={newProfile.description} 
                                        onChange={e => setNewProfile({...newProfile, description: e.target.value})}
                                        placeholder="Briefly describe your expertise and why clients should hire you..."
                                    />
                                </div>

                                <div className="pt-6 flex flex-col md:flex-row justify-end gap-4">
                                    <button 
                                        type="button" 
                                        onClick={() => setIsPostModalOpen(false)}
                                        className="px-8 py-4 border-2 border-gray-100 rounded-2xl text-gray-600 font-bold hover:bg-gray-50 transition-colors"
                                    >
                                        Cancel
                                    </button>
                                    <button 
                                        type="submit" 
                                        className="px-10 py-4 bg-teal-600 text-white font-black rounded-2xl hover:bg-teal-700 shadow-xl shadow-teal-200 transition-all active:scale-95"
                                    >
                                        Submit Profile
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Freelancers;
