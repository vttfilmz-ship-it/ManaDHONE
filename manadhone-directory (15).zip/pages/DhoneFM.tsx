
import React, { useState, useEffect, useRef } from 'react';
import { getFMSchedule, saveFMProgram } from '../services/storageService';
import { FMProgram } from '../types';
import { IconRadio, IconPlay, IconPause, IconVolume, IconClock, IconStar, IconFilm, IconSend, IconCheck } from '../components/Icons';

const DhoneFM: React.FC = () => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [isBuffering, setIsBuffering] = useState(false);
    const [currentTime, setCurrentTime] = useState(new Date());
    const [schedule, setSchedule] = useState<FMProgram[]>([]);
    const [isPostModalOpen, setIsPostModalOpen] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [playbackError, setPlaybackError] = useState<string | null>(null);
    
    const [newProgram, setNewProgram] = useState<Partial<FMProgram>>({
        title: '', host: '', time: ''
    });

    const audioRef = useRef<HTMLAudioElement | null>(null);
    const videoRef = useRef<HTMLVideoElement | null>(null);
    const audioPromiseRef = useRef<Promise<void> | null>(null);

    useEffect(() => {
        const loadedSchedule = getFMSchedule().filter(p => p.active && p.status === 'approved');
        setSchedule(loadedSchedule);
        const timer = setInterval(() => setCurrentTime(new Date()), 60000);
        return () => clearInterval(timer);
    }, []);

    const getCurrentProgram = (): FMProgram | null => {
        if (schedule.length === 0) return null;
        
        const hour = currentTime.getHours();
        const found = schedule.find(p => {
             const [timeStr, meridiem] = p.time.split(' ');
             let [progHour] = timeStr.split(':').map(Number);
             const isPM = meridiem === 'PM';
             const actualHour = isPM && progHour !== 12 ? progHour + 12 : (progHour === 12 && !isPM ? 0 : progHour);
             return hour >= actualHour && hour < actualHour + 3;
        });
        
        return found || schedule[0];
    };

    const currentProgram = getCurrentProgram();

    // Determine format label for UI
    const getFormatLabel = (url?: string) => {
        if (!url) return 'Digital';
        if (url.startsWith('data:audio/')) {
            return url.split(';')[0].split('/')[1].toUpperCase();
        }
        const ext = url.split('.').pop()?.toUpperCase();
        return ext && ext.length < 5 ? ext : 'HQ Audio';
    };

    useEffect(() => {
        if (!currentProgram) return;

        const syncPlayback = async () => {
            if (isPlaying) {
                setPlaybackError(null);
                if (audioRef.current && currentProgram.audioUrl) {
                    setIsBuffering(true);
                    try {
                        audioPromiseRef.current = audioRef.current.play();
                        await audioPromiseRef.current;
                        setIsBuffering(false);
                    } catch (e) {
                        console.error("Playback failed", e);
                        setPlaybackError("Your browser doesn't support this audio format. Try another show.");
                        setIsPlaying(false);
                        setIsBuffering(false);
                    }
                }
                if (videoRef.current && currentProgram.videoUrl) {
                    try {
                        await videoRef.current.play();
                    } catch (e) {
                        console.debug("Video play failed", e);
                    }
                }
            } else {
                if (audioRef.current) {
                    if (audioPromiseRef.current) {
                        await audioPromiseRef.current.catch(() => {});
                    }
                    audioRef.current.pause();
                }
                if (videoRef.current) {
                    videoRef.current.pause();
                }
                setIsBuffering(false);
            }
        };

        syncPlayback();
    }, [isPlaying, currentProgram]);

    const togglePlay = () => {
        setIsPlaying(!isPlaying);
    };

    const handlePostProgram = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        const programToSave: FMProgram = {
            id: Date.now().toString(),
            status: 'pending',
            active: false,
            title: newProgram.title!,
            host: newProgram.host!,
            time: newProgram.time!,
        };

        setTimeout(() => {
            saveFMProgram(programToSave);
            setIsSubmitting(false);
            setIsSuccess(true);
        }, 1000);
    };

    const closePostModal = () => {
        setIsPostModalOpen(false);
        setIsSuccess(false);
        setNewProgram({ title: '', host: '', time: '' });
    };

    return (
        <div className="bg-[#05050a] min-h-screen text-white flex flex-col items-center py-12 px-4 relative overflow-hidden font-sans">
            {/* Audio Element - Hidden but handles all formats */}
            <audio 
                ref={audioRef} 
                src={currentProgram?.audioUrl} 
                loop 
                onWaiting={() => setIsBuffering(true)}
                onPlaying={() => setIsBuffering(false)}
                onError={() => {
                    setPlaybackError("Format incompatible or file missing.");
                    setIsPlaying(false);
                }}
            />

            {/* Cinematic Background Atmosphere */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className={`absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-indigo-600/20 rounded-full blur-[160px] transition-all duration-1000 ${isPlaying ? 'scale-125 opacity-40' : 'scale-100 opacity-20'}`}></div>
                <div className={`absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/20 rounded-full blur-[140px] transition-all duration-1000 ${isPlaying ? 'translate-x-[-10%] opacity-30' : 'opacity-10'}`}></div>
                {/* Subtle grid pattern */}
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
            </div>

            <div className="relative z-10 w-full max-w-6xl flex flex-col lg:flex-row gap-12 items-center lg:items-start">
                
                {/* --- UNIVERSAL PLAYER CONSOLE --- */}
                <div className="w-full lg:w-[55%] animate-in fade-in slide-in-from-left-8 duration-1000">
                    <div className="bg-white/5 backdrop-blur-3xl border border-white/10 rounded-[3.5rem] p-8 md:p-12 shadow-[0_32px_64px_rgba(0,0,0,0.5)] ring-1 ring-white/20">
                        
                        {/* Top Control Bar */}
                        <div className="flex justify-between items-center mb-12">
                            <div className="flex items-center gap-4">
                                <div className="relative">
                                    <div className={`w-3 h-3 rounded-full ${isPlaying ? 'bg-red-500 animate-pulse shadow-[0_0_15px_#ef4444]' : 'bg-white/20'}`}></div>
                                    {isPlaying && <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-75"></div>}
                                </div>
                                <span className={`text-[10px] font-black tracking-[0.3em] uppercase ${isPlaying ? 'text-red-500' : 'text-white/40'}`}>
                                    {isPlaying ? 'Broadcasting Live' : 'Station Standby'}
                                </span>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="bg-indigo-500/10 border border-indigo-500/30 px-4 py-1.5 rounded-full text-[10px] font-black text-indigo-400 tracking-widest">
                                    {getFormatLabel(currentProgram?.audioUrl)} STEREO
                                </div>
                                <div className="bg-white/5 border border-white/10 px-4 py-1.5 rounded-full text-[10px] font-mono text-gray-400">
                                    90.4 MHz
                                </div>
                            </div>
                        </div>

                        {/* Visual Display Area */}
                        <div className="flex flex-col items-center mb-12">
                            <div className="relative w-64 h-64 md:w-80 md:h-80 mb-10">
                                {/* Rotating Inner Disc Animation */}
                                <div className={`absolute inset-0 rounded-full border-2 border-white/5 p-4 transition-transform duration-[10s] linear infinite ${isPlaying ? 'animate-[spin_12s_linear_infinite]' : ''}`}>
                                    <div className="w-full h-full rounded-full border border-white/10 border-dashed"></div>
                                </div>

                                {/* Content Cover */}
                                <div className="relative w-full h-full rounded-full overflow-hidden border-8 border-[#0a0a14] shadow-2xl group">
                                    {currentProgram?.videoUrl ? (
                                        <div className="w-full h-full bg-black">
                                            <video
                                                ref={videoRef}
                                                src={currentProgram.videoUrl}
                                                className="w-full h-full object-cover"
                                                loop
                                                muted={!isPlaying}
                                                playsInline
                                            />
                                        </div>
                                    ) : (
                                        <div className="w-full h-full bg-gradient-to-tr from-indigo-900 via-purple-900 to-slate-900 flex items-center justify-center">
                                            <IconRadio className={`w-24 h-24 text-white/20 transition-all duration-700 ${isPlaying ? 'scale-110 text-white/40' : 'scale-100'}`} />
                                            {/* Glowing orb behind icon */}
                                            <div className={`absolute inset-0 bg-indigo-500/20 blur-[60px] rounded-full transition-opacity duration-1000 ${isPlaying ? 'opacity-100' : 'opacity-0'}`}></div>
                                        </div>
                                    )}

                                    {/* Buffering Overlay */}
                                    {isBuffering && (
                                        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-20">
                                            <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
                                        </div>
                                    )}

                                    {/* Center Hole Effect */}
                                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-[#0a0a14] rounded-full shadow-inner z-30"></div>
                                </div>
                            </div>
                            
                            <div className="text-center space-y-3 px-4">
                                <h2 className="text-4xl md:text-5xl font-black tracking-tight text-white group-hover:text-indigo-400 transition-colors">
                                    {currentProgram?.title || "ManaDHONE FM"}
                                </h2>
                                <div className="flex items-center justify-center gap-3">
                                    <span className="h-px w-8 bg-gradient-to-r from-transparent to-indigo-500/50"></span>
                                    <p className="text-indigo-400 font-black text-xs uppercase tracking-[0.3em]">Hosted by {currentProgram?.host || "AI Voice"}</p>
                                    <span className="h-px w-8 bg-gradient-to-l from-transparent to-indigo-500/50"></span>
                                </div>
                                {playbackError && (
                                    <div className="mt-4 bg-red-500/10 border border-red-500/20 px-4 py-2 rounded-xl text-red-400 text-xs font-bold animate-in shake-in">
                                        {playbackError}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Interactive Dynamic Visualizer */}
                        <div className="flex items-end justify-center gap-2 h-20 mb-12">
                            {Array.from({ length: 32 }).map((_, i) => (
                                <div 
                                    key={i} 
                                    className={`w-1.5 bg-indigo-500 rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(99,102,241,0.3)]`}
                                    style={{ 
                                        height: isPlaying ? `${10 + Math.random() * 90}%` : '6%',
                                        opacity: isPlaying ? (0.3 + Math.random() * 0.7) : 0.1,
                                        transitionDelay: `${i * 10}ms`
                                    }}
                                ></div>
                            ))}
                        </div>

                        {/* Modern Playback Controls */}
                        <div className="flex flex-col md:flex-row items-center gap-10">
                            <div className="flex items-center gap-8 order-2 md:order-1">
                                <button className="text-white/20 hover:text-white transition-all transform hover:scale-110 active:scale-90">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m11 17-5-5 5-5M18 17l-5-5 5-5"/></svg>
                                </button>
                                
                                <button 
                                    onClick={togglePlay}
                                    disabled={isBuffering}
                                    className={`w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-95 group relative ${isPlaying ? 'bg-white text-[#05050a]' : 'bg-indigo-600 text-white hover:bg-indigo-500'}`}
                                >
                                    {isPlaying ? (
                                        <IconPause className="w-8 h-8 fill-current" />
                                    ) : (
                                        <IconPlay className="w-8 h-8 fill-current translate-x-1" />
                                    )}
                                    <div className={`absolute inset-0 rounded-full border-2 border-white/20 transition-all duration-500 scale-110 opacity-0 group-hover:opacity-100 group-hover:scale-125`}></div>
                                </button>
                                
                                <button className="text-white/20 hover:text-white transition-all transform hover:scale-110 active:scale-90">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m13 17 5-5-5-5M6 17l5-5-5-5"/></svg>
                                </button>
                            </div>

                            <div className="flex-1 w-full bg-white/5 border border-white/10 p-5 rounded-[2rem] flex items-center gap-5 order-1 md:order-2">
                                <IconVolume className="w-5 h-5 text-white/40" />
                                <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden cursor-pointer relative group">
                                    <div className="w-[85%] h-full bg-gradient-to-r from-indigo-600 to-purple-500 rounded-full"></div>
                                    <div className="absolute top-1/2 left-[85%] w-3 h-3 bg-white rounded-full -translate-y-1/2 -translate-x-1/2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                </div>
                                <span className="text-[10px] font-black text-white/40 font-mono tracking-tighter">85% VOL</span>
                            </div>
                        </div>
                    </div>

                    <div className="mt-8 flex justify-center gap-12 text-white/40 font-black text-[10px] uppercase tracking-[0.2em]">
                        <button className="flex items-center gap-2 hover:text-white transition-colors group">
                            <IconStar className="w-4 h-4 group-hover:fill-current" /> Add to Playlist
                        </button>
                        <button className="flex items-center gap-2 hover:text-white transition-colors group">
                            <IconSend className="w-4 h-4" /> Share Stream
                        </button>
                    </div>
                </div>

                {/* --- SIDEBAR: BROADCAST GRID --- */}
                <div className="w-full lg:w-[45%] flex flex-col gap-8 animate-in fade-in slide-in-from-right-8 duration-1000 delay-300">
                    <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[3rem] p-10 h-full flex flex-col">
                        <div className="flex justify-between items-center mb-10">
                            <div>
                                <h3 className="text-2xl font-black tracking-tight flex items-center gap-3">
                                    Program Radar
                                </h3>
                                <p className="text-indigo-400/60 text-xs font-bold uppercase tracking-widest mt-1">Live Town Schedule</p>
                            </div>
                            <button 
                                onClick={() => setIsPostModalOpen(true)}
                                className="bg-white text-black text-[10px] font-black uppercase tracking-widest px-6 py-3 rounded-2xl transition-all shadow-xl hover:bg-indigo-50 active:scale-95"
                            >
                                Get On Air
                            </button>
                        </div>
                        
                        <div className="space-y-4 flex-1">
                            {schedule.map((item) => {
                                const isCurrent = item.id === currentProgram?.id;
                                
                                return (
                                    <div 
                                        key={item.id} 
                                        className={`flex items-center gap-5 p-5 rounded-[2rem] border transition-all group ${isCurrent ? 'bg-indigo-600 text-white border-indigo-400/50 shadow-2xl shadow-indigo-600/20' : 'bg-white/[0.03] border-white/5 hover:bg-white/10'}`}
                                    >
                                        <div className={`w-16 h-16 shrink-0 rounded-2xl flex flex-col items-center justify-center font-black text-[10px] leading-tight ${isCurrent ? 'bg-white text-indigo-600' : 'bg-white/5 text-gray-500'}`}>
                                            {item.time.split(' ')[0]}
                                            <span className="block opacity-50">{item.time.split(' ')[1]}</span>
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className={`font-black truncate text-lg tracking-tight ${isCurrent ? 'text-white' : 'text-gray-200'}`}>{item.title}</h4>
                                                {isCurrent && <span className="bg-white/20 text-[8px] uppercase px-1.5 py-0.5 rounded font-black tracking-widest animate-pulse">Now</span>}
                                            </div>
                                            <p className={`text-xs font-bold uppercase tracking-widest ${isCurrent ? 'text-white/70' : 'text-gray-500'}`}>With RJ {item.host}</p>
                                        </div>
                                        <div className={`flex gap-2 transition-all ${isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                                            {item.audioUrl && (
                                                <div className={`${isCurrent ? 'text-white' : 'text-indigo-400'}`}>
                                                    <IconPlay className="w-5 h-5 fill-current" />
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        {/* Interactive CTA */}
                        <div className="mt-10 bg-indigo-600 p-8 rounded-[2.5rem] relative overflow-hidden group shadow-2xl">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700"></div>
                            <h4 className="text-lg font-black mb-2 relative z-10">Request a Track</h4>
                            <p className="text-white/70 text-xs font-medium mb-6 relative z-10 leading-relaxed">Dedicated songs for birthdays, anniversaries, or just to surprise a friend in Dhone!</p>
                            <a href="tel:+919876543210" className="bg-white text-indigo-600 px-8 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-50 transition-all inline-block relative z-10 shadow-lg">
                                Send WhatsApp +91 98765
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Submission Modal */}
            {isPostModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
                    <div className="bg-[#0a0a14] border border-white/10 rounded-[3.5rem] shadow-[0_0_100px_rgba(79,70,229,0.2)] w-full max-w-xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col">
                        <div className="bg-indigo-600 p-10 text-white flex justify-between items-center shrink-0">
                            <div>
                                <h3 className="text-3xl font-black tracking-tighter">Become an RJ</h3>
                                <p className="text-indigo-100 text-sm font-medium mt-1">Host your own show on ManaDHONE FM.</p>
                            </div>
                            <button onClick={closePostModal} className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="3" strokeLinecap="round"/></svg>
                            </button>
                        </div>
                        
                        <div className="p-10">
                            {isSuccess ? (
                                <div className="text-center py-12 animate-in zoom-in duration-500">
                                    <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-500/20">
                                        <IconCheck className="w-12 h-12" />
                                    </div>
                                    <h3 className="text-3xl font-black mb-2 tracking-tight">Pitch Received!</h3>
                                    <p className="text-white/40 mb-10 leading-relaxed font-medium">
                                        Our content lead will audit your program pitch. Expect a callback within 48 hours for an audition.
                                    </p>
                                    <button 
                                        onClick={closePostModal}
                                        className="w-full bg-white text-black font-black py-5 rounded-[2rem] transition-all active:scale-95 shadow-xl uppercase tracking-widest text-xs"
                                    >
                                        Ready for the mic
                                    </button>
                                </div>
                            ) : (
                                <form onSubmit={handlePostProgram} className="space-y-8">
                                    <div className="space-y-6">
                                        <div>
                                            <label className="block text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-3">Program Narrative Title*</label>
                                            <input 
                                                required 
                                                className="w-full p-5 bg-white/5 border border-white/10 rounded-2xl text-white outline-none focus:border-indigo-500 transition-all font-bold placeholder:text-white/10" 
                                                value={newProgram.title} 
                                                onChange={e => setNewProgram({...newProgram, title: e.target.value})}
                                                placeholder="e.g. Night Rider Chronicles"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-3">Your Stage Identity*</label>
                                            <input 
                                                required 
                                                className="w-full p-5 bg-white/5 border border-white/10 rounded-2xl text-white outline-none focus:border-indigo-500 transition-all font-bold placeholder:text-white/10" 
                                                value={newProgram.host} 
                                                onChange={e => setNewProgram({...newProgram, host: e.target.value})}
                                                placeholder="Your RJ Name"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-3">Desired Air Time*</label>
                                            <input 
                                                required 
                                                className="w-full p-5 bg-white/5 border border-white/10 rounded-2xl text-white outline-none focus:border-indigo-500 transition-all font-bold placeholder:text-white/10" 
                                                value={newProgram.time} 
                                                onChange={e => setNewProgram({...newProgram, time: e.target.value})}
                                                placeholder="e.g. 10:00 PM - 12:00 AM"
                                            />
                                        </div>
                                    </div>

                                    <div className="pt-4 flex flex-col sm:flex-row gap-4">
                                        <button type="button" onClick={closePostModal} className="flex-1 py-5 text-white/20 font-black uppercase tracking-widest text-[10px] hover:text-white transition-colors">Discard Draft</button>
                                        <button 
                                            type="submit" 
                                            disabled={isSubmitting}
                                            className="flex-[2] py-5 bg-indigo-600 text-white font-black rounded-[2rem] shadow-[0_15px_30px_rgba(79,70,229,0.3)] transition-all active:scale-95 uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 disabled:opacity-50"
                                        >
                                            {isSubmitting ? (
                                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                            ) : (
                                                <>
                                                    <IconSend className="w-4 h-4" /> Submit Audition Pitch
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>
            )}
            
            {/* Footer Geolocation Data */}
            <div className="mt-16 text-center text-white/10 text-[10px] font-black tracking-[0.4em] uppercase pb-12 flex items-center gap-6">
                <span className="h-px w-20 bg-white/5"></span>
                <span>Dhone Broadcasting 90.4</span>
                <span className="font-mono text-[8px] opacity-50">77.87E 15.39N</span>
                <span className="h-px w-20 bg-white/5"></span>
            </div>
        </div>
    );
};

export default DhoneFM;
