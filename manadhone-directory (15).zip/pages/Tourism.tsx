
import React, { useState, useEffect } from 'react';
import { getTourismSpots, getHeroSlides } from '../services/storageService';
import { HeroSlide } from '../types';
import { IconMapPin, IconStar } from '../components/Icons';

const Tourism: React.FC = () => {
    const spots = getTourismSpots();
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    useEffect(() => {
        const slides = getHeroSlides().filter(s => s.page === 'tourism' && s.active);
        setHeroSlides(slides);
    }, []);

    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    return (
        <div className="bg-gray-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
            {/* Hero Header with Slider */}
            <div className="bg-indigo-900 text-white py-20 px-4 text-center relative overflow-hidden h-[400px] flex items-center justify-center">
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, index) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-50' : 'opacity-0'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover" alt={slide.caption} />
                        </div>
                    ))
                ) : (
                    <div className="absolute inset-0 bg-black/20 z-0"></div>
                )}
                
                <div className="relative z-10">
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4 drop-shadow-lg">
                        {heroSlides.length > 0 && heroSlides[currentSlide]?.caption ? heroSlides[currentSlide].caption : "Visit Dhone & Beyond"}
                    </h1>
                    <p className="text-lg text-indigo-200 max-w-2xl mx-auto drop-shadow-md">
                        Explore ancient temples, historic forts, and natural wonders. Discover the best weekend getaways around ManaDHONE.
                    </p>
                </div>
            </div>

            <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {spots.map(spot => (
                        <div key={spot.id} className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-300 border border-gray-100 dark:border-slate-700 flex flex-col h-full">
                            <div className="relative h-64 overflow-hidden shrink-0">
                                <img 
                                    src={spot.imageUrl} 
                                    alt={spot.name} 
                                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                                />
                                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                                <div className="absolute top-4 right-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wide shadow-sm">
                                    {spot.type}
                                </div>
                                <div className="absolute bottom-4 left-4 text-white">
                                     <div className="flex items-center gap-1 text-sm font-medium bg-black/30 backdrop-blur-sm px-2 py-1 rounded-lg border border-white/20">
                                        <IconMapPin className="w-4 h-4 text-yellow-400" /> {spot.location}
                                    </div>
                                </div>
                            </div>
                            <div className="p-6 flex flex-col flex-1">
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{spot.name}</h3>
                                <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6 text-sm flex-1">
                                    {spot.description}
                                </p>
                                
                                {spot.highlights && (
                                    <div className="mb-6 bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-xl border border-indigo-100 dark:border-indigo-800/50">
                                        <h4 className="text-xs font-bold text-indigo-700 dark:text-indigo-300 uppercase tracking-wider mb-2 flex items-center gap-2">
                                            <IconStar className="w-3 h-3 fill-current" /> Highlights & Tips
                                        </h4>
                                        <p className="text-xs text-indigo-900 dark:text-indigo-100 font-medium leading-relaxed">
                                            {spot.highlights}
                                        </p>
                                    </div>
                                )}

                                <a 
                                    href={spot.latitude && spot.longitude 
                                        ? `https://www.google.com/maps/search/?api=1&query=${spot.latitude},${spot.longitude}`
                                        : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(spot.name + ' ' + spot.location)}`
                                    }
                                    target="_blank"
                                    rel="noreferrer"
                                    className="w-full bg-gray-100 dark:bg-slate-700 hover:bg-indigo-600 dark:hover:bg-indigo-600 text-gray-800 dark:text-white hover:text-white font-bold py-3 rounded-xl transition-colors text-center block"
                                >
                                    Get Directions
                                </a>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Tourism;
