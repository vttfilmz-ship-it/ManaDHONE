
import React, { useState, useEffect, useMemo } from 'react';
import { getBusinesses, getSavedBusinessIds } from '../services/storageService';
import { Business } from '../types';
import BusinessCard from '../components/BusinessCard';
import { IconBookmark, IconSearch } from '../components/Icons';
import { Link } from 'react-router-dom';

const Saved: React.FC = () => {
    const [businesses, setBusinesses] = useState<Business[]>([]);
    const [savedIds, setSavedIds] = useState<string[]>([]);

    useEffect(() => {
        setBusinesses(getBusinesses());
        setSavedIds(getSavedBusinessIds());
    }, []);

    const savedBusinesses = useMemo(() => {
        return businesses.filter(b => savedIds.includes(b.id) && b.status === 'approved');
    }, [businesses, savedIds]);

    const handleRefresh = () => {
        setSavedIds(getSavedBusinessIds());
    };

    return (
        <div className="bg-gray-50 min-h-screen py-12">
            <div className="container mx-auto px-4 max-w-6xl">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-4">
                    <div>
                        <h1 className="text-3xl font-extrabold text-gray-900 flex items-center gap-3">
                            <IconBookmark fill className="text-indigo-600" />
                            Saved for Later
                        </h1>
                        <p className="text-gray-500 mt-1">Your bookmarked businesses and services in ManaDHONE.</p>
                    </div>
                    <Link to="/" className="text-indigo-600 font-bold hover:text-indigo-800 flex items-center gap-2">
                        <IconSearch className="w-4 h-4" /> Browse more
                    </Link>
                </div>

                {savedBusinesses.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {savedBusinesses.map(b => (
                            <BusinessCard key={b.id} business={b} onToggleSaved={handleRefresh} />
                        ))}
                    </div>
                ) : (
                    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-12 text-center max-w-2xl mx-auto">
                        <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-200 mx-auto mb-6">
                            <IconBookmark className="w-12 h-12" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">No saved businesses</h3>
                        <p className="text-gray-500 mb-8 leading-relaxed">
                            You haven't bookmarked any businesses yet. When you find a place you're interested in, click the bookmark icon to save it here for quick access later.
                        </p>
                        <Link to="/" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-10 rounded-2xl shadow-lg shadow-indigo-100 transition-all inline-block">
                            Start Exploring Dhone
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Saved;
