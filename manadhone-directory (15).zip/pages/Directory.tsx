
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { getBusinesses } from '../services/storageService.ts';
import { Business, Category } from '../types.ts';
import BusinessCard from '../components/BusinessCard.tsx';
import { IconSearch, IconFilter, IconStar, IconCheck, IconClock, IconMapPin, IconTrendingUp, IconBriefcase } from '../components/Icons.tsx';

const Directory: React.FC = () => {
    const [businesses, setBusinesses] = useState<Business[]>([]);
    const [search, setSearch] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
    const [minRating, setMinRating] = useState<number>(0);
    const [onlyVerified, setOnlyVerified] = useState(false);
    const [onlyOpenNow, setOnlyOpenNow] = useState(false);
    const [sortBy, setSortBy] = useState<'rating' | 'name' | 'views'>('rating');
    const [showMobileFilters, setShowMobileFilters] = useState(false);

    useEffect(() => {
        setBusinesses(getBusinesses());
        window.scrollTo(0, 0);
    }, []);

    const isNowOpen = (b: Business) => {
        if (!b.openTime || !b.closeTime) return true;
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        return currentTime >= b.openTime && currentTime <= b.closeTime;
    };

    const filteredAndSorted = useMemo(() => {
        let result = businesses.filter(b => b.status === 'approved');

        if (search.trim()) {
            const q = search.toLowerCase();
            result = result.filter(b => 
                b.name.toLowerCase().includes(q) || 
                b.shortDescription.toLowerCase().includes(q) ||
                b.address.toLowerCase().includes(q)
            );
        }

        if (selectedCategory !== 'All') {
            result = result.filter(b => b.category === selectedCategory);
        }

        if (minRating > 0) {
            result = result.filter(b => b.rating >= minRating);
        }

        if (onlyVerified) {
            result = result.filter(b => b.verified);
        }

        if (onlyOpenNow) {
            result = result.filter(b => isNowOpen(b));
        }

        // Sorting
        result.sort((a, b) => {
            if (sortBy === 'rating') return b.rating - a.rating;
            if (sortBy === 'views') return (b.views || 0) - (a.views || 0);
            return a.name.localeCompare(b.name);
        });

        return result;
    }, [businesses, search, selectedCategory, minRating, onlyVerified, onlyOpenNow, sortBy]);

    const resetFilters = () => {
        setSearch('');
        setSelectedCategory('All');
        setMinRating(0);
        setOnlyVerified(false);
        setOnlyOpenNow(false);
        setSortBy('rating');
    };

    return (
        <div className="bg-gray-50 dark:bg-slate-950 min-h-screen transition-colors duration-300">
            {/* Minimal Header */}
            <div className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-white/5 py-8">
                <div className="container mx-auto px-4">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                        <div>
                            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
                                <Link to="/" className="hover:text-indigo-600 transition-colors">Home</Link>
                                <span>/</span>
                                <span className="text-indigo-600">Business Directory</span>
                            </div>
                            <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Business Hub</h1>
                            <p className="text-slate-500 dark:text-slate-400 font-medium">Find and connect with verified local professionals.</p>
                        </div>
                        <Link to="/submit-listing" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black text-sm shadow-xl shadow-indigo-200 transition-all active:scale-95 flex items-center gap-2">
                            + List Your Business
                        </Link>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 py-12">
                <div className="flex flex-col lg:flex-row gap-10">
                    
                    {/* Filter Sidebar (Desktop) */}
                    <aside className="hidden lg:block w-72 shrink-0 space-y-8 sticky top-28 h-fit">
                        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 space-y-8">
                            <div className="flex items-center justify-between">
                                <h3 className="text-sm font-black uppercase tracking-widest text-slate-900 dark:text-white flex items-center gap-2">
                                    <IconFilter className="w-4 h-4 text-indigo-600" /> Filters
                                </h3>
                                <button onClick={resetFilters} className="text-[10px] font-black text-red-500 uppercase hover:underline">Reset</button>
                            </div>

                            {/* Search */}
                            <div>
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Quick Search</label>
                                <div className="relative">
                                    <IconSearch className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <input 
                                        type="text" 
                                        placeholder="Business name..." 
                                        className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-white/5 rounded-xl border border-transparent focus:border-indigo-500 outline-none text-sm font-bold dark:text-white"
                                        value={search}
                                        onChange={(e) => setSearch(e.target.value)}
                                    />
                                </div>
                            </div>

                            {/* Category */}
                            <div>
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Sectors</label>
                                <select 
                                    className="w-full p-3 bg-gray-50 dark:bg-white/5 rounded-xl border border-transparent focus:border-indigo-500 outline-none text-sm font-bold dark:text-white"
                                    value={selectedCategory}
                                    onChange={(e) => setSelectedCategory(e.target.value as any)}
                                >
                                    <option value="All">All Categories</option>
                                    {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>

                            {/* Rating */}
                            <div>
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Min. Rating</label>
                                <div className="flex gap-2">
                                    {[3, 4, 4.5].map(rating => (
                                        <button 
                                            key={rating}
                                            onClick={() => setMinRating(minRating === rating ? 0 : rating)}
                                            className={`flex-1 py-2 rounded-xl text-xs font-black transition-all border ${minRating === rating ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-gray-50 dark:bg-white/5 text-slate-500 border-transparent hover:border-indigo-200'}`}
                                        >
                                            {rating}+ <IconStar fill className="w-3 h-3 inline ml-1" />
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Toggles */}
                            <div className="space-y-4">
                                <label className="flex items-center justify-between cursor-pointer group">
                                    <span className="text-sm font-bold text-slate-600 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">Verified Only</span>
                                    <input 
                                        type="checkbox" 
                                        className="w-5 h-5 rounded-lg text-indigo-600 border-gray-200 focus:ring-indigo-500"
                                        checked={onlyVerified}
                                        onChange={() => setOnlyVerified(!onlyVerified)}
                                    />
                                </label>
                                <label className="flex items-center justify-between cursor-pointer group">
                                    <span className="text-sm font-bold text-slate-600 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">Open Now</span>
                                    <input 
                                        type="checkbox" 
                                        className="w-5 h-5 rounded-lg text-emerald-600 border-gray-200 focus:ring-emerald-500"
                                        checked={onlyOpenNow}
                                        onChange={() => setOnlyOpenNow(!onlyOpenNow)}
                                    />
                                </label>
                            </div>
                        </div>

                        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform"></div>
                            <h4 className="text-xl font-black mb-2 relative z-10 leading-tight">Can't find a business?</h4>
                            <p className="text-indigo-100 text-sm mb-6 relative z-10 font-medium">Suggest a new local store and help us grow the Dhone directory.</p>
                            <Link to="/contact" className="w-full bg-white text-indigo-600 font-black py-3 rounded-xl flex items-center justify-center text-xs uppercase tracking-widest shadow-lg relative z-10 hover:bg-indigo-50 active:scale-95 transition-all">
                                Suggest Hub
                            </Link>
                        </div>
                    </aside>

                    {/* Main Content */}
                    <div className="flex-1 space-y-8">
                        {/* Mobile Search & Filter Button */}
                        <div className="lg:hidden flex gap-4">
                            <div className="flex-1 relative">
                                <IconSearch className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                                <input 
                                    type="text" 
                                    placeholder="Search..." 
                                    className="w-full pl-12 pr-4 py-4 bg-white dark:bg-slate-900 rounded-2xl border border-gray-200 dark:border-white/5 outline-none font-bold shadow-sm"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                            </div>
                            <button 
                                onClick={() => setShowMobileFilters(true)}
                                className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-gray-200 dark:border-white/5 shadow-sm text-indigo-600"
                            >
                                <IconFilter className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Top Bar: Active Filters & Sort */}
                        <div className="flex flex-col sm:flex-row justify-between items-center bg-white dark:bg-slate-900 p-4 rounded-2xl md:rounded-[2rem] border border-gray-100 dark:border-white/5 shadow-sm gap-4 transition-colors">
                            <div className="flex flex-wrap gap-2">
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2 flex items-center">Active:</span>
                                {selectedCategory !== 'All' && <span className="bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-lg text-xs font-bold border border-indigo-100 dark:border-indigo-800">{selectedCategory}</span>}
                                {onlyVerified && <span className="bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-lg text-xs font-bold border border-blue-100 dark:border-blue-800">Verified</span>}
                                {onlyOpenNow && <span className="bg-emerald-50 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-lg text-xs font-bold border border-emerald-100 dark:border-emerald-800">Open Now</span>}
                                {!search && selectedCategory === 'All' && !onlyVerified && !onlyOpenNow && <span className="text-xs font-bold text-slate-400 italic">None applied</span>}
                            </div>

                            <div className="flex items-center gap-3">
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest whitespace-nowrap">Sort By</span>
                                <select 
                                    className="bg-gray-100 dark:bg-white/5 border-none rounded-xl text-xs font-black uppercase tracking-widest px-4 py-2 outline-none dark:text-white"
                                    value={sortBy}
                                    onChange={(e) => setSortBy(e.target.value as any)}
                                >
                                    <option value="rating">Top Rated</option>
                                    <option value="views">Most Viewed</option>
                                    <option value="name">Name A-Z</option>
                                </select>
                            </div>
                        </div>

                        {/* Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {filteredAndSorted.length > 0 ? (
                                filteredAndSorted.map(b => (
                                    <div key={b.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                                        <BusinessCard business={b} />
                                    </div>
                                ))
                            ) : (
                                <div className="col-span-full py-32 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-gray-200 dark:border-white/5">
                                    <div className="w-20 h-20 bg-slate-50 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                                        <IconSearch className="w-10 h-10 text-slate-300" />
                                    </div>
                                    <h3 className="text-2xl font-black text-slate-900 dark:text-white">No results found</h3>
                                    <p className="text-slate-500 mt-2 max-w-xs mx-auto">Try widening your filters or checking back later as new businesses register daily.</p>
                                    <button onClick={resetFilters} className="mt-8 text-indigo-600 font-bold hover:underline">Clear all filters</button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Filters Modal */}
            {showMobileFilters && (
                <div className="fixed inset-0 z-[100] flex flex-col bg-white dark:bg-slate-900 animate-in slide-in-from-bottom duration-300">
                    <div className="p-6 border-b border-gray-100 dark:border-white/5 flex justify-between items-center">
                        <h2 className="text-xl font-black">Search Filters</h2>
                        <button onClick={() => setShowMobileFilters(false)} className="p-2 bg-gray-100 dark:bg-white/10 rounded-full">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5" strokeLinecap="round"/></svg>
                        </button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6 space-y-8">
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Category</label>
                            <div className="grid grid-cols-2 gap-2">
                                {['All', ...Object.values(Category)].map(c => (
                                    <button 
                                        key={c}
                                        onClick={() => setSelectedCategory(c as any)}
                                        className={`p-3 rounded-xl text-xs font-bold border transition-all ${selectedCategory === c ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-gray-50 dark:bg-white/5 border-transparent'}`}
                                    >
                                        {c}
                                    </button>
                                ))}
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <label className="block text-xs font-black text-slate-400 uppercase">Trust</label>
                                <button onClick={() => setOnlyVerified(!onlyVerified)} className={`w-full p-4 rounded-2xl font-bold flex items-center justify-between border ${onlyVerified ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-100'}`}>
                                    Verified <IconCheck className="w-4 h-4" />
                                </button>
                            </div>
                            <div className="space-y-4">
                                <label className="block text-xs font-black text-slate-400 uppercase">Time</label>
                                <button onClick={() => setOnlyOpenNow(!onlyOpenNow)} className={`w-full p-4 rounded-2xl font-bold flex items-center justify-between border ${onlyOpenNow ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-gray-100'}`}>
                                    Open Now <IconClock className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="p-6 border-t border-gray-100 dark:border-white/5 flex gap-4">
                        <button onClick={resetFilters} className="flex-1 py-4 text-gray-500 font-bold">Clear All</button>
                        <button onClick={() => setShowMobileFilters(false)} className="flex-[2] py-4 bg-indigo-600 text-white font-black rounded-2xl">Apply Filters</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Directory;
