
import React, { useState, useEffect, useMemo } from 'react';
import { getInfluencers } from '../services/storageService.ts';
import { Influencer } from '../types.ts';
import { IconInstagram, IconFacebook, IconTwitter, IconSearch, IconStar, IconTrendingUp } from '../components/Icons.tsx';

const Stars: React.FC = () => {
    const [influencers, setInfluencers] = useState<Influencer[]>([]);
    const [search, setSearch] = useState('');
    const [filterPlatform, setFilterPlatform] = useState<string>('All');

    useEffect(() => {
        setInfluencers(getInfluencers());
        window.scrollTo(0, 0);
    }, []);

    const filteredStars = useMemo(() => {
        return influencers.filter(star => {
            const matchesSearch = star.name.toLowerCase().includes(search.toLowerCase()) || 
                                 star.handle.toLowerCase().includes(search.toLowerCase());
            const matchesPlatform = filterPlatform === 'All' || star.platform === filterPlatform;
            return matchesSearch && matchesPlatform;
        });
    }, [influencers, search, filterPlatform]);

    const platforms = [
        { id: 'All', label: 'All Stars', icon: <IconStar className="w-4 h-4" /> },
        { id: 'Instagram', label: 'Instagram', icon: <IconInstagram className="w-4 h-4" /> },
        { id: 'Facebook', label: 'Facebook', icon: <IconFacebook className="w-4 h-4" /> },
        { id: 'YouTube', label: 'YouTube', icon: <IconTrendingUp className="w-4 h-4" /> }
    ];

    return (
        <div className="bg-white dark:bg-slate-950 min-h-screen pb-20">
            {/* Social-First Hero Section */}
            <div className="relative bg-slate-900 h-[450px] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 opacity-40">
                    <img 
                        src="https://images.unsplash.com/photo-1616469829581-73993eb86b02?q=80&w=2670&auto=format&fit=crop" 
                        className="w-full h-full object-cover" 
                        alt="Creators" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-900/60 to-slate-950"></div>
                </div>

                <div className="relative z-10 container mx-auto px-4 text-center">
                    <div className="inline-flex items-center gap-2 bg-pink-500/20 backdrop-blur-xl border border-pink-500/30 px-4 py-2 rounded-full text-pink-400 text-xs font-black uppercase tracking-widest mb-6">
                        <IconStar className="w-4 h-4 fill-current" /> Local Digital Icons
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter shadow-sm">
                        ManaDHONE <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">Stars</span>
                    </h1>
                    <p className="text-xl text-slate-300 max-w-2xl mx-auto font-medium leading-relaxed">
                        Meet the creators, storytellers, and influencers putting Dhone on the digital map. 
                        Follow our local talent across platforms.
                    </p>
                </div>
            </div>

            <div className="container mx-auto px-4 -mt-16 relative z-20">
                {/* Control Bar */}
                <div className="bg-white dark:bg-slate-900 p-4 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-2xl flex flex-col md:flex-row gap-4 items-center mb-12">
                    <div className="flex-1 w-full relative">
                        <IconSearch className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input 
                            type="text" 
                            placeholder="Find your favorite creator..." 
                            className="w-full pl-14 pr-6 py-4 bg-gray-50 dark:bg-white/5 rounded-3xl outline-none focus:ring-2 focus:ring-pink-500/50 transition-all font-bold dark:text-white"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar w-full md:w-auto p-1">
                        {platforms.map(p => (
                            <button
                                key={p.id}
                                onClick={() => setFilterPlatform(p.id)}
                                className={`flex items-center gap-2 px-6 py-4 rounded-3xl font-black text-xs uppercase tracking-widest transition-all shrink-0 ${
                                    filterPlatform === p.id 
                                    ? 'bg-gradient-to-r from-pink-600 to-indigo-600 text-white shadow-xl shadow-pink-500/20 scale-105' 
                                    : 'bg-white dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/10'
                                }`}
                            >
                                {p.icon}
                                {p.label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Stars Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    {filteredStars.length > 0 ? (
                        filteredStars.map((star) => (
                            <div key={star.id} className="group relative">
                                <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-[3rem] blur opacity-0 group-hover:opacity-30 transition duration-1000 group-hover:duration-200"></div>
                                <div className="relative bg-white dark:bg-slate-900 rounded-[3rem] border border-gray-100 dark:border-white/5 overflow-hidden transition-all duration-500 group-hover:-translate-y-2 flex flex-col items-center p-8 shadow-sm group-hover:shadow-2xl">
                                    
                                    <div className="relative mb-6">
                                        <div className="w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600">
                                            <div className="w-full h-full rounded-full bg-white dark:bg-slate-900 flex items-center justify-center overflow-hidden border-4 border-white dark:border-slate-900">
                                                <img src={star.imageUrl} alt={star.name} className="w-full h-full object-cover" />
                                            </div>
                                        </div>
                                        <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-900 p-2 rounded-full shadow-lg border border-gray-100 dark:border-white/10">
                                            {star.platform === 'Instagram' && <IconInstagram className="w-5 h-5 text-pink-500" />}
                                            {star.platform === 'Facebook' && <IconFacebook className="w-5 h-5 text-blue-600" />}
                                            {star.platform === 'YouTube' && <IconTrendingUp className="w-5 h-5 text-red-600" />}
                                        </div>
                                    </div>

                                    <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-1">{star.name}</h3>
                                    <p className="text-gray-500 dark:text-gray-400 font-bold text-sm mb-6">{star.handle}</p>
                                    
                                    <div className="w-full grid grid-cols-2 gap-4 mb-8">
                                        <div className="bg-gray-50 dark:bg-white/5 p-3 rounded-2xl text-center">
                                            <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Followers</span>
                                            <span className="text-lg font-black text-gray-900 dark:text-white">{star.followers}</span>
                                        </div>
                                        <div className="bg-gray-50 dark:bg-white/5 p-3 rounded-2xl text-center">
                                            <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Impact</span>
                                            <span className="text-lg font-black text-pink-600">High</span>
                                        </div>
                                    </div>

                                    <a 
                                        href={star.profileUrl} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="w-full py-4 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-2xl font-black text-xs uppercase tracking-[0.2em] text-center transition-all hover:bg-pink-600 hover:text-white dark:hover:bg-pink-600 dark:hover:text-white shadow-lg active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        Visit Profile
                                    </a>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full py-32 text-center">
                            <div className="bg-gray-100 dark:bg-white/5 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                                <IconSearch className="w-10 h-10 text-gray-300" />
                            </div>
                            <h3 className="text-3xl font-black text-gray-900 dark:text-white">No Stars found</h3>
                            <p className="text-gray-500 mt-2">Try adjusting your filters or search terms.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Stars;
