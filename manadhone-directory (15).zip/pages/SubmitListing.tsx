
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Business, Category } from '../types';
import { saveBusiness } from '../services/storageService';
import { generateBusinessDescription, generateFullBusinessDescription } from '../services/geminiService';
import { IconWand, IconMapPin, IconPhone, IconMail, IconClock, IconUpload, IconSend, IconTrash, IconStar, IconCheck } from '../components/Icons';
import PaymentModal from '../components/PaymentModal';

const SubmitListing: React.FC = () => {
    const navigate = useNavigate();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDone, setIsDone] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [keywords, setKeywords] = useState('');
    
    // Featured Listing State
    const [isFeaturedSelection, setIsFeaturedSelection] = useState(false);
    const [showPayment, setShowPayment] = useState(false);
    const [pendingBusiness, setPendingBusiness] = useState<Business | null>(null);

    const [formData, setFormData] = useState<Partial<Business>>({
        name: '',
        category: Category.OTHER,
        phone: '',
        email: '',
        whatsapp: '',
        address: '',
        latitude: 0,
        longitude: 0,
        shortDescription: '',
        description: '',
        imageUrl: '',
        images: [],
        openTime: '',
        closeTime: '',
        daysOpen: '',
        isFeatured: false
    });

    const FEATURED_PRICE = 499;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleMainImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
            reader.readAsDataURL(file);
        }
    };

    const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const filePromises = Array.from(files).map((file: File) => {
                return new Promise<string>((resolve) => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result as string);
                    reader.readAsDataURL(file);
                });
            });
            
            const newBase64Images = await Promise.all(filePromises);
            setFormData(prev => ({
                ...prev,
                images: [...(prev.images || []), ...newBase64Images]
            }));
        }
    };

    const removeGalleryImage = (indexToRemove: number) => {
        setFormData(prev => ({
            ...prev,
            images: prev.images?.filter((_, index) => index !== indexToRemove)
        }));
    };

    const handleGetLocation = () => {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition((position) => {
                setFormData(prev => ({
                    ...prev,
                    latitude: parseFloat(position.coords.latitude.toFixed(6)),
                    longitude: parseFloat(position.coords.longitude.toFixed(6))
                }));
            }, (error) => alert('Error: ' + error.message));
        } else {
            alert('Geolocation not supported');
        }
    };

    const handleAutoFill = async () => {
        if (!formData.name) {
            alert("Please enter business name first.");
            return;
        }
        setIsGenerating(true);
        const short = await generateBusinessDescription(formData.name!, formData.category!, keywords || 'Local service');
        const long = await generateFullBusinessDescription(formData.name!, formData.category!, keywords || 'Local service');
        setFormData(prev => ({ ...prev, shortDescription: short, description: long }));
        setIsGenerating(false);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        const newBusiness: Business = {
            id: Date.now().toString(),
            status: 'pending',
            name: formData.name!,
            category: formData.category!,
            shortDescription: formData.shortDescription || '',
            description: formData.description || '',
            phone: formData.phone || '',
            email: formData.email || '',
            whatsapp: formData.whatsapp || '',
            address: formData.address || '',
            latitude: formData.latitude || 0,
            longitude: formData.longitude || 0,
            imageUrl: formData.imageUrl || `https://picsum.photos/seed/${formData.name}/800/600`,
            images: formData.images || [],
            rating: 0,
            verified: false,
            isFeatured: isFeaturedSelection,
            createdAt: Date.now(),
            reviews: [],
            openTime: formData.openTime,
            closeTime: formData.closeTime,
            daysOpen: formData.daysOpen
        };

        setPendingBusiness(newBusiness);

        setTimeout(() => {
            setIsSubmitting(false);
            if (isFeaturedSelection) {
                setShowPayment(true);
            } else {
                saveBusiness(newBusiness);
                setIsDone(true);
            }
        }, 1200);
    };

    const handlePaymentSuccess = (transactionId: string) => {
        if (pendingBusiness) {
            const final = { ...pendingBusiness, paymentId: transactionId };
            saveBusiness(final);
            setShowPayment(false);
            setIsDone(true);
        }
    };

    if (isDone) {
        return (
            <div className="min-h-[70vh] flex items-center justify-center p-4">
                <div className="bg-white p-12 rounded-[3rem] shadow-2xl text-center max-w-lg border border-gray-100 animate-in zoom-in duration-300">
                    <div className="w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-xl shadow-green-100">
                        <IconSend className="w-12 h-12" />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-4">Submission Successful!</h2>
                    <p className="text-gray-500 mb-10 leading-relaxed">
                        Thank you for listing your business. Our administrators will review your details and publish it shortly. You'll be notified once it's live!
                    </p>
                    <Link to="/" className="inline-block px-10 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-lg hover:bg-indigo-700 transition-all active:scale-95">
                        Return Home
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-gray-50 min-h-screen py-16 px-4">
            <div className="container mx-auto max-w-4xl">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">List Your <span className="text-indigo-600">Business</span></h1>
                    <p className="text-gray-500 max-w-xl mx-auto">Complete the form below to add your business to the Dhone town directory. Free for everyone, with premium options for extra reach.</p>
                </div>

                <form onSubmit={handleSubmit} className="bg-white rounded-[2.5rem] shadow-xl overflow-hidden border border-gray-100">
                    <div className="p-8 md:p-12 space-y-10">
                        {/* Section 1: Basic Info */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                                <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Business Identity</h3>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Business Name*</label>
                                    <input required name="name" value={formData.name} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold" placeholder="e.g. Dhone Grand Hotel" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Category*</label>
                                    <select name="category" value={formData.category} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none appearance-none font-bold">
                                        {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                </div>
                            </div>

                            <div className="space-y-6">
                                <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Contact Details</h3>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number*</label>
                                    <input required name="phone" value={formData.phone} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">WhatsApp (Optional)</label>
                                    <input name="whatsapp" value={formData.whatsapp} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold" placeholder="91..." />
                                </div>
                            </div>
                        </div>

                        {/* Section 2: AI & Description */}
                        <div className="bg-indigo-50/50 p-8 rounded-[2rem] border border-indigo-100">
                            <div className="flex items-center justify-between mb-6">
                                <h3 className="font-black text-indigo-900 flex items-center gap-2">
                                    <IconWand className="w-5 h-5 text-indigo-600" />
                                    AI Content Assistant
                                </h3>
                                <button type="button" onClick={handleAutoFill} disabled={isGenerating || !formData.name} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md hover:bg-indigo-700 disabled:opacity-50 transition-all">
                                    {isGenerating ? 'Generating...' : 'Auto-Generate Content'}
                                </button>
                            </div>
                            <div className="space-y-6">
                                <div>
                                    <label className="block text-xs font-bold text-indigo-400 uppercase mb-2">Services / Keywords (comma separated)</label>
                                    <input value={keywords} onChange={e => setKeywords(e.target.value)} className="w-full p-4 bg-white border border-indigo-100 rounded-2xl outline-none font-bold" placeholder="e.g. Free delivery, AC, South Indian" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Catchy Short Summary*</label>
                                    <textarea required name="shortDescription" value={formData.shortDescription} onChange={handleChange} rows={2} className="w-full p-4 bg-white border border-indigo-100 rounded-2xl outline-none resize-none font-medium" placeholder="A one-sentence hook..." />
                                </div>
                            </div>
                        </div>

                        {/* Section: Premium Selection */}
                        <div className="pt-8">
                             <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2 mb-6">Visibility Options</h3>
                             <div 
                                onClick={() => setIsFeaturedSelection(!isFeaturedSelection)}
                                className={`p-6 rounded-[2rem] border-2 cursor-pointer transition-all ${isFeaturedSelection ? 'border-amber-500 bg-amber-50 shadow-xl' : 'border-slate-100 hover:border-slate-200 bg-slate-50/30'}`}
                             >
                                <div className="flex items-start justify-between">
                                    <div className="flex items-start gap-4">
                                        <div className={`p-3 rounded-2xl ${isFeaturedSelection ? 'bg-amber-500 text-white' : 'bg-slate-200 text-slate-400'}`}>
                                            <IconStar fill={isFeaturedSelection} className="w-8 h-8" />
                                        </div>
                                        <div>
                                            <h4 className="text-xl font-black text-slate-900">Featured Listing</h4>
                                            <p className="text-slate-500 text-sm font-medium mt-1">Appear at the top of results with a premium badge.</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-2xl font-black text-slate-900">₹{FEATURED_PRICE}</p>
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">One-time fee</p>
                                    </div>
                                </div>
                                {isFeaturedSelection && (
                                    <div className="mt-6 flex items-center gap-2 text-amber-700 font-bold text-sm animate-in fade-in slide-in-from-top-2">
                                        <IconCheck className="w-5 h-5" /> Proceed to payment after submission
                                    </div>
                                )}
                             </div>
                        </div>

                        {/* Section 4: Location */}
                        <div className="space-y-6">
                            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest border-b pb-2">Store Location</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Address*</label>
                                    <input required name="address" value={formData.address} onChange={handleChange} className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 outline-none transition-all font-bold" placeholder="e.g. Near Market, Dhone" />
                                </div>
                                <div className="flex items-end">
                                    <button type="button" onClick={handleGetLocation} className="w-full flex items-center justify-center gap-2 py-4 border-2 border-indigo-100 text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all h-[58px]">
                                        <IconMapPin className="w-5 h-5" /> Pin GPS Coordinates
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-gray-50 p-8 md:p-12 border-t border-gray-100 flex flex-col sm:flex-row justify-end gap-4">
                        <button type="button" onClick={() => navigate('/')} className="px-10 py-4 font-bold text-gray-500">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="px-12 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-3 disabled:opacity-70 transform hover:-translate-y-1 uppercase tracking-widest text-xs">
                            {isSubmitting ? 'Validating...' : (isFeaturedSelection ? `Pay & Submit (₹${FEATURED_PRICE})` : 'Submit Listing')}
                            {!isSubmitting && <IconSend className="w-5 h-5" />}
                        </button>
                    </div>
                </form>
            </div>

            {/* Payment Integration */}
            {showPayment && pendingBusiness && (
                <PaymentModal 
                    isOpen={showPayment}
                    onClose={() => setShowPayment(false)}
                    onSuccess={handlePaymentSuccess}
                    amount={FEATURED_PRICE}
                    itemName="Featured Business Listing"
                    itemType="listing"
                    referenceId={pendingBusiness.id}
                    customerEmail={pendingBusiness.email}
                />
            )}
        </div>
    );
};

export default SubmitListing;
