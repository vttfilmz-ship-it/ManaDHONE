
import React, { useState, useEffect, useMemo } from 'react';
import { getHistory, getTourismSpots, getHeroSlides } from '../services/storageService';
import { HeroSlide, HistoryEvent, TourismSpot } from '../types';
import Timeline from '../components/Timeline';
import { IconMapPin, IconStar, IconBook, IconClock } from '../components/Icons';

const Explore: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'history' | 'tourism'>('history');
    const [historyEvents, setHistoryEvents] = useState<HistoryEvent[]>([]);
    const [spots, setSpots] = useState<TourismSpot[]>([]);
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    useEffect(() => {
        setHistoryEvents(getHistory());
        setSpots(getTourismSpots());
        // Combine history and tourism slides for the hero
        const slides = getHeroSlides().filter(s => 
            (s.page === 'history' || s.page === 'tourism') && s.active
        );
        setHeroSlides(slides);
    }, []);

    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    return (
        <div className="bg-gray-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
            {/* Unified Hero Slider */}
            <div className="bg-slate-900 text-white py-20 px-4 text-center relative overflow-hidden h-[450px] flex items-center justify-center">
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, index) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-40' : 'opacity-0'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover" alt={slide.caption} />
                        </div>
                    ))
                ) : (
                    <div className="absolute inset-0 opacity-20">
                        <img src="https://images.unsplash.com/photo-1590120688653-5d754714f24f?q=80&w=2574&auto=format&fit=crop" className="w-full h-full object-cover" alt="History Background" />
                    </div>
                )}
                
                <div className="relative z-10 max-w-4xl">
                    <span className="inline-block bg-indigo-600 text-white text-[10px] font-black uppercase tracking-[0.4em] px-4 py-1.5 rounded-full mb-6 shadow-xl">
                        Discover Dhone
                    </span>
                    <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter drop-shadow-2xl">
                        {heroSlides.length > 0 && heroSlides[currentSlide]?.caption 
                            ? heroSlides[currentSlide].caption 
                            : "Explore our Heritage & Beauty"}
                    </h1>
                    <p className="text-xl text-indigo-100 max-w-2xl mx-auto drop-shadow-md font-medium leading-relaxed">
                        Journey through centuries of history and visit the stunning natural and spiritual landmarks of ManaDHONE.
                    </p>
                </div>
            </div>

            {/* Tab Switcher / Navigation */}
            <div className="sticky top-16 sm:top-20 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-b border-gray-200 dark:border-white/5 py-4">
                <div className="container mx-auto px-4 flex justify-center gap-4">
                    <button 
                        onClick={() => setActiveTab('history')}
                        className={`flex items-center gap-2 px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${activeTab === 'history' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 scale-105' : 'bg-gray-100 dark:bg-white/5 text-gray-500 hover:bg-gray-200'}`}
                    >
                        <IconBook className="w-4 h-4" /> Town History
                    </button>
                    <button 
                        onClick={() => setActiveTab('tourism')}
                        className={`flex items-center gap-2 px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${activeTab === 'tourism' ? 'bg-teal-600 text-white shadow-xl shadow-teal-100 scale-105' : 'bg-gray-100 dark:bg-white/5 text-gray-500 hover:bg-gray-200'}`}
                    >
                        <IconMapPin className="w-4 h-4" /> Visit Landmarks
                    </button>
                </div>
            </div>

            <div className="container mx-auto px-4 py-16">
                {activeTab === 'history' ? (
                    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4">The Legacy of Dhone</h2>
                            <p className="text-gray-500 max-w-xl mx-auto">From the golden era of kings to the bustling city of today, follow our town's remarkable journey through time.</p>
                        </div>
                        <Timeline events={historyEvents} />
                    </div>
                ) : (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4">Places to Visit</h2>
                            <p className="text-gray-500 max-w-xl mx-auto">Explore ancient temples, historic forts, and natural wonders. Plan your next local adventure right here.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {spots.map(spot => (
                                <div key={spot.id} className="bg-white dark:bg-slate-800 rounded-[2.5rem] shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-300 border border-gray-100 dark:border-slate-700 flex flex-col h-full">
                                    <div className="relative h-64 overflow-hidden shrink-0">
                                        <img 
                                            src={spot.imageUrl} 
                                            alt={spot.name} 
                                            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                                        />
                                        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                                        <div className="absolute top-4 right-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wide shadow-sm">
                                            {spot.type}
                                        </div>
                                        <div className="absolute bottom-4 left-4 text-white">
                                            <div className="flex items-center gap-1 text-sm font-medium bg-black/30 backdrop-blur-sm px-2 py-1 rounded-lg border border-white/20">
                                                <IconMapPin className="w-4 h-4 text-yellow-400" /> {spot.location}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="p-8 flex flex-col flex-1">
                                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-teal-600 transition-colors">{spot.name}</h3>
                                        <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6 text-sm flex-1">
                                            {spot.description}
                                        </p>
                                        
                                        {spot.highlights && (
                                            <div className="mb-6 bg-teal-50 dark:bg-teal-900/20 p-4 rounded-xl border border-teal-100 dark:border-teal-800/50">
                                                <h4 className="text-[10px] font-black text-teal-700 dark:text-teal-300 uppercase tracking-widest mb-2 flex items-center gap-2">
                                                    <IconStar className="w-3 h-3 fill-current" /> Expert Tips
                                                </h4>
                                                <p className="text-xs text-teal-900 dark:text-teal-100 font-medium leading-relaxed">
                                                    {spot.highlights}
                                                </p>
                                            </div>
                                        )}

                                        <a 
                                            href={spot.latitude && spot.longitude 
                                                ? `https://www.google.com/maps/search/?api=1&query=${spot.latitude},${spot.longitude}`
                                                : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(spot.name + ' ' + spot.location)}`
                                            }
                                            target="_blank"
                                            rel="noreferrer"
                                            className="w-full bg-slate-900 dark:bg-slate-700 hover:bg-teal-600 dark:hover:bg-teal-600 text-white font-black py-4 rounded-2xl transition-all shadow-xl active:scale-95 text-xs uppercase tracking-widest text-center"
                                        >
                                            View Map & Directions
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            
            {/* Footer Summary Card */}
            <div className="container mx-auto px-4 pb-20">
                <div className="bg-indigo-600 rounded-[3rem] p-12 md:p-20 text-center text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
                    <div className="relative z-10 max-w-2xl mx-auto">
                        <h2 className="text-3xl md:text-4xl font-black mb-6">Proud of our heritage?</h2>
                        <p className="text-indigo-100 text-lg mb-10 leading-relaxed">
                            If you know of a historical event or a hidden gem in Dhone that we missed, please let us know. We want to tell our town's story together.
                        </p>
                        <button className="bg-white text-indigo-700 px-10 py-4 rounded-2xl font-black shadow-2xl hover:bg-indigo-50 transition-all active:scale-95 text-xs uppercase tracking-widest">
                            Suggest a Landmark
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Explore;
