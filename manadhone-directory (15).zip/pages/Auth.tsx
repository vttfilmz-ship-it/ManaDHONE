
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { loginUser, registerUser } from '../services/storageService';
import { User } from '../types';

interface AuthProps {
    onLoginSuccess: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLoginSuccess }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const [isLogin, setIsLogin] = useState(true);
    const [error, setError] = useState('');
    const [formData, setFormData] = useState({
        username: '',
        password: '',
        name: '',
        email: ''
    });

    const from = (location.state as any)?.from?.pathname || '/';

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        setError('');
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (isLogin) {
            const user = loginUser(formData.username, formData.password);
            if (user) {
                onLoginSuccess(user);
                navigate(from, { replace: true });
            } else {
                setError('Invalid username or password.');
            }
        } else {
            if (!formData.name || !formData.email || !formData.username || !formData.password) {
                setError('All fields are required.');
                return;
            }
            const result = registerUser({
                username: formData.username,
                password: formData.password,
                name: formData.name,
                email: formData.email
            });

            if (typeof result === 'string') {
                setError(result);
            } else {
                onLoginSuccess(result);
                navigate(from, { replace: true });
            }
        }
    };

    return (
        <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
            <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100 transition-all duration-500">
                <div className="bg-indigo-600 p-8 text-center text-white">
                    <h2 className="text-3xl font-bold mb-2">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
                    <p className="text-indigo-100 opacity-80">
                        {isLogin ? 'Log in to manage your listings' : 'Join the ManaDHONE community today'}
                    </p>
                </div>
                
                <div className="p-8">
                    {error && (
                        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg">
                            <p className="text-sm text-red-700 font-medium">{error}</p>
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        {!isLogin && (
                            <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                                    <input 
                                        type="text" 
                                        name="name"
                                        required
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all" 
                                        placeholder="John Doe"
                                        value={formData.name}
                                        onChange={handleInputChange}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
                                    <input 
                                        type="email" 
                                        name="email"
                                        required
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all" 
                                        placeholder="john@example.com"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </>
                        )}
                        
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-1">Username</label>
                            <input 
                                type="text" 
                                name="username"
                                required
                                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all" 
                                placeholder="Choose a username"
                                value={formData.username}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-1">Password</label>
                            <input 
                                type="password" 
                                name="password"
                                required
                                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all" 
                                placeholder="••••••••"
                                value={formData.password}
                                onChange={handleInputChange}
                            />
                        </div>

                        <button 
                            type="submit" 
                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-100 transition-all transform hover:-translate-y-0.5 active:translate-y-0 mt-4"
                        >
                            {isLogin ? 'Sign In' : 'Register Now'}
                        </button>
                    </form>

                    <div className="mt-8 pt-6 border-t border-gray-100 text-center">
                        <p className="text-gray-500 text-sm">
                            {isLogin ? "Don't have an account?" : "Already have an account?"}
                            <button 
                                onClick={() => { setIsLogin(!isLogin); setError(''); }}
                                className="ml-2 text-indigo-600 font-bold hover:text-indigo-800 focus:outline-none"
                            >
                                {isLogin ? 'Create one here' : 'Sign in instead'}
                            </button>
                        </p>
                    </div>
                    
                    {isLogin && (
                        <div className="mt-6 text-center">
                            <p className="text-xs text-gray-400">
                                Testing? Use <strong>admin</strong> / <strong>admin</strong>
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Auth;
