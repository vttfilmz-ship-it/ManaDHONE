
import React, { useEffect, useState, useMemo } from 'react';
import { getJobs, saveJob, getHeroSlides, getJobCategories, saveJobAlert, getJobAlerts, deleteJobAlert, getCurrentUser } from '../services/storageService';
import { Job, HeroSlide, JobCategory, JobAlert, User } from '../types';
import { IconBriefcase, IconMapPin, IconClock, IconPhone, IconSearch, IconFilter, IconEdit, IconMail, IconTrash, IconStar } from '../components/Icons';

const Jobs: React.FC = () => {
    const [jobs, setJobs] = useState<Job[]>([]);
    const [categories, setCategories] = useState<JobCategory[]>([]);
    const [userAlerts, setUserAlerts] = useState<JobAlert[]>([]);
    const [currentUser, setCurrentUser] = useState<User | null>(null);

    const [search, setSearch] = useState('');
    const [filterType, setFilterType] = useState<string>('All');
    const [filterCategory, setFilterCategory] = useState<string>('All');
    
    // Hero Slider State
    const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);

    // Modals State
    const [isPostModalOpen, setIsPostModalOpen] = useState(false);
    const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);

    // Form Data
    const [newJob, setNewJob] = useState<Partial<Job>>({
        title: '', company: '', location: '', type: 'Full-time', salary: '', description: '', contact: '', category: '', applyByDate: 0, isFeatured: false
    });

    const [newAlert, setNewAlert] = useState<Partial<JobAlert>>({
        email: '', keywords: '', category: 'All', type: 'All'
    });

    useEffect(() => {
        setJobs(getJobs());
        setCategories(getJobCategories());
        setUserAlerts(getJobAlerts());
        setCurrentUser(getCurrentUser());
        const slides = getHeroSlides().filter(s => s.page === 'jobs' && s.active);
        setHeroSlides(slides);
    }, []);

    // Slider Timer
    useEffect(() => {
        if (heroSlides.length <= 1) return;
        const timer = setInterval(() => setCurrentSlide(prev => (prev + 1) % heroSlides.length), 5000);
        return () => clearInterval(timer);
    }, [heroSlides.length]);

    const filteredJobs = useMemo(() => {
        // Map items to include original admin index for priority tie-breaking
        const itemsWithMeta = jobs.map((job, index) => ({ job, originalIndex: index }));

        let result = itemsWithMeta.filter(item => {
            // Only show approved jobs
            if (item.job.status !== 'approved') return false;

            const matchesSearch = !search || 
                                  item.job.title.toLowerCase().includes(search.toLowerCase()) || 
                                  item.job.company.toLowerCase().includes(search.toLowerCase()) ||
                                  item.job.description.toLowerCase().includes(search.toLowerCase());
            const matchesType = filterType === 'All' || item.job.type === filterType;
            const matchesCategory = filterCategory === 'All' || item.job.category === filterCategory;
            
            return matchesSearch && matchesType && matchesCategory;
        });

        // Multi-tier sort
        result.sort((a, b) => {
            // Tier 1: Featured/Priority status
            if (a.job.isFeatured && !b.job.isFeatured) return -1;
            if (!a.job.isFeatured && b.job.isFeatured) return 1;

            /* Tier 2: Apply By Date (Ascending - Soonest deadline first) as requested */
            if (a.job.applyByDate !== b.job.applyByDate) {
                return a.job.applyByDate - b.job.applyByDate;
            }

            // Tier 3: Admin Manual Order (the tie-breaker)
            return a.originalIndex - b.originalIndex;
        });

        return result.map(item => item.job);
    }, [jobs, search, filterType, filterCategory]);

    // Personalized Recommendations based on User Alerts
    const recommendedJobs = useMemo(() => {
        if (!currentUser && userAlerts.length === 0) return [];
        
        // Filter alerts relevant to the current user (if logged in, by email)
        const relevantAlerts = currentUser 
            ? userAlerts.filter(a => a.email === currentUser.email)
            : userAlerts.slice(-1); // If not logged in, just use the last one they created this session

        if (relevantAlerts.length === 0) return [];

        return jobs.filter(job => {
            if (job.status !== 'approved') return false;
            return relevantAlerts.some(alert => {
                const catMatch = alert.category === 'All' || job.category === alert.category;
                const typeMatch = alert.type === 'All' || job.type === alert.type;
                const kwMatch = !alert.keywords || 
                                job.title.toLowerCase().includes(alert.keywords.toLowerCase()) || 
                                job.description.toLowerCase().includes(alert.keywords.toLowerCase());
                return catMatch && typeMatch && kwMatch;
            });
        }).slice(0, 3); // Top 3 recommendations
    }, [jobs, userAlerts, currentUser]);

    const formatTimeAgo = (date: number) => {
        const days = Math.floor((Date.now() - date) / (1000 * 60 * 60 * 24));
        if (days === 0) return 'Today';
        if (days === 1) return 'Yesterday';
        return `${days} days ago`;
    };

    const formatDate = (timestamp: number) => {
        if (!timestamp) return 'N/A';
        return new Date(timestamp).toLocaleDateString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric'
        });
    };

    const handlePostJob = (e: React.FormEvent) => {
        e.preventDefault();
        const jobToSave: Job = {
            id: Date.now().toString(),
            status: 'pending',
            title: newJob.title!,
            company: newJob.company!,
            location: newJob.location!,
            type: newJob.type! as any,
            salary: newJob.salary!,
            description: newJob.description!,
            contact: newJob.contact!,
            category: newJob.category!,
            postedDate: Date.now(),
            applyByDate: newJob.applyByDate || Date.now() + (7 * 24 * 60 * 60 * 1000),
            isFeatured: false
        };

        saveJob(jobToSave);
        setIsPostModalOpen(false);
        setNewJob({ title: '', company: '', location: '', type: 'Full-time', salary: '', description: '', contact: '', category: '', applyByDate: 0, isFeatured: false });
        alert("Job submitted successfully! It will be listed after admin approval.");
        setJobs(getJobs());
    };

    const handleSubscribeAlert = (e: React.FormEvent) => {
        e.preventDefault();
        const alertToSave: JobAlert = {
            id: Date.now().toString(),
            email: newAlert.email!,
            keywords: newAlert.keywords,
            category: newAlert.category!,
            type: newAlert.type!,
            createdAt: Date.now()
        };
        saveJobAlert(alertToSave);
        setIsAlertModalOpen(false);
        setNewAlert({ email: '', keywords: '', category: 'All', type: 'All' });
        setUserAlerts(getJobAlerts());
        alert("Success! You'll receive alerts for these matching jobs.");
    };

    const removeAlert = (id: string) => {
        if (window.confirm("Stop receiving alerts for this subscription?")) {
            deleteJobAlert(id);
            setUserAlerts(getJobAlerts());
        }
    };

    const openContextualAlert = (cat: string) => {
        setNewAlert({ ...newAlert, category: cat, email: currentUser?.email || '' });
        setIsAlertModalOpen(true);
    };

    return (
        <div className="bg-gray-50 dark:bg-slate-900 min-h-screen pb-12 transition-colors duration-300 font-sans">
            {/* Hero Section */}
            <div className="bg-indigo-900 text-white py-16 relative overflow-hidden h-[450px] flex flex-col items-center justify-center">
                {heroSlides.length > 0 ? (
                    heroSlides.map((slide, index) => (
                        <div 
                            key={slide.id} 
                            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-40' : 'opacity-0'}`}
                        >
                            <img src={slide.imageUrl} className="w-full h-full object-cover" alt={slide.caption} />
                            <div className="absolute inset-0 bg-indigo-900/60 mix-blend-multiply"></div>
                        </div>
                    ))
                ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-indigo-800 to-indigo-950"></div>
                )}
                
                <div className="container mx-auto px-4 text-center relative z-10">
                    <h1 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter drop-shadow-2xl">
                        {heroSlides.length > 0 && heroSlides[currentSlide]?.caption 
                            ? heroSlides[currentSlide].caption 
                            : <span>Your Next Big <span className="text-indigo-400 text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-teal-300">Opportunity</span></span>}
                    </h1>
                    <p className="text-lg md:text-xl text-indigo-100 max-w-2xl mx-auto mb-10 drop-shadow-sm font-medium">
                        Dhone's official job board. Connecting 500+ local businesses with professional talent.
                    </p>

                    {/* Enhanced Search Bar */}
                    <div className="max-w-4xl mx-auto bg-white/10 backdrop-blur-md p-2 rounded-[2rem] border border-white/20 shadow-2xl flex flex-col md:flex-row gap-2">
                        <div className="flex-1 flex items-center px-6 bg-white rounded-[1.5rem]">
                            <IconSearch className="w-5 h-5 text-indigo-400" />
                            <input 
                                type="text" 
                                placeholder="Search roles, companies or skills..." 
                                className="w-full p-4 bg-transparent outline-none text-gray-800 font-bold"
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                            />
                        </div>
                        <div className="flex gap-2 p-1">
                            <select 
                                className="bg-white/90 backdrop-blur rounded-2xl px-4 py-3 text-indigo-900 font-black text-xs uppercase tracking-widest outline-none border-0"
                                value={filterCategory}
                                onChange={(e) => setFilterCategory(e.target.value)}
                            >
                                <option value="All">Categories</option>
                                {categories.map(cat => (
                                    <option key={cat.id} value={cat.name}>{cat.name}</option>
                                ))}
                            </select>
                            <button className="bg-indigo-500 hover:bg-indigo-400 text-white font-black px-8 py-3 rounded-2xl transition-all shadow-lg active:scale-95 text-xs uppercase tracking-widest">
                                Search
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 py-12 max-w-7xl flex flex-col lg:flex-row gap-10">
                
                {/* Main Content: Jobs */}
                <div className="flex-1">
                    {/* Personalized Recommendations Section */}
                    {recommendedJobs.length > 0 && (
                        <div className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="flex items-center gap-2 mb-6">
                                <div className="p-2 bg-amber-100 rounded-lg text-amber-600"><IconStar fill className="w-5 h-5" /></div>
                                <h2 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">Hand-picked for You</h2>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {recommendedJobs.map(job => (
                                    <div key={`rec-${job.id}`} className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-xl hover:scale-[1.02] transition-transform group">
                                        <span className="bg-white/20 text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded mb-3 inline-block">Matched Alert</span>
                                        <h3 className="text-xl font-bold mb-1 truncate">{job.title}</h3>
                                        <p className="text-indigo-100 text-sm mb-4 opacity-90">{job.company}</p>
                                        <div className="flex items-center justify-between mt-auto">
                                            <span className="text-xs font-bold font-mono">{job.salary}</span>
                                            <a href={`tel:${job.contact}`} className="bg-white text-indigo-700 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg">Apply</a>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                        <div>
                            <h2 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight">Active Vacancies</h2>
                            <p className="text-gray-500 text-sm font-medium">{filteredJobs.length} listings available today</p>
                        </div>
                        
                        {filterCategory !== 'All' && (
                            <button 
                                onClick={() => openContextualAlert(filterCategory)}
                                className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-5 py-2.5 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 border border-indigo-100 dark:border-indigo-800 transition-all hover:bg-indigo-100 active:scale-95"
                            >
                                <IconMail className="w-4 h-4" /> Notify me of new {filterCategory} jobs
                            </button>
                        )}
                    </div>

                    <div className="space-y-4">
                        {filteredJobs.length > 0 ? (
                            filteredJobs.map(job => (
                                <div key={job.id} className={`bg-white dark:bg-slate-800 rounded-[2rem] p-8 shadow-sm hover:shadow-2xl transition-all duration-300 border flex flex-col md:flex-row gap-8 group ${job.isFeatured ? 'border-amber-400 ring-1 ring-amber-200' : 'border-gray-100 dark:border-slate-700'}`}>
                                    <div className="w-20 h-20 bg-gray-50 dark:bg-slate-700 rounded-2xl flex items-center justify-center shrink-0 border border-gray-100 dark:border-slate-600 transition-colors group-hover:bg-indigo-50">
                                        <IconBriefcase className="w-10 h-10 text-gray-400 group-hover:text-indigo-600" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-4">
                                            <div>
                                                <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-1 group-hover:text-indigo-600 transition-colors">{job.title}</h3>
                                                <p className="text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-2">
                                                    {job.company}
                                                    <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                                                    <span className="text-gray-400 text-xs font-medium uppercase tracking-widest">{job.category}</span>
                                                </p>
                                            </div>
                                            <div className="flex flex-wrap gap-2">
                                                {job.isFeatured && (
                                                    <span className="bg-amber-500 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-md">
                                                        Featured
                                                    </span>
                                                )}
                                                <span className="bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-indigo-100 dark:border-indigo-800">
                                                    {job.type}
                                                </span>
                                                <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border ${job.applyByDate < Date.now() ? 'bg-red-50 text-red-600 border-red-100' : 'bg-green-50 text-green-600 border-green-100'}`}>
                                                    Exp: {formatDate(job.applyByDate)}
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div className="flex flex-wrap gap-6 text-sm text-gray-500 font-bold mb-6">
                                            <div className="flex items-center gap-1.5"><IconMapPin className="w-4 h-4 text-red-500" /> {job.location}</div>
                                            <div className="flex items-center gap-1.5"><IconBriefcase className="w-4 h-4 text-indigo-500" /> {job.salary}</div>
                                            <div className="flex items-center gap-1.5"><IconClock className="w-4 h-4 text-emerald-500" /> {formatTimeAgo(job.postedDate)}</div>
                                        </div>
                                        
                                        <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed line-clamp-2 italic">"{job.description}"</p>
                                    </div>
                                    <div className="flex items-center border-t md:border-t-0 md:border-l border-gray-50 dark:border-slate-700 pt-6 md:pt-0 md:pl-8">
                                        <a 
                                            href={`tel:${job.contact}`} 
                                            className="w-full md:w-auto bg-gray-900 dark:bg-white text-white dark:text-slate-900 font-black py-4 px-10 rounded-2xl transition-all shadow-xl active:scale-95 text-sm uppercase tracking-widest hover:bg-indigo-600 hover:text-white"
                                        >
                                            Quick Apply
                                        </a>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="text-center py-32 bg-white dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-gray-200 dark:border-slate-700">
                                <IconSearch className="w-16 h-16 text-gray-200 mx-auto mb-6" />
                                <h3 className="text-2xl font-black text-gray-900 dark:text-white">No jobs match your search</h3>
                                <p className="text-gray-500 mt-2 max-w-xs mx-auto font-medium">Try broadening your filters or reset to see all local openings.</p>
                                <button onClick={() => {setSearch(''); setFilterCategory('All'); setFilterType('All');}} className="mt-8 bg-indigo-50 text-indigo-600 font-black px-8 py-3 rounded-2xl text-xs uppercase tracking-widest">Reset All Filters</button>
                            </div>
                        )}
                    </div>
                </div>

                {/* Sidebar */}
                <div className="w-full lg:w-96 shrink-0 space-y-8">
                    {/* Management Area for Alerts */}
                    {userAlerts.length > 0 && (
                        <div className="bg-white dark:bg-slate-800 rounded-[2.5rem] p-8 shadow-sm border border-gray-100 dark:border-slate-700">
                            <h3 className="text-xl font-black text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                                <IconMail className="w-5 h-5 text-indigo-600" />
                                Your Subscriptions
                            </h3>
                            <div className="space-y-3">
                                {userAlerts.filter(a => !currentUser || a.email === currentUser.email).map(alert => (
                                    <div key={alert.id} className="p-4 bg-gray-50 dark:bg-slate-900/50 rounded-2xl border border-gray-100 dark:border-slate-700 group">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">
                                                {alert.category === 'All' ? 'Every Job' : alert.category}
                                            </span>
                                            <button 
                                                onClick={() => removeAlert(alert.id)}
                                                className="text-gray-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                                            >
                                                <IconTrash className="w-4 h-4" />
                                            </button>
                                        </div>
                                        <p className="text-xs font-bold text-gray-700 dark:text-gray-300 truncate">{alert.email}</p>
                                        {alert.keywords && <p className="text-[9px] text-gray-400 mt-1 uppercase font-medium">Keywords: {alert.keywords}</p>}
                                    </div>
                                ))}
                            </div>
                            <p className="text-[10px] text-gray-400 mt-4 text-center font-bold uppercase tracking-tighter italic">Emails sent automatically upon approval</p>
                        </div>
                    )}

                    <div className="bg-indigo-600 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
                        <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mb-6 backdrop-blur-md">
                            <IconMail className="w-8 h-8" />
                        </div>
                        <h3 className="text-2xl font-black mb-3 leading-tight">Get New Jobs in Your Inbox</h3>
                        <p className="text-indigo-100 text-sm mb-8 leading-relaxed font-medium">
                            Don't check back every day. Let the opportunities find you based on your unique skills.
                        </p>
                        <button 
                            onClick={() => setIsAlertModalOpen(true)}
                            className="w-full bg-white text-indigo-900 font-black py-4 rounded-2xl shadow-xl hover:bg-indigo-50 transition-all active:scale-95 text-xs uppercase tracking-widest"
                        >
                            Set Alert Preferences
                        </button>
                    </div>

                    <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group">
                        <div className="w-14 h-14 bg-indigo-500 rounded-2xl flex items-center justify-center mb-6">
                            <IconEdit className="w-8 h-8" />
                        </div>
                        <h3 className="text-2xl font-black mb-3">Hiring in Dhone?</h3>
                        <p className="text-slate-400 text-sm mb-8 font-medium">
                            Post your job opening and reach thousands of local residents and skilled professionals.
                        </p>
                        <button 
                            onClick={() => setIsPostModalOpen(true)}
                            className="w-full bg-indigo-500 hover:bg-indigo-400 text-white font-black py-4 rounded-2xl transition-all shadow-xl active:scale-95 text-xs uppercase tracking-widest"
                        >
                            Post a Job Listing
                        </button>
                    </div>
                </div>
            </div>

            {/* Alert Modal */}
            {isAlertModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-slate-800 rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="bg-indigo-600 p-8 text-white">
                            <div className="flex justify-between items-start mb-4">
                                <IconMail className="w-12 h-12" />
                                <button onClick={() => setIsAlertModalOpen(false)} className="text-white/60 hover:text-white transition-colors">
                                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5" strokeLinecap="round"/></svg>
                                </button>
                            </div>
                            <h3 className="text-3xl font-black tracking-tight mb-2">Job Notifications</h3>
                            <p className="text-indigo-100 text-sm font-medium">We'll email you immediately when a matching job is verified by admin.</p>
                        </div>
                        
                        <div className="p-8">
                            <form onSubmit={handleSubscribeAlert} className="space-y-6">
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Email Address</label>
                                    <input 
                                        type="email" 
                                        required 
                                        className="w-full p-4 bg-gray-50 dark:bg-slate-700 border-2 border-gray-100 dark:border-slate-600 rounded-2xl focus:border-indigo-500 outline-none font-bold dark:text-white transition-all" 
                                        value={newAlert.email} 
                                        onChange={e => setNewAlert({...newAlert, email: e.target.value})}
                                        placeholder="your@email.com"
                                    />
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Category</label>
                                        <select 
                                            className="w-full p-4 bg-gray-50 dark:bg-slate-700 border-2 border-gray-100 dark:border-slate-600 rounded-2xl focus:border-indigo-500 outline-none font-bold appearance-none dark:text-white" 
                                            value={newAlert.category} 
                                            onChange={e => setNewAlert({...newAlert, category: e.target.value})}
                                        >
                                            <option value="All">All Categories</option>
                                            {categories.map(cat => (
                                                <option key={cat.id} value={cat.name}>{cat.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Job Type</label>
                                        <select 
                                            className="w-full p-4 bg-gray-50 dark:bg-slate-700 border-2 border-gray-100 dark:border-slate-600 rounded-2xl focus:border-indigo-500 outline-none font-bold appearance-none dark:text-white" 
                                            value={newAlert.type} 
                                            onChange={e => setNewAlert({...newAlert, type: e.target.value})}
                                        >
                                            <option value="All">Any Type</option>
                                            <option value="Full-time">Full-time</option>
                                            <option value="Part-time">Part-time</option>
                                            <option value="Contract">Contract</option>
                                        </select>
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Keywords (Optional)</label>
                                    <input 
                                        type="text" 
                                        className="w-full p-4 bg-gray-50 dark:bg-slate-700 border-2 border-gray-100 dark:border-slate-600 rounded-2xl focus:border-indigo-500 outline-none font-bold dark:text-white transition-all" 
                                        value={newAlert.keywords} 
                                        onChange={e => setNewAlert({...newAlert, keywords: e.target.value})}
                                        placeholder="e.g. driver, react, nurse"
                                    />
                                </div>

                                <div className="pt-4">
                                    <button 
                                        type="submit" 
                                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-indigo-100 transition-all active:scale-95 uppercase tracking-widest text-xs"
                                    >
                                        Activate My Alerts
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}

            {/* Post Job Modal (Simplified for better UX) */}
            {isPostModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-slate-800 rounded-[3rem] shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
                        <div className="bg-slate-900 p-8 text-white flex justify-between items-center shrink-0">
                            <div>
                                <h3 className="text-3xl font-black tracking-tight">Hire Talent</h3>
                                <p className="text-slate-400 text-sm font-medium mt-1">Submit your details. Free listing for Dhone businesses.</p>
                            </div>
                            <button onClick={() => setIsPostModalOpen(false)} className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors text-white">
                                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5" strokeLinecap="round"/></svg>
                            </button>
                        </div>
                        
                        <div className="p-8 overflow-y-auto custom-scrollbar">
                            <form onSubmit={handlePostJob} className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Job Title</label>
                                        <input required className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold" value={newJob.title} onChange={e => setNewJob({...newJob, title: e.target.value})} placeholder="e.g. Sales Executive" />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Company Name</label>
                                        <input required className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold" value={newJob.company} onChange={e => setNewJob({...newJob, company: e.target.value})} />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Category</label>
                                        <select required className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold appearance-none" value={newJob.category} onChange={e => setNewJob({...newJob, category: e.target.value})}>
                                            <option value="">Select Category</option>
                                            {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Salary</label>
                                        <input required className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold" value={newJob.salary} onChange={e => setNewJob({...newJob, salary: e.target.value})} placeholder="e.g. ₹15,000/month" />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Responsibilities</label>
                                    <textarea required rows={4} className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-medium resize-none" value={newJob.description} onChange={e => setNewJob({...newJob, description: e.target.value})} placeholder="What will the employee do?" />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Contact Info</label>
                                        <input required className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold" value={newJob.contact} onChange={e => setNewJob({...newJob, contact: e.target.value})} />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Apply By Date</label>
                                        <input required type="date" className="w-full p-4 border-2 border-gray-100 rounded-2xl bg-gray-50 focus:border-indigo-500 outline-none font-bold" value={newJob.applyByDate ? new Date(newJob.applyByDate).toISOString().split('T')[0] : ''} onChange={e => setNewJob({...newJob, applyByDate: new Date(e.target.value).getTime()})} />
                                    </div>
                                </div>

                                <div className="pt-6 flex gap-4">
                                    <button type="button" onClick={() => setIsPostModalOpen(false)} className="flex-1 py-4 text-gray-400 font-black uppercase tracking-widest text-xs">Discard</button>
                                    <button type="submit" className="flex-[2] py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 transition-all active:scale-95 uppercase tracking-widest text-xs">Submit Vacancy</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Jobs;
