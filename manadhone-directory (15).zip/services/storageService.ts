
import { Business, Category, Advert, Review, NewsItem, AnalyticsData, Influencer, LocalEvent, EmergencyContact, Job, HistoryEvent, TourismSpot, WeatherData, User, HeroSlide, Freelancer, JobCategory, JobAlert, FMProgram, AdRequest, TownStats, Property, RealEstateAgent, Transaction, Broadcast } from '../types';

const STORAGE_KEY = 'manadhone_directory_v1';
const ADS_STORAGE_KEY = 'manadhone_ads_v1';
const AD_REQUESTS_KEY = 'manadhone_ad_requests_v1';
const NEWS_STORAGE_KEY = 'manadhone_news_v1';
const INFLUENCERS_STORAGE_KEY = 'manadhone_influencers_v1';
const EVENTS_STORAGE_KEY = 'manadhone_events_v1';
const CONTACTS_STORAGE_KEY = 'manadhone_contacts_v1';
const JOBS_STORAGE_KEY = 'manadhone_jobs_v1';
const JOB_CATEGORIES_STORAGE_KEY = 'manadhone_job_categories_v1';
const JOB_ALERTS_STORAGE_KEY = 'manadhone_job_alerts_v1';
const FREELANCERS_STORAGE_KEY = 'manadhone_freelancers_v1';
const HISTORY_STORAGE_KEY = 'manadhone_history_v1';
const TOURISM_STORAGE_KEY = 'manadhone_tourism_v1';
const HERO_SLIDES_KEY = 'manadhone_hero_slides_v1';
const USERS_STORAGE_KEY = 'manadhone_users_v1';
const CURRENT_USER_KEY = 'manadhone_current_user';
const SAVED_BUSINESSES_KEY = 'manadhone_saved_businesses_v1';
const FM_STORAGE_KEY = 'manadhone_fm_schedule_v1';
const TOWN_STATS_KEY = 'manadhone_town_stats_v1';
const PROPERTIES_STORAGE_KEY = 'manadhone_properties_v1';
const AGENTS_STORAGE_KEY = 'manadhone_agents_v1';
const TRANSACTIONS_KEY = 'manadhone_transactions_v1';
const BROADCASTS_KEY = 'manadhone_broadcasts_v1';

// Initial Admin User
const DEFAULT_ADMIN: User = {
    id: 'admin_01',
    username: 'admin',
    password: 'admin',
    name: 'Town Administrator',
    email: 'admin@manadhone.gov',
    role: 'admin'
};

const DEFAULT_TOWN_STATS: TownStats = {
    id: 'town_stats_01',
    residents: '50k+',
    dailyVisitors: '1,200+',
    verifiedShops: '250+',
    activeListings: '500+',
    lastUpdated: Date.now()
};

const DEFAULT_JOB_CATEGORIES: JobCategory[] = [
    { id: 'cat1', name: 'Sales & Marketing' },
    { id: 'cat2', name: 'Information Technology' },
    { id: 'cat3', name: 'Medical & Healthcare' },
    { id: 'cat4', name: 'Education & Teaching' },
    { id: 'cat5', name: 'Construction & Labor' },
    { id: 'cat6', name: 'Drivers & Transport' },
    { id: 'cat7', name: 'Hotel & Restaurant' }
];

const MOCK_HERO_SLIDES: HeroSlide[] = [
    { id: 'hr1', imageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=2573&auto=format&fit=crop', caption: 'Your Dream Home Awaits', active: true, page: 'realestate' },
    { id: 'hr2', imageUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2670&auto=format&fit=crop', caption: 'Prime Commercial Spaces', active: true, page: 'realestate' },
    { id: 'hr3', imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=2574&auto=format&fit=crop', caption: 'Investment Plots in Dhone', active: true, page: 'realestate' }
];

const MOCK_FM_SCHEDULE: FMProgram[] = [
    { id: 'fm1', time: '06:00 AM', title: 'Suprabhatam Dhone', host: 'RJ Vasu', active: true, status: 'approved', audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
    { id: 'fm2', time: '09:00 AM', title: 'Dhone Morning Drive', host: 'RJ Priya', active: true, status: 'approved', audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
    { id: 'fm3', time: '01:00 PM', title: 'Rayalaseema Rhythms', host: 'RJ Karthik', active: true, status: 'approved', audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
    { id: 'fm4', time: '05:00 PM', title: 'Evening Chill', host: 'RJ Sneha', active: true, status: 'approved', audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3' },
    { id: 'fm5', time: '08:00 PM', title: 'Night Melodies', host: 'RJ Rahul', active: true, status: 'approved', audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3' }
];

// --- STARS MOCK DATA ---
const MOCK_INFLUENCERS: Influencer[] = [
    { id: 'st1', name: 'Ravi Varma', handle: '@ravivarma_dhone', platform: 'Instagram', followers: '45k', imageUrl: 'https://i.pravatar.cc/150?u=st1', profileUrl: 'https://instagram.com' },
    { id: 'st2', name: 'Dhone Foodie', handle: 'Dhone Food Diaries', platform: 'YouTube', followers: '120k', imageUrl: 'https://i.pravatar.cc/150?u=st2', profileUrl: 'https://youtube.com' },
    { id: 'st3', name: 'Lakshmi Clickz', handle: '@lakshmi_photography', platform: 'Instagram', followers: '12k', imageUrl: 'https://i.pravatar.cc/150?u=st3', profileUrl: 'https://instagram.com' },
    { id: 'st4', name: 'Siva Dhone News', handle: 'Siva Updates', platform: 'Facebook', followers: '25k', imageUrl: 'https://i.pravatar.cc/150?u=st4', profileUrl: 'https://facebook.com' }
];

// --- REAL ESTATE MOCK DATA ---
const MOCK_AGENTS: RealEstateAgent[] = [
    { id: 'ag1', name: 'Venkata Rao', agency: 'Dhone Prime Realty', phone: '+91 99887 76655', imageUrl: 'https://i.pravatar.cc/150?u=ag1', bio: 'Expert in agricultural lands and residential plots.', experience: '15 Years', verified: true },
    { id: 'ag2', name: 'Lakshmi Devi', agency: 'Smart Homes Dhone', phone: '+91 98480 12345', imageUrl: 'https://i.pravatar.cc/150?u=ag2', bio: 'Specializing in residential villas and rental apartments.', experience: '8 Years', verified: true }
];

const MOCK_PROPERTIES: Property[] = [
    { 
        id: 'p1', 
        title: 'Premium 2BHK near Gandhi Circle', 
        type: 'Apartment', 
        purpose: 'Sale', 
        price: '₹45 Lakhs', 
        area: '1200 Sqft', 
        location: 'Gandhi Nagar, Dhone', 
        description: 'Newly built apartment with 24/7 water supply and parking.', 
        imageUrl: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2670&auto=format&fit=crop', 
        agentId: 'ag2', 
        status: 'available', 
        featured: true, 
        createdAt: Date.now(),
        bedrooms: 2,
        bathrooms: 2,
        parking: true,
        amenities: ['Gated Community', 'Lift', 'Security']
    },
    { 
        id: 'p2', 
        title: 'Commercial Plot on Highway', 
        type: 'Plot', 
        purpose: 'Sale', 
        price: '₹1.2 Cr', 
        area: '400 Sqyd', 
        location: 'NH-44 Bypass, Dhone', 
        description: 'Ideal for showrooms or warehouses. Prime location.', 
        imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=2574&auto=format&fit=crop', 
        agentId: 'ag1', 
        status: 'available', 
        featured: true, 
        createdAt: Date.now(),
        amenities: ['Power Backup', 'Water Connection']
    }
];

// --- Generic Storage Helpers ---
function getFromStorage<T>(key: string, defaultData: T[]): T[] {
    const data = localStorage.getItem(key);
    if (!data) {
        localStorage.setItem(key, JSON.stringify(defaultData));
        return defaultData;
    }
    return JSON.parse(data);
}

function saveToStorage<T extends { id: string }>(key: string, item: T): T {
    const items = getFromStorage<T>(key, []);
    const index = items.findIndex(i => i.id === item.id);
    if (index >= 0) {
        items[index] = item;
    } else {
        items.push(item);
    }
    localStorage.setItem(key, JSON.stringify(items));
    return item;
}

// Helper for reordering
export const saveOrderedItems = (key: string, items: any[]) => {
    localStorage.setItem(key, JSON.stringify(items));
};

// --- Stats Management ---
export const getTownStats = (): TownStats => {
    const data = localStorage.getItem(TOWN_STATS_KEY);
    if (!data) {
        localStorage.setItem(TOWN_STATS_KEY, JSON.stringify(DEFAULT_TOWN_STATS));
        return DEFAULT_TOWN_STATS;
    }
    return JSON.parse(data);
};

export const saveTownStats = (stats: TownStats) => {
    localStorage.setItem(TOWN_STATS_KEY, JSON.stringify(stats));
    return stats;
};

// --- TRANSACTION FUNCTIONS ---
export const getTransactions = (): Transaction[] => getFromStorage(TRANSACTIONS_KEY, []);
export const saveTransaction = (t: Transaction) => saveToStorage(TRANSACTIONS_KEY, t);
export const deleteTransaction = (id: string) => {
    const items = getTransactions();
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};

// --- BROADCAST FUNCTIONS ---
export const getBroadcasts = (): Broadcast[] => getFromStorage(BROADCASTS_KEY, []);
export const saveBroadcast = (b: Broadcast) => saveToStorage(BROADCASTS_KEY, b);
export const deleteBroadcast = (id: string) => {
    const items = getBroadcasts();
    localStorage.setItem(BROADCASTS_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};

// --- REAL ESTATE FUNCTIONS ---
export const getProperties = (): Property[] => getFromStorage(PROPERTIES_STORAGE_KEY, MOCK_PROPERTIES);
export const saveProperty = (p: Property) => saveToStorage(PROPERTIES_STORAGE_KEY, p);
export const deleteProperty = (id: string) => {
    const items = getFromStorage<Property>(PROPERTIES_STORAGE_KEY, []);
    localStorage.setItem(PROPERTIES_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllProperties = (items: Property[]) => saveOrderedItems(PROPERTIES_STORAGE_KEY, items);

export const getAgents = (): RealEstateAgent[] => getFromStorage(AGENTS_STORAGE_KEY, MOCK_AGENTS);
export const saveAgent = (a: RealEstateAgent) => saveToStorage(AGENTS_STORAGE_KEY, a);
export const deleteAgent = (id: string) => {
    const items = getFromStorage<RealEstateAgent>(AGENTS_STORAGE_KEY, []);
    localStorage.setItem(AGENTS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllAgents = (items: RealEstateAgent[]) => saveOrderedItems(AGENTS_STORAGE_KEY, items);

// --- AUTH ---
export const getUsers = (): User[] => getFromStorage(USERS_STORAGE_KEY, [DEFAULT_ADMIN]);
export const saveUser = (user: User) => saveToStorage(USERS_STORAGE_KEY, user);
export const deleteUser = (id: string) => {
    if (id === 'admin_01') return;
    const items = getFromStorage<User>(USERS_STORAGE_KEY, []);
    const filtered = items.filter(i => i.id !== id);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(filtered));
};
export const saveAllUsers = (items: User[]) => saveOrderedItems(USERS_STORAGE_KEY, items);

export const registerUser = (user: Omit<User, 'id' | 'role'>): User | string => {
    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === user.username.toLowerCase())) {
        return "Username already exists";
    }
    const newUser: User = { ...user, id: Date.now().toString(), role: 'user' };
    users.push(newUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    return newUser;
};

export const loginUser = (username: string, password: string): User | null => {
    const users = getUsers();
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
    if (user) {
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
        return user;
    }
    return null;
};

export const getCurrentUser = (): User | null => {
    const data = localStorage.getItem(CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
};

export const logoutUser = () => {
    localStorage.removeItem(CURRENT_USER_KEY);
};

// --- Business Functions ---
export const getBusinesses = (): Business[] => getFromStorage(STORAGE_KEY, []);
export const saveBusiness = (business: Business) => saveToStorage(STORAGE_KEY, business);
export const deleteBusiness = (id: string) => {
    const items = getFromStorage<Business>(STORAGE_KEY, []);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllBusinesses = (items: Business[]) => saveOrderedItems(STORAGE_KEY, items);

// --- Review Functions ---
export interface ReviewWithBusiness extends Review {
    businessId: string;
    businessName: string;
}
export const getAllReviews = (): ReviewWithBusiness[] => {
    const businesses = getBusinesses();
    const allReviews: ReviewWithBusiness[] = [];
    businesses.forEach(b => {
        if (b.reviews) {
            b.reviews.forEach(r => {
                allReviews.push({ ...r, businessId: b.id, businessName: b.name });
            });
        }
    });
    return allReviews.sort((a, b) => b.date - a.date);
};

export const deleteReview = (businessId: string, reviewId: string) => {
    const businesses = getBusinesses();
    const index = businesses.findIndex(b => b.id === businessId);
    if (index >= 0) {
        const business = businesses[index];
        business.reviews = business.reviews?.filter(r => r.id !== reviewId) || [];
        if (business.reviews.length > 0) {
            const sum = business.reviews.reduce((acc, r) => acc + r.rating, 0);
            business.rating = parseFloat((sum / business.reviews.length).toFixed(1));
        } else business.rating = 0;
        businesses[index] = business;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(businesses));
    }
};

// --- Other Data Functions ---
export const getAds = () => getFromStorage<Advert>(ADS_STORAGE_KEY, []);
export const saveAd = (i: Advert) => saveToStorage(ADS_STORAGE_KEY, i);
export const deleteAd = (id: string) => {
    const items = getFromStorage<Advert>(ADS_STORAGE_KEY, []);
    localStorage.setItem(ADS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllAds = (items: Advert[]) => saveOrderedItems(ADS_STORAGE_KEY, items);

export const getNews = () => getFromStorage(NEWS_STORAGE_KEY, []);
export const saveNews = (i: NewsItem) => saveToStorage(NEWS_STORAGE_KEY, i);
export const deleteNews = (id: string) => {
    const items = getFromStorage<NewsItem>(NEWS_STORAGE_KEY, []);
    localStorage.setItem(NEWS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllNews = (items: NewsItem[]) => saveOrderedItems(NEWS_STORAGE_KEY, items);

export const getEvents = () => getFromStorage(EVENTS_STORAGE_KEY, []);
export const saveEvent = (i: LocalEvent) => saveToStorage(EVENTS_STORAGE_KEY, i);
export const deleteEvent = (id: string) => {
    const items = getFromStorage<LocalEvent>(EVENTS_STORAGE_KEY, []);
    localStorage.setItem(EVENTS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllEvents = (items: LocalEvent[]) => saveOrderedItems(EVENTS_STORAGE_KEY, items);

export const getInfluencers = () => getFromStorage(INFLUENCERS_STORAGE_KEY, MOCK_INFLUENCERS);
export const saveInfluencer = (i: Influencer) => saveToStorage(INFLUENCERS_STORAGE_KEY, i);
export const deleteInfluencer = (id: string) => {
    const items = getFromStorage<Influencer>(INFLUENCERS_STORAGE_KEY, []);
    localStorage.setItem(INFLUENCERS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllInfluencers = (items: Influencer[]) => saveOrderedItems(INFLUENCERS_STORAGE_KEY, items);

export const getContacts = () => getFromStorage(CONTACTS_STORAGE_KEY, []);
export const saveContact = (i: EmergencyContact) => saveToStorage(CONTACTS_STORAGE_KEY, i);
export const deleteContact = (id: string) => {
    const items = getFromStorage<EmergencyContact>(CONTACTS_STORAGE_KEY, []);
    localStorage.setItem(CONTACTS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllContacts = (items: EmergencyContact[]) => saveOrderedItems(CONTACTS_STORAGE_KEY, items);

export const getJobs = () => getFromStorage(JOBS_STORAGE_KEY, []);
export const saveJob = (i: Job) => saveToStorage(JOBS_STORAGE_KEY, i);
export const deleteJob = (id: string) => {
    const items = getFromStorage<Job>(JOBS_STORAGE_KEY, []);
    localStorage.setItem(JOBS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllJobs = (items: Job[]) => saveOrderedItems(JOBS_STORAGE_KEY, items);

export const getJobAlerts = () => getFromStorage<JobAlert>(JOB_ALERTS_STORAGE_KEY, []);
export const saveJobAlert = (i: JobAlert) => saveToStorage(JOB_ALERTS_STORAGE_KEY, i);
export const deleteJobAlert = (id: string) => {
    const items = getFromStorage<JobAlert>(JOB_ALERTS_STORAGE_KEY, []);
    localStorage.setItem(JOB_ALERTS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};

export const getJobCategories = () => getFromStorage(JOB_CATEGORIES_STORAGE_KEY, DEFAULT_JOB_CATEGORIES);
export const saveJobCategory = (i: JobCategory) => saveToStorage(JOB_CATEGORIES_STORAGE_KEY, i);
export const deleteJobCategory = (id: string) => {
    const items = getFromStorage<JobCategory>(JOB_CATEGORIES_STORAGE_KEY, []);
    localStorage.setItem(JOB_CATEGORIES_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};

export const getFreelancers = () => getFromStorage(FREELANCERS_STORAGE_KEY, []);
export const saveFreelancer = (i: Freelancer) => saveToStorage(FREELANCERS_STORAGE_KEY, i);
export const deleteFreelancer = (id: string) => {
    const items = getFromStorage<Freelancer>(FREELANCERS_STORAGE_KEY, []);
    localStorage.setItem(FREELANCERS_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllFreelancers = (items: Freelancer[]) => saveOrderedItems(FREELANCERS_STORAGE_KEY, items);

export const getHistory = () => getFromStorage(HISTORY_STORAGE_KEY, []);
export const saveHistoryEvent = (i: HistoryEvent) => saveToStorage(HISTORY_STORAGE_KEY, i);
export const deleteHistoryEvent = (id: string) => {
    const items = getFromStorage<HistoryEvent>(HISTORY_STORAGE_KEY, []);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllHistoryEvents = (items: HistoryEvent[]) => saveOrderedItems(HISTORY_STORAGE_KEY, items);

export const getTourismSpots = () => getFromStorage(TOURISM_STORAGE_KEY, []);
export const saveTourismSpot = (i: TourismSpot) => saveToStorage(TOURISM_STORAGE_KEY, i);
export const deleteTourismSpot = (id: string) => {
    const items = getFromStorage<TourismSpot>(TOURISM_STORAGE_KEY, []);
    localStorage.setItem(TOURISM_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllTourismSpots = (items: TourismSpot[]) => saveOrderedItems(TOURISM_STORAGE_KEY, items);

export const getHeroSlides = () => getFromStorage(HERO_SLIDES_KEY, MOCK_HERO_SLIDES);
export const saveHeroSlide = (i: HeroSlide) => saveToStorage(HERO_SLIDES_KEY, i);
export const deleteHeroSlide = (id: string) => {
    const items = getFromStorage<HeroSlide>(HERO_SLIDES_KEY, []);
    localStorage.setItem(HERO_SLIDES_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllHeroSlides = (items: HeroSlide[]) => saveOrderedItems(HERO_SLIDES_KEY, items);

export const getFMSchedule = () => getFromStorage(FM_STORAGE_KEY, MOCK_FM_SCHEDULE);
export const saveFMProgram = (i: FMProgram) => saveToStorage(FM_STORAGE_KEY, i);
export const deleteFMProgram = (id: string) => {
    const items = getFromStorage<FMProgram>(FM_STORAGE_KEY, []);
    localStorage.setItem(FM_STORAGE_KEY, JSON.stringify(items.filter(i => i.id !== id)));
};
export const saveAllFMPrograms = (items: FMProgram[]) => saveOrderedItems(FM_STORAGE_KEY, items);

export const saveAdRequest = (i: AdRequest) => saveToStorage(AD_REQUESTS_KEY, i);

export const incrementViewCount = (id: string) => {
    const businesses = getBusinesses();
    const index = businesses.findIndex(b => b.id === id);
    if (index >= 0) {
        businesses[index].views = (businesses[index].views || 0) + 1;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(businesses));
    }
};

export const addReview = (businessId: string, review: Omit<Review, 'id' | 'date'>) => {
    const businesses = getBusinesses();
    const index = businesses.findIndex(b => b.id === businessId);
    if (index === -1) return null;
    const business = businesses[index];
    const newReview = { ...review, id: Date.now().toString(), date: Date.now() };
    const reviews = [newReview, ...(business.reviews || [])];
    const newRating = parseFloat((reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1));
    const updated = { ...business, reviews, rating: newRating };
    businesses[index] = updated;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(businesses));
    return updated;
};

export const getAnalytics = (): AnalyticsData => {
    const businesses = getBusinesses().filter(b => b.status === 'approved');
    const totalViews = businesses.reduce((sum, b) => sum + (b.views || 0), 0);
    const totalReviews = businesses.reduce((sum, b) => sum + (b.reviews?.length || 0), 0);
    const topBusinesses = [...businesses].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 5);
    const categoryViews: Record<string, number> = {};
    businesses.forEach(b => {
        categoryViews[b.category] = (categoryViews[b.category] || 0) + (b.views || 0);
    });
    return { totalViews, totalReviews, topBusinesses, categoryViews };
};

export const getWeather = async (): Promise<WeatherData> => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({ temp: 34, condition: 'Sunny', humidity: 45, windSpeed: 12 });
        }, 1000);
    });
};

export const getSavedBusinessIds = (): string[] => {
    const data = localStorage.getItem(SAVED_BUSINESSES_KEY);
    return data ? JSON.parse(data) : [];
};

export const toggleSaveBusiness = (id: string): boolean => {
    const ids = getSavedBusinessIds();
    const index = ids.indexOf(id);
    let isNowSaved = false;
    if (index >= 0) {
        ids.splice(index, 1);
        isNowSaved = false;
    } else {
        ids.push(id);
        isNowSaved = true;
    }
    localStorage.setItem(SAVED_BUSINESSES_KEY, JSON.stringify(ids));
    return isNowSaved;
};

export const isBusinessSaved = (id: string): boolean => {
    return getSavedBusinessIds().includes(id);
};
