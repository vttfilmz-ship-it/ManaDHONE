
import { GoogleGenAI } from "@google/genai";
import { Business, Category } from "../types";

// Always use process.env.API_KEY to initialize GoogleGenAI
const getClient = () => {
    /* Always use new GoogleGenAI({ apiKey: process.env.API_KEY }) directly */
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateBusinessDescription = async (
    name: string,
    category: Category,
    keywords: string
): Promise<string> => {
    /* Initialize client right before use */
    const ai = getClient();

    try {
        const prompt = `
        Write a compelling, short marketing description (max 2 sentences) for a local business.
        Business Name: ${name}
        Category: ${category}
        Keywords/Services: ${keywords}
        
        The tone should be professional yet inviting.
        `;

        const response = await ai.models.generateContent({
            // For simple text tasks, use gemini-3-flash-preview
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        // Use the .text property directly, not a function call
        return response.text || "Could not generate description.";
    } catch (error) {
        console.error("Gemini API Error:", error);
        return "Error generating description. Please try again.";
    }
};

export const generateFullBusinessDescription = async (
    name: string,
    category: Category,
    keywords: string
): Promise<string> => {
    /* Initialize client right before use */
    const ai = getClient();

    try {
        const prompt = `
        Write a detailed and professional business description (approx 100-150 words) for a local business directory listing.
        Business Name: ${name}
        Category: ${category}
        Keywords/Services: ${keywords}
        Location: ManaDHONE town.
        
        Highlight the key services, the atmosphere, and the value proposition based on the keywords provided. The tone should be warm, authentic, and inviting to local customers.
        `;

        const response = await ai.models.generateContent({
            // For general text tasks, use gemini-3-flash-preview
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        // Use the .text property directly
        return response.text || "Could not generate description.";
    } catch (error) {
        console.error("Gemini API Error:", error);
        return "Error generating description.";
    }
};

export const enhanceDescription = async (currentDescription: string, keywords?: string): Promise<string> => {
    /* Initialize client right before use */
    const ai = getClient();

    try {
        let prompt = `
        Enhance the following business description to be more SEO friendly, professional, and attractive to customers in a local town setting. Keep the text under 100 words.
        
        Current Description: "${currentDescription}"
        `;
        
        if (keywords) {
            prompt += `\nIMPORTANT: Ensure to incorporate or emphasize these specific keywords/services: ${keywords}`;
        }

        const response = await ai.models.generateContent({
            // For basic reasoning/summarization, use gemini-3-flash-preview
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        // Use the .text property directly
        return response.text || currentDescription;
    } catch (error) {
        console.error("Gemini API Error:", error);
        return currentDescription;
    }
};

export const generateBusinessImage = async (prompt: string): Promise<string | null> => {
    /* Initialize client right before use */
    const ai = getClient();

    try {
        const response = await ai.models.generateContent({
            // Use gemini-2.5-flash-image for general image tasks
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: `Create a professional, high-quality, photorealistic image for a business listing. Context: ${prompt}` }]
            },
            config: {
                imageConfig: {
                    aspectRatio: "4:3"
                }
            }
        });

        const candidate = response.candidates?.[0];
        if (candidate?.content?.parts) {
            // Find the image part as recommended, do not assume it's the first
            for (const part of candidate.content.parts) {
                if (part.inlineData && part.inlineData.data) {
                    const mimeType = part.inlineData.mimeType || 'image/png';
                    return `data:${mimeType};base64,${part.inlineData.data}`;
                }
            }
        }
        return null;
    } catch (error) {
        console.error("Gemini Image Gen Error:", error);
        return null;
    }
};
